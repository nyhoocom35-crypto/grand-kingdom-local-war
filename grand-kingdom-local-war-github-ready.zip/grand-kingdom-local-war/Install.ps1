﻿param([ValidateSet('standard','growth8')][string]$Mode='standard',[string]$VitaRoot='',[string]$DecryptedSelf='')
$ErrorActionPreference='Stop'
function Hash([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadJson([string]$p){return Get-Content -LiteralPath $p -Raw -Encoding UTF8|ConvertFrom-Json}
function SelectFile([string]$title){
 Add-Type -AssemblyName System.Windows.Forms
 $d=New-Object System.Windows.Forms.OpenFileDialog
 $d.Title=$title;$d.Filter='eboot.bin|*.bin|All files|*.*'
 if($d.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){throw 'Selection cancelled. No game executable was changed.'}
 return $d.FileName
}
function ApplyPatches([byte[]]$bytes,$patches){
 foreach($p in @($patches)){
  $o=[int]$p.offset
  if($p.before.Length -ne $p.after.Length -or $p.before.Length%2 -ne 0){throw 'Invalid patch lengths.'}
  $n=[int]($p.before.Length/2)
  if($o -lt 0 -or $o+$n -gt $bytes.Length){throw 'Patch outside executable.'}
  for($i=0;$i -lt $n;$i++){
   if($bytes[$o+$i] -ne [Convert]::ToByte($p.before.Substring($i*2,2),16)){throw 'Original instructions do not match the verified patch.'}
   $bytes[$o+$i]=[Convert]::ToByte($p.after.Substring($i*2,2),16)
  }
 }
}
function FromHex([string]$hex){
 if($hex.Length%2 -ne 0){throw 'Invalid helper hex length.'}
 $n=[int]($hex.Length/2);if($n -gt 4096){throw 'Helper is outside the verified size limit.'}
 $a=New-Object byte[] $n
 for($i=0;$i -lt $n;$i++){$a[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
 return ,$a
}
$prepared='';$stage=''
try{
 if(Get-Process -Name Vita3K -ErrorAction SilentlyContinue){throw 'Close Vita3K before installing.'}
 if(@(Get-Process -ErrorAction SilentlyContinue|Where-Object {$_.ProcessName -like 'GK_Server*'}).Count -gt 0){throw 'Close all GK server windows before installing.'}
 . (Join-Path $PSScriptRoot 'AtomicReplace.ps1')
 . (Join-Path $PSScriptRoot 'Finish_Install.ps1')
 $manifest=ReadJson (Join-Path $PSScriptRoot 'release.json')
 $m=$manifest.modes.$Mode
 $exe=Join-Path $PSScriptRoot 'GK_Server_29.exe'
 if((Hash $exe) -ne $manifest.server_sha256){throw 'Server file hash mismatch.'}
 & $exe --selftest
 if($LASTEXITCODE -ne 0){throw 'Server selftest failed.'}
 $recordPath=Join-Path $PSScriptRoot 'public-install.json';$previous=$null;$oldRecord=$null
 if(Test-Path -LiteralPath $recordPath){$oldRecord=[IO.File]::ReadAllText($recordPath);$previous=$oldRecord|ConvertFrom-Json;$target=[string]$previous.target}
 elseif(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'active-install.json')){$legacy=ReadJson (Join-Path $PSScriptRoot 'active-install.json');$target=[string]$legacy.target}
 else{
  if(!$VitaRoot){$VitaRoot=Join-Path $env:APPDATA 'Vita3K\Vita3K'}
  $target=Join-Path $VitaRoot 'ux0\patch\PCSG00474\eboot.bin'
  if(!(Test-Path -LiteralPath $target)){$target=Join-Path $VitaRoot 'ux0\app\PCSG00474\eboot.bin'}
  if(!(Test-Path -LiteralPath $target)){$target=SelectFile 'Select INSTALLED PCSG00474 1.06 eboot.bin (ux0 patch/app folder)'}
 }
 $target=[IO.Path]::GetFullPath($target)
 $gameDir=Split-Path $target -Parent;$roleDir=Split-Path $gameDir -Parent
 if((Split-Path $gameDir -Leaf) -ne 'PCSG00474' -or (Split-Path $roleDir -Leaf) -notin @('app','patch')){throw 'Select ux0\patch\PCSG00474\eboot.bin or ux0\app\PCSG00474\eboot.bin.'}
 $VitaRoot=Split-Path (Split-Path $roleDir -Parent) -Parent
 $current=Hash $target
 $variants=@($m.variants|Where-Object {$_.source_sha256 -eq $current})
 $fresh=$current -eq $manifest.original_installed_sha256 -or $current -eq $manifest.decrypted_sha256
 if(!$fresh -and $variants.Count -ne 1){throw 'Unsupported executable. Only verified Japanese PCSG00474 1.06 and clients 30/31/32/34/38 are supported. No game files changed.'}
 $protocol=Join-Path $PSScriptRoot 'protocol.dat'
 $protocolOK=(Test-Path -LiteralPath $protocol) -and (Hash $protocol) -eq $manifest.protocol_sha256
 if($current -eq $m.patched_sha256 -and $protocolOK -and $previous){Complete-Release11;Write-Host ('ALREADY INSTALLED: Local War 1.5 / '+$Mode) -ForegroundColor Green;return}
 if($fresh -or !$protocolOK){
  if(!$DecryptedSelf){
   $desktop=[Environment]::GetFolderPath('Desktop')
   foreach($place in @($PSScriptRoot,$VitaRoot,(Join-Path $desktop 'vita3k'),(Join-Path $desktop 'Vita3K'))){
    $candidate=Join-Path $place 'decrypted_selfs\PCSG00474\eboot.bin'
    if((Test-Path -LiteralPath $candidate) -and (Hash $candidate) -eq $manifest.decrypted_sha256){$DecryptedSelf=$candidate;break}
   }
  }
  if(!$DecryptedSelf){$DecryptedSelf=SelectFile 'Select DECRYPTED PCSG00474 1.06 eboot.bin (decrypted_selfs folder)'}
  if((Hash $DecryptedSelf) -ne $manifest.decrypted_sha256){throw 'Wrong decrypted executable. An encrypted eboot.bin cannot be used here.'}
 }
 $backupDir=Join-Path $PSScriptRoot ('backups/public_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N').Substring(0,6))
 [void](New-Item -ItemType Directory -Path $backupDir)
 $backup=Join-Path $backupDir 'eboot-before-public.bin';Copy-Item -LiteralPath $target -Destination $backup
 if((Hash $backup) -ne $current){throw 'Executable backup verification failed.'}
 $saves=@();$userRoot=Join-Path $VitaRoot 'ux0\user'
 if(Test-Path -LiteralPath $userRoot){
  foreach($profile in (Get-ChildItem -LiteralPath $userRoot -Directory)){
   $save=Join-Path $profile.FullName 'savedata\PCSG00474'
   if(Test-Path -LiteralPath $save){
    $dest=Join-Path $backupDir ('savedata_'+$profile.Name);Copy-Item -LiteralPath $save -Destination $dest -Recurse
    foreach($f in (Get-ChildItem -LiteralPath $save -File -Recurse)){$rel=$f.FullName.Substring($save.Length).TrimStart('\');if((Hash $f.FullName) -ne (Hash (Join-Path $dest $rel))){throw 'Save backup verification failed.'}}
    $saves+=@{original=$save;backup=$dest}
   }
  }
 }
 foreach($name in @('active-install.json','public-install.json','war-state.json','local-users.json')){
  $p=Join-Path $PSScriptRoot $name;if(Test-Path -LiteralPath $p){Copy-Item -LiteralPath $p -Destination $backupDir}
 }
 if($fresh -or !$protocolOK){
  $prepared=Join-Path $gameDir ('gk-public-prepared-'+[guid]::NewGuid().ToString('N')+'.bin')
  & $exe --prepare $DecryptedSelf $prepared
  if($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $prepared)){throw 'Protocol extraction/preparation failed.'}
  if((Hash $protocol) -ne $manifest.protocol_sha256){throw 'Extracted protocol did not match the verified game.'}
 }
 if($fresh){
  $f=$m.fresh
  if((Hash $prepared) -ne $f.source_sha256){throw 'Prepared base executable did not match.'}
  $bytes=[IO.File]::ReadAllBytes($prepared)
  if($bytes.Length -ne [int]$f.source_length){throw 'Prepared base length mismatch.'}
  ApplyPatches $bytes $f.patches
  $c=$f.clone_code;$clone=New-Object byte[] ([int]$c.length)
  [Array]::Copy($bytes,[int]$c.offset,$clone,0,$clone.Length)
  ApplyPatches $clone $c.patches
  $suffix=FromHex ([string]$c.suffix_hex)
  $expanded=New-Object byte[] ($bytes.Length+$clone.Length+$suffix.Length)
  [Array]::Copy($bytes,0,$expanded,0,$bytes.Length);[Array]::Copy($clone,0,$expanded,$bytes.Length,$clone.Length);[Array]::Copy($suffix,0,$expanded,$bytes.Length+$clone.Length,$suffix.Length)
 }else{
  $v=$variants[0];$bytes=[IO.File]::ReadAllBytes($target)
  if($bytes.Length -ne [int]$v.source_length){throw 'Current executable length mismatch.'}
  ApplyPatches $bytes $v.patches;$suffix=FromHex ([string]$v.append_hex)
  $expanded=New-Object byte[] ($bytes.Length+$suffix.Length)
  [Array]::Copy($bytes,0,$expanded,0,$bytes.Length);[Array]::Copy($suffix,0,$expanded,$bytes.Length,$suffix.Length)
 }
 $stage=Join-Path $gameDir ('gk-public-final-'+[guid]::NewGuid().ToString('N')+'.bin')
 [IO.File]::WriteAllBytes($stage,$expanded)
 if((Hash $stage) -ne $m.patched_sha256){throw 'Prepared public patch hash mismatch.'}
 if((Hash $target) -ne $current){throw 'Installed executable changed during preparation.'}
 $undoBackup=$backup;$undoHash=$current
 if($previous){$undoBackup=$previous.undo_backup;$undoHash=$previous.undo_sha256}
 $record=[ordered]@{release='1.5';mode=$Mode;target=$target;patched_sha256=$m.patched_sha256;undo_backup=$undoBackup;undo_sha256=$undoHash;latest_backup=$backup;backup_directory=$backupDir;saves=$saves;created=(Get-Date -Format o)}
 # Save recovery information before replacement, as for the verified update32.
 [IO.File]::WriteAllText($recordPath,($record|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
 try{Replace-VerifiedFile $stage $target $m.patched_sha256}catch{
  if((Hash $target) -eq $current){if($oldRecord){[IO.File]::WriteAllText($recordPath,$oldRecord,(New-Object Text.UTF8Encoding($false)))}else{Remove-Item -LiteralPath $recordPath}}
  throw
 }
 Write-Host ('INSTALLED: Grand Kingdom Local War 1.5 / '+$Mode) -ForegroundColor Green
 Complete-Release11
 Write-Host 'MERIT x3: positive own operation merit gains; existing points and costs preserved.' -ForegroundColor Green
 Write-Host 'EXP x3: current and future own mercenaries; level growth option preserved.' -ForegroundColor Green
 Write-Host 'REQUIRED SETTINGS: Graphics backend OpenGL; VSync OFF.' -ForegroundColor Yellow
 Write-Host 'Run 2_Start_Local_War.cmd, keep READY window open, then start Vita3K.'
 Write-Host ('Verified executable and current save backups: '+$backupDir)
}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}
finally{foreach($p in @($prepared,$stage)){if($p -and (Test-Path -LiteralPath $p)){Remove-Item -LiteralPath $p}}}
