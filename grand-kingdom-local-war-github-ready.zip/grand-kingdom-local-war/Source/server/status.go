package main

import (
	"encoding/json"
	"net/http"
	"sort"
	"time"
)

type VoteCount struct {
	Country byte   `json:"country"`
	Region  byte   `json:"region"`
	Base    byte   `json:"base"`
	AI      uint32 `json:"ai"`
	Player  uint32 `json:"player"`
	Total   uint32 `json:"total"`
}

func (w *War) voteCounts() []VoteCount {
	out := []VoteCount{}
	if w.World == nil {
		return out
	}
	c := w.World
	for country := byte(0); country < 4; country++ {
		for region := byte(0); region < 16; region++ {
			if !combatRegion(region) || c.Owners[region] == country || !w.reachable(country, region) {
				continue
			}
			for base := byte(0); base < 7; base++ {
				if c.BaseOwners[region][base] == country {
					continue
				}
				ai := uint32(6 + (int(region)+int(base)+int(w.ID)+c.Round+int(country)*3)%7)
				p := uint32(0)
				for _, v := range c.Votes {
					if v.Country == country && v.Region == region && (v.Base == base || v.Base == 23) {
						p = saturate(p, v.Weight)
					}
				}
				out = append(out, VoteCount{country, region, base, ai, p, saturate(ai, p)})
			}
		}
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Country != out[j].Country {
			return out[i].Country < out[j].Country
		}
		if out[i].Total != out[j].Total {
			return out[i].Total > out[j].Total
		}
		if out[i].Region != out[j].Region {
			return out[i].Region < out[j].Region
		}
		return out[i].Base < out[j].Base
	})
	return out
}
func (b *Backend) statusHTTP(w http.ResponseWriter, r *http.Request) bool {
	if r.URL.Path != "/status" && r.URL.Path != "/status.json" {
		return false
	}
	if r.Method != "GET" {
		http.Error(w, "GET required", 405)
		return true
	}
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	if r.URL.Path == "/status" {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'")
		w.Write([]byte(statusHTML))
		return true
	}
	if b.war == nil {
		http.Error(w, "war unavailable", 503)
		return true
	}
	b.war.mu.Lock()
	defer b.war.mu.Unlock()
	type DispatchView struct {
		Company  string `json:"company"`
		Slot     byte   `json:"slot"`
		Battles  byte   `json:"battles"`
		Wins     byte   `json:"wins"`
		Returned bool   `json:"returned"`
	}
	dispatched := []DispatchView{}
	for id, slots := range b.war.Dispatches {
		c, _ := b.war.company(id)
		for slot, t := range slots {
			dispatched = append(dispatched, DispatchView{c.Name, slot, t.Battles, t.Wins, t.Returned})
		}
	}
	strategyVotes := []map[string]any{}
	ids := []int{}
	for id, s := range b.war.Strategies {
		if s.Votes != nil {
			ids = append(ids, int(id))
		}
	}
	sort.Ints(ids)
	for _, id := range ids {
		s := b.war.Strategies[uint32(id)]
		v := s.Votes
		entry := map[string]any{"operation": id, "deadline": s.Began, "resolved": v.Resolved, "ai_placement_votes": v.AIPlacements, "placement_votes": v.placementCounts25(), "placement_result": v.DeploymentResult, "ai_policy_votes": v.AIPolicy, "policy_votes": v.policyCounts25(), "commands": v.commandCounts25()}
		if f := s.Finish37; f != nil {
			entry["operation_end"] = f.End
			entry["remaining_seconds"] = max(0, int(time.Until(f.End).Seconds()))
			entry["completed"] = f.Completed
			entry["winning_side"] = f.Winner
		}
		if b.war.World != nil {
			entry["map"] = b.war.World.Operations[uint32(id)]
		}
		strategyVotes = append(strategyVotes, entry)
	}
	data := map[string]any{"server_version": 29, "snapshot_protocol": 22, "contract_nations": b.war.contractNations26(), "campaign": b.war.ID, "remaining_seconds": max(0, int(time.Until(b.war.End).Seconds())), "votes": b.war.voteCounts(), "dispatches": dispatched, "strategy_votes": strategyVotes}
	data["display_revision"] = 33
	data["dispatch_revision"] = 35
	data["order_revision"] = 36
	data["finish_revision"] = 37
	data["order_limit_per_side"] = orderLimitPerSide36
	data["order_limit_per_battle"] = 2 * orderLimitPerSide36
	data["dispatch_step_seconds"] = int(dispatchStep / time.Second)
	data["dispatch_battle_limit"] = dispatchLimit
	data["country_names"] = displayNames33.Countries
	data["region_names"] = displayNames33.Regions
	data["base_names"] = displayNames33.Bases
	if c := b.war.World; c != nil {
		data["round"] = c.Round + 1
		data["owners"] = c.Owners
		data["revision"] = b.war.wireID()
		data["fronts"] = c.Fronts
		data["research"] = c.Research
		data["events"] = displayEvents33(c.Events)
	}
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(data)
	return true
}

const statusHTML = `<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>그란킹덤 전황·투표 집계</title><style>body{font:16px system-ui;background:#101b28;color:#eef4fb;margin:24px auto;max-width:1100px;padding:0 16px}h1{font-size:26px}h2{margin-top:30px;font-size:20px}table{border-collapse:collapse;width:100%;margin:14px 0;background:#192b3e}th,td{padding:8px 12px;border-bottom:1px solid #304861;text-align:left}th{color:#9ed1ff}.meta{color:#bcd0e4}strong{color:#8de4cb}#error{color:#ffbc9c}</style>
<h1>전황·투표 집계</h1><p id="clock" class="meta"></p><p id="error"></p>
<h2>국가 계약 인구·영토</h2><div id="contracts"></div>
<h2>현재 전장 영향력</h2><div id="fronts"></div>
<h2>영토 소유권</h2><div id="owners"></div>
<h2>다음 전장 지지표</h2><p class="meta">투표 직후 3초 안에 반영됩니다. 5분마다 후보를 정산합니다. AI 표와 플레이어 표를 합산하며 국가 간 중복 지역은 정산 때 조정됩니다. 지역·거점은 게임의 한글 이름으로 표시합니다.</p><div id="votes"></div>
<h2>국가 병영 투표</h2><div id="research"></div>
<h2>전장 병기 설치·공헌도 투표</h2><p class="meta">작전별로 양 진영을 구분해 AI 표·플레이어 표·합계를 표시합니다. 설치 결과는 최초 참가 후 60초에 한 번 확정됩니다.</p><div id="strategyvotes"></div>
<h2>부대 파견</h2><div id="dispatches"></div><h2>최근 전황</h2><div id="events"></div><script>
function table(parent,head,rows){
  let t=document.createElement('table'),tr=document.createElement('tr');
  head.forEach(x=>{let th=document.createElement('th');th.textContent=x;tr.append(th)});t.append(tr);
  rows.forEach(xs=>{let tr=document.createElement('tr');xs.forEach(x=>{let td=document.createElement('td');td.textContent=x;tr.append(td)});t.append(tr)});parent.append(t);
}
async function refresh(){try{
  let r=await fetch('/status.json');if(!r.ok)throw Error('서버 응답 '+r.status);
  let s=await r.json(),sec=s.remaining_seconds;
  const nation=c=>s.country_names?.[c]||(c===4?'길드':'알 수 없는 국가');
  const region=r=>s.region_names?.[r]||'알 수 없는 지역';
  const base=(r,b)=>b===23?'지역 전체':s.base_names?.[r]?.[b]||'알 수 없는 거점';
  document.querySelector('#clock').textContent='캠페인 '+s.campaign+' · '+(s.round||1)+'/6 라운드 · 남은 시간 '+Math.floor(sec/60)+'분 '+sec%60+'초';
  for(let id of ['contracts','fronts','owners','votes','research','strategyvotes','dispatches','events'])document.getElementById(id).replaceChildren();
  table(document.getElementById('contracts'),['국가','영토 수 (수도 포함)','전장 지역 수','AI 용병단','플레이어 용병단','계약 합계','계약 비율'],s.contract_nations.map(c=>[nation(c.country),c.territories,c.combat_territories,c.ai,c.player,c.total,c.percent.toFixed(2)+'%']));
  table(document.getElementById('fronts'),['지역','공격국','방어국','거점','공격 영향력','방어 영향력'],(s.fronts||[]).map(f=>[region(f.region),nation(f.attacker),nation(f.defender),f.bases.map(b=>base(f.region,b)).join(', '),f.influence[0],f.influence[1]]));
  table(document.getElementById('owners'),['지역','소유 국가'],(s.owners||[]).map((c,r)=>[region(r),nation(c)]));
  for(let c=0;c<4;c++){
    let p=document.getElementById('votes'),h=document.createElement('h3');h.textContent=nation(c);p.append(h);
    table(p,['지역','거점','AI 표','플레이어 표','합계'],s.votes.filter(v=>v.country===c).map(v=>[region(v.region),base(v.region,v.base),v.ai,v.player,v.total]));
  }
  table(document.getElementById('research'),['국가','연구','후보 1','후보 2','후보 3','후보 4','진행률'],(s.research||[]).flatMap((a,c)=>a.map((r,k)=>[nation(c),k===0?'병기':'지원',...r.votes,r.progress+'%'])));
  const types={5:'부대',6:'발리스타',7:'병기 7',8:'시설 8',9:'시설 9',11:'설치 안 함'};
  for(let v of s.strategy_votes){
    let p=document.getElementById('strategyvotes'),h=document.createElement('h3'),m=v.map;
    h.textContent=(m?region(m.Region)+' / '+base(m.Region,m.Base)+' · ':'')+'작전 '+v.operation+' · '+(v.resolved?'설치 확정':'투표 중');p.append(h);
    const sideName=side=>m?nation(side===0?m.Attacker:m.Defender):side===0?'공격 진영':'방어 진영';
    if(v.operation_end){let timer=document.createElement('p'),left=v.remaining_seconds;timer.className='meta';timer.textContent=v.completed?'작전 종료 · '+sideName(v.winning_side)+' 승리':'작전 종료까지 '+Math.floor(left/60)+'분 '+left%60+'초';p.append(timer);}
    let rows=[];
    for(let side=0;side<2;side++){for(let slot=0;slot<10;slot++){for(let c of [5,6,7,8,9,11]){
      let ai=v.ai_placement_votes[side][slot][c],total=v.placement_votes[side][slot][c];
      if(total>0)rows.push([sideName(side),slot+1,types[c],ai,total-ai,total,v.resolved?types[v.placement_result[side][slot]]:'집계 중']);
    }}}
    table(p,['진영','배치 칸','후보','AI 표','플레이어 표','합계','결과'],rows);
    let policy=[];
    for(let side=0;side<2;side++){for(let kind=0;kind<3;kind++){for(let c=0;c<7;c++){
      let ai=v.ai_policy_votes[side][kind][c],total=v.policy_votes[side][kind][c];policy.push([sideName(side),kind+1,c,ai,total-ai,total]);
    }}}
    table(p,['진영','공헌도 항목','후보 번호','AI 점수','플레이어 점수','합계'],policy);
  }
  table(document.getElementById('dispatches'),['용병단','부대','전투','승리','상태'],s.dispatches.map(d=>[d.company,d.slot+1,d.battles,d.wins,d.returned?'귀환':'파견 중']));
  (s.events||[]).slice(-8).reverse().forEach(e=>{let p=document.createElement('p');p.textContent=e;document.getElementById('events').append(p)});
  document.getElementById('error').textContent='';
}catch(e){document.getElementById('error').textContent='갱신 실패: '+e.message}}
refresh();setInterval(refresh,3000);
</script></html>`
