package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// Export encrypted responses for actual client24 ARM handlers AFTER resolution.
func TestVotes25AllMapsBothSidesAndRollover(t *testing.T) {
	p := testProtocol(t)
	w := campaignWar(t)
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p, war: w}
	out := "testdata/votes25"
	os.MkdirAll(out, 0700)
	emit := func(name string, api int, req []byte) []byte {
		r := make([]byte, eps[api].RequestPadded)
		copy(r, req)
		u32(r, 4, 0x3130786b)
		u32(r, 8, eps[api].OperationCode)
		u32(r, 12, uint32(eps[api].ResponseLogical))
		frame, status, err := b.response(eps[api], r)
		if err != nil || status != "OK" {
			t.Fatal(name, status, err)
		}
		q, err := p.decode(frame, true)
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(out, name), frame, 0600); err != nil {
			t.Fatal(err)
		}
		return q
	}
	checks := 0
	for region := byte(0); region < 16; region++ {
		if !combatRegion(region) {
			continue
		}
		for base := byte(0); base < 7; base++ {
			w.OperationGeneration++
			id := w.operationID(0)
			w.World.Owners[region] = 1
			for j := 0; j < 7; j++ {
				w.World.BaseOwners[region][j] = 1
			}
			w.World.Fronts[0] = Front{region, 0, 1, [3]byte{base, (base + 1) % 7, (base + 2) % 7}, [2]uint32{1000, 1000}}
			w.World.Operations[id] = Operation{region, base, 0, 1, w.ID}
			// Native API21 resolves fronts by region: fixture fronts must be unique.
			next := 1
			for r := byte(0); r < 16 && next < 4; r++ {
				if r == region || !combatRegion(r) {
					continue
				}
				def := w.World.Owners[r]
				att := (def + 1) % 4
				bases := [3]byte{base, (base + 1) % 7, (base + 2) % 7}
				w.World.Fronts[next] = Front{r, att, def, bases, [2]uint32{1000, 1000}}
				for j := 0; j < 7; j++ {
					w.World.BaseOwners[r][j] = def
				}
				for j, b := range bases {
					w.World.Operations[w.operationID(next*3+j)] = Operation{r, b, att, def, w.ID}
				}
				next++
			}
			label := fmt.Sprintf("map_%02d_%d", region, base)
			req := campaignReq(w, 123, 23)
			u32(req, 0xa0, id)
			emit(label+"_21.response.bin", 21, req)
			for side := byte(0); side < 2; side++ {
				req[0xa4] = side
				u32(req, 0x24, 123+uint32(side))
				emit(fmt.Sprintf("%s_%d_23.response.bin", label, side), 23, req)
			}
			s := w.Strategies[id]
			s.Began = time.Now().UTC().Add(time.Minute)
			l, _ := w.layout(id)
			w.ensureVotes25(id, s, l)
			for side := byte(0); side < 2; side++ {
				req[0xa4] = side
				u32(req, 0x24, 123+uint32(side))
				for slot := 0; slot < 10; slot++ {
					req[0xa8+slot] = 11
					if choices := deploymentCandidates25(l, int(side), slot); len(choices) > 0 {
						req[0xa8+slot] = choices[(slot+1)%len(choices)]
					}
				}
				for retry := 0; retry < 3; retry++ {
					if ok, err := w.place(req); !ok || err != nil {
						t.Fatal(label, side, "placement", err)
					}
				}
				if len(s.Votes.Placements) != int(side)+1 {
					t.Fatal("retries duplicated ballot")
				}
				for k := 0; k < 3; k++ {
					req[0xa5+k] = byte((int(side)*3 + k) % 7)
					u32(req, 0xb4+4*k, uint32(100+k*10))
				}
				for retry := 0; retry < 3; retry++ {
					if err := w.campaignRequest(34, make([]byte, 160), req); err != nil {
						t.Fatal(err)
					}
				}
			}
			if len(s.Votes.Policy) != 2 {
				t.Fatal("policy retry duplicated")
			}
			for side := 0; side < 2; side++ {
				for k := 0; k < 3; k++ {
					for c := 0; c < 7; c++ {
						if s.Votes.AIPolicy[side][k][c] == 0 {
							t.Fatal("missing AI policy choice")
						}
					}
				}
			}
			s.Began = time.Now().UTC().Add(-185 * time.Second)
			for side := byte(0); side < 2; side++ {
				req[0xa4] = side
				u32(req, 0x24, 123+uint32(side))
				q := emit(fmt.Sprintf("%s_%d_24.response.bin", label, side), 24, req)
				if binary.LittleEndian.Uint32(q[0x98+0x54:]) == 0 {
					t.Fatal("native vote matrix empty")
				}
				kinds := map[byte]bool{}
				for _, o := range s.Objects {
					if o.Side == side {
						kinds[o.Type] = true
					}
					if o.Type == 5 && o.Slot >= 12 {
						t.Fatal("invalid rival troop slot")
					}
				}
				for _, typ := range []byte{0, 5, 6, 7, 10} {
					if !kinds[typ] {
						t.Fatal(label, side, "missing type", typ)
					}
				}
				checks++
			}
			if !s.Votes.Resolved || len(s.Objects) > 36 {
				t.Fatal(label, "resolution/capacity")
			}
			if err := w.validateStrategies(); err != nil {
				t.Fatal(err)
			}
			before, _ := json.Marshal(s)
			loaded, err := loadWar(w.path)
			if err != nil {
				t.Fatal(err)
			}
			w = loaded
			b.war = w
			buf := make([]byte, 1712)
			if ok, err := w.strategyData(buf, req); !ok || err != nil {
				t.Fatal(err)
			}
			after, _ := json.Marshal(w.Strategies[id])
			if !bytes.Equal(before, after) {
				t.Fatal(label, "restart changed resolved votes")
			}
			for j := 0; j < 10; j++ {
				req[0xa8+j] = 11
			}
			if ok, err := w.place(req); !ok || err != nil {
				t.Fatal(err)
			}
			after, _ = json.Marshal(w.Strategies[id])
			if !bytes.Equal(before, after) {
				t.Fatal(label, "late ballot reopened voting")
			}
		}
	}
	if checks != 168 {
		t.Fatal(checks)
	}
	id := w.operationID(0)
	req := campaignReq(w, 123, 24)
	u32(req, 0xa0, id)
	l, ok := w.layout(id)
	if !ok {
		t.Fatal("last map lost")
	}
	start := w.Start
	for _, step := range []time.Duration{5 * time.Minute, 30 * time.Minute, 35 * time.Minute} {
		if err := w.advance(start.Add(step)); err != nil {
			t.Fatal(err)
		}
		if next, ok := w.layout(id); !ok || fmt.Sprint(next) != fmt.Sprint(l) {
			t.Fatal("old map remapped")
		}
		emit(fmt.Sprintf("rollover_%d_24.response.bin", step/time.Minute), 24, req)
	}
	loaded, err := loadWar(w.path)
	if err != nil {
		t.Fatal("state after campaigns", err)
	}
	if loaded.Strategies[id].Votes == nil || !loaded.Strategies[id].Votes.Resolved {
		t.Fatal("state lost at campaign rollover")
	}
}

func TestVotes25MigrationReplacementAndWriteRollback(t *testing.T) {
	w := campaignWar(t)
	id := w.operationID(0)
	req := campaignReq(w, 123, 23)
	u32(req, 0xa0, id)
	if ok, err := w.enter(make([]byte, 1600), req); !ok || err != nil {
		t.Fatal(err)
	}
	s := w.Strategies[id]
	s.Began = time.Now().UTC().Add(time.Minute)
	for j := 0; j < 10; j++ {
		s.Placements[0][j] = 11
		req[0xa8+j] = 11
	}
	s.Placements[0][1] = 6
	req[0xa9] = 7
	if err := w.save(); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	w = loaded
	l, _ := w.layout(id)
	w.ensureVotes25(id, w.Strategies[id], l)
	if len(w.Strategies[id].Votes.Placements) != 1 {
		t.Fatal("old proposal lost")
	}
	if ok, err := w.place(req); !ok || err != nil {
		t.Fatal(err)
	}
	if len(w.Strategies[id].Votes.Placements) != 1 || w.Strategies[id].Votes.Placements[123].Choices[1] != 7 {
		t.Fatal("migration ballot not replaced")
	}
	old, _ := json.Marshal(w)
	w.path = filepath.Join(t.TempDir(), "missing", "state.json")
	req[0xa9] = 5
	if ok, err := w.place(req); ok || err == nil {
		t.Fatal("failed durable write accepted")
	}
	now, _ := json.Marshal(w)
	if !bytes.Equal(old, now) {
		t.Fatal("failed write changed state")
	}
}

func TestVotes25ActualCapturedPlacementAndCommands(t *testing.T) {
	dir := os.Getenv("GK_CAPTURE25")
	if dir == "" {
		t.Skip("private replay optional")
	}
	p := testProtocol(t)
	w := campaignWar(t)
	w.ID = 18
	w.World.Operations[2270] = Operation{0, 0, 0, 1, 18}
	responses, _ := filepath.Glob(filepath.Join(dir, "*_21.response.bin"))
	for _, f := range responses {
		raw, _ := os.ReadFile(f)
		q, err := p.decode(raw, true)
		if err != nil {
			t.Fatal(err)
		}
		for i := 0; i < 4; i++ {
			for j := 0; j < 3; j++ {
				at := 0x8c + i*0xf0 + 8 + j*0x44
				if binary.LittleEndian.Uint32(q[at+0x30:]) == 2270 {
					op := w.World.Operations[2270]
					op.Region = q[0x8c+i*0xf0+0xed]
					op.Base = q[at+0x34]
					w.World.Operations[2270] = op
				}
			}
		}
	}
	files, _ := filepath.Glob(filepath.Join(dir, "*105629*_28.request.bin"))
	if len(files) != 1 {
		t.Fatal(files)
	}
	raw, _ := os.ReadFile(files[0])
	req, err := p.decode(raw, false)
	if err != nil {
		t.Fatal(err)
	}
	if ok, err := w.enter(make([]byte, 1600), req); !ok || err != nil {
		t.Fatal(err)
	}
	w.Strategies[2270].Began = time.Now().UTC().Add(time.Minute)
	for retry := 0; retry < 4; retry++ {
		if ok, err := w.place(req); !ok || err != nil {
			t.Fatal(err)
		}
	}
	wanted := [10]byte{6, 6, 7, 5, 7, 6, 11, 11, 11, 11}
	player := binary.LittleEndian.Uint32(req[0x24:])
	if w.Strategies[2270].Votes.Placements[player].Choices != wanted {
		t.Fatal("captured proposal changed")
	}
	for _, api := range []int{31, 34} {
		fs, _ := filepath.Glob(filepath.Join(dir, fmt.Sprintf("*111432*_%02d.request.bin", api)))
		if len(fs) != 1 {
			t.Fatal(api, fs)
		}
		raw, _ := os.ReadFile(fs[0])
		r, err := p.decode(raw, false)
		if err != nil {
			t.Fatal(err)
		}
		dst := make([]byte, 160)
		for retry := 0; retry < 4; retry++ {
			if api == 31 {
				if ok, err := w.registerOrder25(dst, r); !ok || err != nil {
					t.Fatal(err)
				}
			} else {
				if err := w.campaignRequest(34, dst, r); err != nil {
					t.Fatal(err)
				}
			}
		}
		if api == 31 && dst[0x8d] != 2 {
			t.Fatal("captured command acknowledgment")
		}
	}
}
