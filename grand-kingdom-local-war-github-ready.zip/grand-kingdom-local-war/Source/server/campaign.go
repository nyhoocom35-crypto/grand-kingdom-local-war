package main

import (
	"crypto/sha256"
	_ "embed"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"time"
)

//go:embed world-layouts.json
var worldLayoutData []byte

//go:embed adjacency.json
var adjacencyData []byte

var initialOwners = [16]byte{0, 0, 3, 3, 0, 0, 3, 3, 2, 2, 1, 1, 2, 2, 1, 1}

func combatRegion(region byte) bool {
	return region < 16 && region != 3 && region != 4 && region != 12 && region != 15
}

const campaignLength = 30 * time.Minute
const roundLength = 5 * time.Minute
const aiStep = 15 * time.Second

type Front struct {
	Region    byte      `json:"region"`
	Attacker  byte      `json:"attacker"`
	Defender  byte      `json:"defender"`
	Bases     [3]byte   `json:"bases"`
	Influence [2]uint32 `json:"influence"`
}
type Operation struct {
	Region, Base, Attacker, Defender byte
	Campaign                         uint32
}
type Ballot struct {
	Region, Base, Country byte
	Weight                uint32
}
type Rank struct {
	ID      uint32    `json:"id"`
	Name    string    `json:"name"`
	Country byte      `json:"country"`
	AI      bool      `json:"ai"`
	Scores  [3]uint32 `json:"scores"`
	Wins    uint32    `json:"wins"`
	Losses  uint32    `json:"losses"`
}
type Research struct {
	Votes      [4]uint32 `json:"votes"`
	Item       byte      `json:"item"`
	Progress   uint32    `json:"progress"`
	Gold       uint32    `json:"gold"`
	Resources  uint32    `json:"resources"`
	Level      byte      `json:"level"`
	Candidates [4]byte   `json:"candidates"`
}
type Campaign struct {
	Version     int                  `json:"version"`
	Round       int                  `json:"round"`
	Tick        int64                `json:"tick"`
	Owners      [16]byte             `json:"owners"`
	BaseOwners  [16][7]byte          `json:"base_owners"`
	Fronts      [4]Front             `json:"fronts"`
	Operations  map[uint32]Operation `json:"operations"`
	Votes       map[uint32]Ballot    `json:"votes"`
	Ranks       map[uint32]*Rank     `json:"ranks"`
	ScoreTotals map[string][3]uint32 `json:"score_totals"`
	Receipts    map[string]bool      `json:"receipts"`
	Research    [4][2]Research       `json:"research"`
	History     []CampaignResult     `json:"history"`
	Events      []string             `json:"events"`
}
type CampaignResult struct {
	Fronts     [4]Front    `json:"fronts"`
	BaseOwners [16][7]byte `json:"base_owners"`
	ID         uint32      `json:"id"`
	End        time.Time   `json:"end"`
	Owners     [16]byte    `json:"owners"`
	Ranks      []Rank      `json:"ranks"`
}

func (w *War) fightingEnd() time.Time {
	if w.World != nil {
		return w.End.Add(-30 * time.Second)
	}
	return w.End.Add(-time.Hour)
}
func (w *War) layout(id uint32) (Layout, bool) {
	if w.World != nil {
		if op, ok := w.World.Operations[id]; ok {
			if !combatRegion(op.Region) {
				return Layout{}, false
			}
			l, ok := worldLayouts22[fmt.Sprintf("%d:%d", op.Region, op.Base)]
			return l, ok
		}
		return Layout{}, false // Never remap an unknown ID to another battlefield.
	}
	return layoutFor(id)
}
func (w *War) change(fn func() error) error {
	// Caller owns w.mu. Roll back the entire persistent state if a durable write fails.
	before, err := json.Marshal(w)
	if err != nil {
		return err
	}
	if err = fn(); err == nil {
		err = w.save()
	}
	if err != nil {
		var old War
		if json.Unmarshal(before, &old) == nil {
			w.ID = old.ID
			w.Start = old.Start
			w.End = old.End
			w.OperationGeneration = old.OperationGeneration
			w.OperationStart = old.OperationStart
			w.Contracts = old.Contracts
			w.AIContracts26 = old.AIContracts26
			w.Strategies = old.Strategies
			w.World = old.World
			w.Companies = old.Companies
			w.Dispatches = old.Dispatches
		}
		return err
	}
	return nil
}
func (w *War) enableCampaign(now time.Time) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.World != nil {
		return w.validateWorld()
	}
	return w.change(func() error {
		if w.OperationGeneration >= 357913856 {
			return errors.New("operation generation exhausted")
		}
		w.Start = now.Truncate(time.Second)
		w.End = w.Start.Add(campaignLength)
		w.OperationGeneration++
		w.OperationStart = w.Start.Add(-time.Minute)
		c := &Campaign{Version: 15, Operations: map[uint32]Operation{}, Votes: map[uint32]Ballot{}, Ranks: map[uint32]*Rank{}, ScoreTotals: map[string][3]uint32{}, Receipts: map[string]bool{}}
		for i := 0; i < 16; i++ {
			c.Owners[i] = initialOwners[i]
			for j := 0; j < 7; j++ {
				c.BaseOwners[i][j] = initialOwners[i]
			}
		}
		for id := range w.Strategies {
			i := int((id - 1000) % 12)
			c.Operations[id] = Operation{regions[i/3], byte(3 + i%3), attackers[i/3], byte(i / 3), w.ID}
		}
		w.World = c
		w.seedAI()
		for i := 0; i < 4; i++ {
			for k := 0; k < 2; k++ {
				c.Research[i][k] = Research{Item: byte(k), Candidates: [4]byte{0, 1, 2, 3}}
			}
		}
		w.selectFronts()
		w.event("Campaign 15 enabled: 30 minutes, 5-minute rounds, 15-second AI steps")
		return nil
	})
}
func (w *War) validateWorld() error {
	c := w.World
	if c == nil {
		return nil
	}
	if c.Version != 15 || c.Round < 0 || c.Round > 5 || c.Tick < 0 || c.Tick > 120 || w.End.Sub(w.Start) != campaignLength || c.Operations == nil || c.Votes == nil || c.Ranks == nil || c.ScoreTotals == nil || c.Receipts == nil {
		return errors.New("invalid campaign 15 state; keep backups")
	}
	for i, o := range c.Owners {
		if o > 3 {
			return errors.New("invalid territory owner")
		}
		for _, v := range c.BaseOwners[i] {
			if v > 3 {
				return errors.New("invalid base owner")
			}
		}
	}
	for _, f := range c.Fronts {
		if !combatRegion(f.Region) || f.Attacker > 3 || f.Defender > 3 || f.Attacker == f.Defender {
			return errors.New("invalid campaign front")
		}
		for _, b := range f.Bases {
			if b > 6 {
				return errors.New("invalid battlefield")
			}
		}
	}
	for _, r := range c.Ranks {
		if r == nil || r.ID == 0 || r.Country > 3 {
			return errors.New("invalid ranking")
		}
	}
	for _, op := range c.Operations {
		if op.Region > 15 || op.Base > 6 || op.Attacker > 3 || op.Defender > 3 {
			return errors.New("invalid operation history")
		}
	}
	for _, v := range c.Votes {
		if v.Region > 15 || (v.Base > 6 && v.Base != 23) || v.Country > 3 || v.Weight > 9999 {
			return errors.New("invalid vote")
		}
	}
	for _, rs := range c.Research {
		for _, r := range rs {
			if r.Item > 46 || r.Level > 9 || r.Progress > 100 {
				return errors.New("invalid research")
			}
		}
	}
	return nil
}
func (w *War) seedAI() {
	for country := 0; country < 4; country++ {
		for i := 0; i < 6; i++ {
			id := uint32(0xf0000000 + country*100 + i)
			w.World.Ranks[id] = &Rank{ID: id, Name: fmt.Sprintf("AI-%d-%02d", country+1, i+1), Country: byte(country), AI: true}
		}
	}
}
func (w *War) event(s string) {
	c := w.World
	c.Events = append(c.Events, s)
	if len(c.Events) > 120 {
		c.Events = c.Events[len(c.Events)-120:]
	}
}
func neighbors() [16][]byte { var a [16][]byte; _ = json.Unmarshal(adjacencyData, &a); return a }
func (w *War) reachable(country, region byte) bool {
	c := w.World
	if region > 15 {
		return false
	}
	if c.Owners[region] == country {
		return true
	}
	a := neighbors()
	for i, o := range c.Owners {
		if o == country {
			for _, v := range a[i] {
				if v == region {
					return true
				}
			}
		}
	}
	return false
}
func (w *War) selectFronts() {
	c := w.World
	order := []int{0, 1, 2, 3}
	strengths := [4]uint32{}
	for _, v := range c.Votes {
		strengths[(int(v.Country)+3)%4] += v.Weight
	}
	sort.SliceStable(order, func(a, b int) bool { return strengths[order[a]] > strengths[order[b]] })
	used := map[byte]bool{}
	for _, i := range order {
		country := byte((i + 1) % 4)
		weights := map[int]uint32{}
		// AI votes favor reachable opposing land and avoid a fixed clockwise script.
		for region := 0; region < 16; region++ {
			if combatRegion(byte(region)) && !used[byte(region)] && c.Owners[region] != country && w.reachable(country, byte(region)) {
				for base := 0; base < 7; base++ {
					if c.BaseOwners[region][base] != country {
						weights[region*7+base] = uint32(6 + (region+base+int(w.ID)+c.Round+int(country)*3)%7)
					}
				}
			}
		}
		for _, v := range c.Votes {
			if combatRegion(v.Region) && !used[v.Region] && v.Country == country && c.Owners[v.Region] != country && w.reachable(country, v.Region) {
				if v.Base == 23 { // Native region proposal has no selected base.
					for base := 0; base < 7; base++ {
						key := int(v.Region)*7 + base
						if _, exists := weights[key]; exists {
							weights[key] += v.Weight
						}
					}
				} else {
					weights[int(v.Region)*7+int(v.Base)] += v.Weight
				}
			}
		}
		chosen := -1
		var best uint32
		for key, n := range weights {
			if n > best || n == best && (chosen < 0 || key < chosen) {
				chosen = key
				best = n
			}
		}
		if chosen < 0 {
			for r := 0; r < 16; r++ {
				if combatRegion(byte(r)) && !used[byte(r)] && c.Owners[r] != country {
					chosen = r*7 + 3
					break
				}
			}
		}
		if chosen < 0 {
			for r := 0; r < 16; r++ {
				if combatRegion(byte(r)) && !used[byte(r)] {
					chosen = r*7 + 3
					break
				}
			}
			country = (c.Owners[chosen/7] + 1) % 4
		}
		region, base := byte(chosen/7), byte(chosen%7)
		used[region] = true
		defender := c.Owners[region]
		f := Front{Region: region, Attacker: country, Defender: defender, Bases: [3]byte{base, (base + 1) % 7, (base + 2) % 7}, Influence: [2]uint32{1, 1}}
		c.Fronts[i] = f
		for j, b := range f.Bases {
			c.Operations[w.operationID(i*3+j)] = Operation{region, b, country, defender, w.ID}
		}
		w.event(fmt.Sprintf("Round %d: country %d vote selected region %d base %d (%d votes)", c.Round+1, country, region, base, best))
	}
	w.voteDeadlines = nil
}
func saturate(a, b uint32) uint32 {
	if uint64(a)+uint64(b) > 999999 {
		return 999999
	}
	return a + b
}
func (w *War) aiCombat(tick int64) {
	w.renewAIContracts26(tick)
	c := w.World
	for i := range c.Fronts {
		f := &c.Fronts[i]
		for side, country := range []byte{f.Attacker, f.Defender} {
			level := int(c.Research[country][0].Level) + int(c.Research[country][1].Level)
			// Stable variation makes restart/catch-up produce exactly the same AI outcome.
			n := uint32(8 + (int(tick)*17+i*11+int(country)*7+int(w.ID)*3)%23 + level*2)
			f.Influence[side] = saturate(f.Influence[side], n)
			rows := w.aiContractRanks26(country)
			r := rows[(int(tick)+i)%len(rows)]
			r.Scores[0] = saturate(r.Scores[0], n)
			r.Scores[1] = saturate(r.Scores[1], n/2)
			r.Scores[2] = saturate(r.Scores[2], 1)
		}
	}
	for i := 0; i < 4; i++ {
		for k := 0; k < 2; k++ {
			r := &c.Research[i][k]
			r.Progress += 5
			choice := (int(tick) + i*3 + k*7) % 4
			r.Votes[choice] = saturate(r.Votes[choice], uint32(1+(int(tick)+i+k)%3))
			if r.Progress >= 100 {
				r.Progress = 100
			}
		}
	}
}
func (w *War) finishRound() {
	c := w.World
	// Resolve all fronts against a single prior ownership snapshot. On overlaps,
	// highest winning margin wins; ties keep the defender's previous ownership.
	owners := c.BaseOwners
	margins := [16][7]uint32{}
	for _, f := range c.Fronts {
		side := 0
		if f.Influence[1] >= f.Influence[0] {
			side = 1
		}
		win, lose := f.Attacker, f.Defender
		if side == 1 {
			win, lose = lose, win
		}
		margin := uint32(0)
		if f.Influence[side] > f.Influence[1-side] {
			margin = f.Influence[side] - f.Influence[1-side]
		}
		for j, b := range f.Bases {
			if margin > margins[f.Region][b] {
				owners[f.Region][b] = win
				margins[f.Region][b] = margin
			}
			if j == 0 {
				w.event(fmt.Sprintf("Round %d: country %d defeats country %d at region %d, influence %d:%d", c.Round+1, win, lose, f.Region, f.Influence[0], f.Influence[1]))
			}
		}
		for _, r := range c.Ranks {
			if r.AI {
				if r.Country == win {
					r.Wins++
				}
				if r.Country == lose {
					r.Losses++
				}
			}
		}
	}
	c.BaseOwners = owners
	for i := 0; i < 16; i++ {
		counts := [4]int{}
		for _, o := range owners[i] {
			counts[o]++
		}
		old := c.Owners[i]
		winner := old
		for country := 0; country < 4; country++ {
			if counts[country] > counts[winner] {
				winner = byte(country)
			}
		}
		if winner != old {
			c.Owners[i] = winner
			w.event(fmt.Sprintf("Territory %d captured: country %d -> %d", i, old, winner))
		}
	}
	for country := 0; country < 4; country++ {
		for kind := 0; kind < 2; kind++ {
			r := &c.Research[country][kind]
			if r.Progress >= 100 {
				if r.Level < 9 {
					r.Level++
				}
				r.Progress = 0
				choice := 0
				for j := 1; j < 4; j++ {
					if r.Votes[j] > r.Votes[choice] {
						choice = j
					}
				}
				r.Item = r.Candidates[choice]
				r.Votes = [4]uint32{}
				r.Gold = 0
				r.Resources = 0
				w.event(fmt.Sprintf("Country %d barrack %d automatically selected item %d, level %d", country, kind, r.Item, r.Level))
			}
		}
	}
}
func (w *War) nextCampaign() error {
	c := w.World
	w.finishEntered37(w.End)
	w.event(fmt.Sprintf("Campaign %d finished", w.ID))
	ranks := []Rank{}
	for _, r := range c.Ranks {
		ranks = append(ranks, *r)
	}
	sort.Slice(ranks, func(i, j int) bool {
		if ranks[i].Scores[0] == ranks[j].Scores[0] {
			return ranks[i].ID < ranks[j].ID
		}
		return ranks[i].Scores[0] > ranks[j].Scores[0]
	})
	c.History = append(c.History, CampaignResult{ID: w.ID, End: w.End, Owners: c.Owners, Ranks: ranks, Fronts: c.Fronts, BaseOwners: c.BaseOwners})
	if len(c.History) > 8 {
		c.History = c.History[len(c.History)-8:]
	}
	if w.ID == 0xffffffff || w.OperationGeneration >= 357913856 {
		return errors.New("campaign ID exhausted")
	}
	w.ID++
	w.Start = w.End
	w.End = w.Start.Add(campaignLength)
	w.OperationGeneration++
	w.OperationStart = w.Start.Add(-time.Minute)
	c.Round = 0
	c.Tick = 0
	c.Votes = map[uint32]Ballot{}
	c.ScoreTotals = map[string][3]uint32{}
	c.Receipts = map[string]bool{}
	c.Ranks = map[uint32]*Rank{}
	w.seedAI()
	w.resetAIContracts26()
	// Contract map is retained for compatibility; the native new-campaign ID
	// triggers the original client contract flow. No gold/payment logic is replaced.
	w.selectFronts()
	// Keep the latest campaign and any already entered map through a boundary.
	for id, op := range c.Operations {
		s := w.Strategies[id]
		// Keep entered maps for late battle results until a terminal reply was
		// served. Retain served results through the originating campaign + eight
		// subsequent campaigns for normal settlement retries.
		if op.Campaign+1 < w.ID && (s == nil || s.Finish37 != nil && s.Finish37.Delivered && uint64(op.Campaign)+8 < uint64(w.ID)) {
			delete(c.Operations, id)
			delete(w.Strategies, id)
		}
	}
	return nil
}
func (w *War) advance(now time.Time) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.World == nil || now.Before(w.Start) {
		return nil
	}
	target := int64(now.Sub(w.Start) / aiStep)
	if target == w.World.Tick {
		return nil
	}
	return w.change(func() error {
		w.advanceDispatches(now)
		// Offline simulation is bounded to the latest four hours; older gaps jump
		// campaign IDs without inventing archived scores for unplayed campaigns.
		if now.Sub(w.End) > 4*time.Hour {
			// Preserve the actual recorded campaign before skipping long inactive gaps.
			w.event("Archived recorded progress before skipping a long offline interval")
			if err := w.nextCampaign(); err != nil {
				return err
			}
			skip := uint32((now.Sub(w.End) - 4*time.Hour) / campaignLength)
			if uint64(w.ID)+uint64(skip) >= 0xffffffff || uint64(w.OperationGeneration)+uint64(skip) >= 357913856 {
				return errors.New("campaign counter overflow")
			}
			w.ID += skip
			w.resetAIContracts26()
			w.OperationGeneration += skip
			w.Start = w.Start.Add(time.Duration(skip) * campaignLength)
			w.End = w.End.Add(time.Duration(skip) * campaignLength)
			w.OperationStart = w.Start.Add(-time.Minute)
			w.event(fmt.Sprintf("Skipped %d inactive campaigns without fabricated rankings", skip))
			w.selectFronts()
		}
		for {
			c := w.World
			until := now
			if until.After(w.End) {
				until = w.End
			}
			n := int64(until.Sub(w.Start) / aiStep)
			if n > 120 {
				n = 120
			}
			for c.Tick < n {
				c.Tick++
				if c.Tick <= 118 {
					w.aiCombat(c.Tick)
				}
				w.finishEntered37(w.Start.Add(time.Duration(c.Tick) * aiStep))
				if c.Tick%20 == 0 && c.Tick < 120 {
					w.finishRound()
					c.Round++
					w.OperationGeneration++
					w.OperationStart = w.Start.Add(time.Duration(c.Tick) * aiStep).Add(-time.Minute)
					w.selectFronts()
				}
			}
			if now.Before(w.End) {
				break
			}
			w.finishRound()
			if err := w.nextCampaign(); err != nil {
				return err
			}
		}
		return nil
	})
}
func (w *War) player(req []byte, country byte) *Rank {
	id := binary.LittleEndian.Uint32(req[0x24:])
	r := w.World.Ranks[id]
	if r == nil {
		name := string(req[0x10:0x21])
		for i, b := range []byte(name) {
			if b == 0 {
				name = name[:i]
				break
			}
		}
		if name == "" {
			name = fmt.Sprintf("PLAYER-%d", id)
		}
		r = &Rank{ID: id, Name: name, Country: country}
		w.World.Ranks[id] = r
	}
	r.Country = country
	return r
}
func (w *War) campaignRequest(api int, dst, req []byte) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.World == nil {
		return errors.New("campaign 15 not enabled")
	}
	if binary.LittleEndian.Uint32(req[0x24:]) == 0 {
		return errors.New("player ID required")
	}
	campaign := binary.LittleEndian.Uint32(req[0x9c:])
	if campaignNumber(campaign) != w.ID {
		if api == 34 {
			dst[0x8c] = 8
			dst[0x8d] = 8
			dst[0x8e] = 8
			// The entered map can outlive a campaign boundary. Apply its vote
			// to that map without crediting scores to the new campaign.
			id := binary.LittleEndian.Uint32(req[0xa0:])
			if op, ok := w.World.Operations[id]; ok && op.Campaign == campaignNumber(campaign) && req[0xa4] < 2 && w.Strategies[id] != nil {
				return w.change(func() error { return w.policyVote25(dst, req) })
			}
		}
		return nil
	} // Acknowledge late results without crediting the next campaign.
	// Native SetVoteData is also part of reconnect synchronization. Its
	// unselected region is -1 (serialized as 0xff), with base sentinel 23.
	// Quest rewards can change the weight and make this empty proposal dirty.
	// Acknowledge it so the native completion callback clears that dirty state,
	// without creating, clearing, or persisting any campaign ballot.
	if api == 10 && req[0xa2] == 0xff && req[0xa3] == 23 && binary.LittleEndian.Uint16(req[0xa0:]) <= 9999 {
		return nil
	}
	return w.change(func() error {
		c := w.World
		id := binary.LittleEndian.Uint32(req[0x24:])
		country, contracted := w.Contracts[id]
		switch api {
		case 10:
			region, base := req[0xa2], req[0xa3]
			weight := uint32(binary.LittleEndian.Uint16(req[0xa0:]))
			if !contracted || country > 3 || region > 15 || (base > 6 && base != 23) || weight > 9999 {
				return errors.New("invalid next-battle ballot")
			}
			c.Votes[id] = Ballot{region, base, country, max(uint32(1), weight)}
			w.event(fmt.Sprintf("Country %d player ballot: region %d base %d weight %d", country, region, base, weight))
		case 11:
			kind, nation := req[0xc4], req[0xc5]
			if kind > 1 || nation > 3 {
				return errors.New("invalid barrack contribution")
			}
			r := &c.Research[nation][kind]
			digest := sha256.Sum256(req[0x9c:0xc8])
			key := fmt.Sprintf("barrack:%d:%d:%d:%s", id, c.Round, r.Item, hex.EncodeToString(digest[:]))
			gain := uint32(0)
			if !c.Receipts[key] {
				gold := binary.LittleEndian.Uint32(req[0xa0:])
				res := uint32(0)
				for o := 0xa8; o <= 0xc0; o += 4 {
					res = saturate(res, binary.LittleEndian.Uint32(req[o:]))
				}
				r.Gold = saturate(r.Gold, gold)
				r.Resources = saturate(r.Resources, res)
				gain = min(uint32(1000), gold/100+res)
				r.Progress = min(uint32(100), r.Progress+gain)
				for j, item := range r.Candidates {
					if item == r.Item {
						r.Votes[j] = saturate(r.Votes[j], max(uint32(1), gain))
					}
				}
				c.Receipts[key] = true
			}
			u32(dst, 0x8c, min(r.Gold, uint32(0x044aa200)))
			u32(dst, 0x90, gain)
			dst[0x94] = 0
		case 33, 34:
			opid := binary.LittleEndian.Uint32(req[0xa0:])
			op, ok := c.Operations[opid]
			side := req[0xa4]
			if !ok || op.Campaign != w.ID || side > 1 {
				return errors.New("invalid battle operation")
			}
			nation := op.Attacker
			if side == 1 {
				nation = op.Defender
			}
			r := w.player(req, nation)
			if api == 34 {
				dst[0x8c], dst[0x8d], dst[0x8e] = 8, 8, 8
				if err := w.policyVote25(dst, req); err != nil {
					return err
				}
				key := fmt.Sprintf("%d:%d", id, opid)
				old := c.ScoreTotals[key]
				var total [3]uint32
				delta := uint32(0)
				for j := 0; j < 3; j++ {
					v := min(uint32(999999), binary.LittleEndian.Uint32(req[0xb4+4*j:]))
					total[j] = max(old[j], v)
					d := total[j] - old[j]
					r.Scores[j] = saturate(r.Scores[j], d)
					delta = saturate(delta, d)
				}
				c.ScoreTotals[key] = total
				for i := range c.Fronts {
					for j := 0; j < 3; j++ {
						if w.operationID(i*3+j) == opid {
							c.Fronts[i].Influence[side] = saturate(c.Fronts[i].Influence[side], delta)
						}
					}
				}
			} else {
				digest := sha256.Sum256(req[0x9c:0xd2])
				key := fmt.Sprintf("battle:%d:%s", id, hex.EncodeToString(digest[:]))
				if !c.Receipts[key] {
					if req[0xa5] == 1 {
						r.Wins++
					} else {
						r.Losses++
					}
					c.Receipts[key] = true
					if s := w.Strategies[opid]; s != nil && req[0xa5] == 1 {
						object := uint32(binary.LittleEndian.Uint16(req[0xcc:]))
						for j := range s.Objects {
							o := &s.Objects[j]
							if o.ID == object && o.Side != side && o.Type == 5 {
								s.Objects = append(s.Objects[:j], s.Objects[j+1:]...)
								break
							}
						}
					}
				}
			}
		}
		return nil
	})
}
func writeRank(dst []byte, off int, r Rank, metric int) {
	u32(dst, off, r.ID)
	dst[off+4] = r.Country
	dst[off+5] = 0
	dst[off+6] = 0
	labels := []string{r.Name, "Company", "Mercenaries", "Campaign"}
	if c, ok := aiCompany(r.ID); ok {
		labels = []string{c.Name, c.Motto, "Nation Guard", fmt.Sprintf("Company %02d", (r.ID-0xf0000000)%100+1)}
	}
	for i, label := range labels {
		copy(dst[off+8+24*i:off+8+24*(i+1)], label)
	}
	name := []byte(r.Name)
	if len(name) > 16 {
		name = name[:16]
	}
	copy(dst[off+0x68:off+0x79], name)
	u32(dst, off+0x7c, r.Scores[metric])
}
func (w *War) ranking(dst, req []byte, api int) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.World == nil {
		return
	}
	rows := []Rank{}
	for _, r := range w.World.Ranks {
		rows = append(rows, *r)
	}
	if api == 44 {
		// Native top response has ten blocks with four nation records per block.
		// Empty troop sections are deliberate: the server has no submitted unit names.
		for country := 0; country < 4; country++ {
			list := []Rank{}
			for _, r := range rows {
				if r.Country == byte(country) {
					list = append(list, r)
				}
			}
			sort.Slice(list, func(i, j int) bool {
				if list[i].Scores[0] == list[j].Scores[0] {
					return list[i].ID < list[j].ID
				}
				return list[i].Scores[0] > list[j].Scores[0]
			})
			for block := 0; block < 10 && block < len(list); block++ {
				writeRankTop(dst, 0x8c+block*0x67c+0x48c+country*0x7c, list[block])
				w.rankCompanyLabels(dst, 0x8c+block*0x67c+0x48c+country*0x7c, list[block].ID)
			}
		}
		return
	}
	offset := int(binary.LittleEndian.Uint32(req[0xa0:]))
	if offset < 0 || offset > len(rows) {
		return
	}
	for metric := 0; metric < 3; metric++ {
		sort.Slice(rows, func(i, j int) bool {
			if rows[i].Scores[metric] == rows[j].Scores[metric] {
				return rows[i].ID < rows[j].ID
			}
			return rows[i].Scores[metric] > rows[j].Scores[metric]
		})
		for rank, r := range rows {
			if r.ID == binary.LittleEndian.Uint32(req[0x24:]) {
				u32(dst, 0xf8c+4*metric, uint32(rank+1))
				u32(dst, 0xf98+4*metric, r.Scores[metric])
				break
			}
		}
		for i := 0; i < 10 && offset+i < len(rows); i++ {
			writeRank(dst, 0x8c+metric*0x500+i*0x80, rows[offset+i], metric)
			w.rankCompanyLabels(dst, 0x8c+metric*0x500+i*0x80, rows[offset+i].ID)
		}
	}
}
func writeRankTop(dst []byte, off int, r Rank) {
	// Top champion records are 124 bytes and do not contain the score tail.
	row := make([]byte, 128)
	writeRank(row, 0, r, 0)
	copy(dst[off:off+124], row[:124])
}
func (w *War) barrackCountry(dst []byte, country int) {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.barrack(dst)
	if w.World == nil {
		return
	}
	c := w.World
	for nation := 0; nation < 4; nation++ {
		for kind := 0; kind < 2; kind++ {
			r := c.Research[nation][kind]
			off := 0x8c + kind*0x30 + nation*12
			u32(dst, off, min(r.Gold, uint32(360000))*1000)
			u32(dst, off+4, min(r.Resources, uint32(360000))*1000)
			dst[off+8] = byte(r.Progress)
			dst[off+9] = r.Item
			dst[off+10] = 1
			copy(dst[0x10c+kind*16+nation*4:], r.Candidates[:])
		}
	}
	for j := 0; j < 8; j++ {
		dst[0x100+j] = max(byte(1), c.Research[country][j%2].Level)
	}
	u32(dst, 0x12c, w.wireID())
}

func (w *War) results(dst, req []byte) {
	w.mu.Lock()
	defer w.mu.Unlock()
	for i := 0; i < 4; i++ {
		dst[0x8c+0x24*i+0x22] = 0xff
	}
	if w.World == nil {
		for i := 0; i < 16; i++ {
			dst[0x500+i] = byte(i / 4)
		}
		return
	}
	c := w.World
	for i, o := range c.Owners {
		dst[0x500+i] = o
	}
	id := campaignNumber(binary.LittleEndian.Uint32(req[0x9c:]))
	var result *CampaignResult
	for i := range c.History {
		if c.History[i].ID == id {
			result = &c.History[i]
			break
		}
	}
	if result == nil {
		return
	}
	for i, o := range result.Owners {
		dst[0x500+i] = o
	}
	for i, f := range result.Fronts {
		off := 0x8c + i*0x24
		dst[off+0x22] = f.Region
		for side, country := range []byte{f.Attacker, f.Defender} {
			at := off + side*16
			u32(dst, at, f.Influence[side])
			dst[at+0xf] = country
			if f.Influence[side] > f.Influence[1-side] {
				dst[at+0xc] = 1
			}
			for _, o := range result.BaseOwners[f.Region] {
				if o == country {
					dst[at+0xd]++
				}
			}
		}
	}
}

func (w *War) rankCompanyLabels(dst []byte, off int, id uint32) {
	if c, ok := w.company(id); ok {
		for i, label := range []string{c.Name, c.Motto, c.Description, c.Username} {
			putText(dst[off+8+i*24:off+8+(i+1)*24], label)
		}
	}
}
