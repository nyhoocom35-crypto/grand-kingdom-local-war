package main

import (
	"encoding/binary"
	"errors"
	"fmt"
	"time"
)

func validateVotes25(v *StrategyVotes25) error {
	if v == nil {
		return nil
	} // Migration of version 22 state is lazy and reversible.
	bad := func() error { return errors.New("invalid saved vote state; preserve war-state.json") }
	if v.Version != 25 || v.Placements == nil || v.Policy == nil || v.Commands == nil || v.AITick < 0 || v.AITick > 120 {
		return bad()
	}
	for _, b := range v.Placements {
		if b.Side > 1 {
			return bad()
		}
		for _, c := range b.Choices {
			if !validDeployment25(c) {
				return bad()
			}
		}
	}
	for _, b := range v.Policy {
		if b.Side > 1 {
			return bad()
		}
		for k, c := range b.Choices {
			if c > 7 || b.Points[k] > 999999 {
				return bad()
			}
		}
	}
	for _, r := range v.Commands {
		if r.Side > 1 {
			return bad()
		}
	}
	if v.OrderRevision36 != 0 && v.OrderRevision36 != 36 {
		return bad()
	}
	if v.OrderRevision36 == 36 && (v.orderTotal36(0) > orderLimitPerSide36 || v.orderTotal36(1) > orderLimitPerSide36) {
		return bad()
	}
	for side := 0; side < 2; side++ {
		for slot := 0; slot < 10; slot++ {
			if !validDeployment25(v.DeploymentResult[side][slot]) {
				return bad()
			}
			for c, n := range v.AIPlacements[side][slot] {
				if n > 12 || n > 0 && !validDeployment25(byte(c)) {
					return bad()
				}
			}
		}
		for _, row := range v.AIPolicy[side] {
			for _, n := range row {
				if n > 999999 {
					return bad()
				}
			}
		}
	}
	return nil
}

// Wire enums, rather than translated menu labels: 5 army, 6/7 siege arms,
// 8/9 field installations, 11 empty; 10 is exclusively a real player token.
var deploymentChoices25 = [...]byte{5, 6, 7}

// Six rival troop slots per side are shared by armies and siege arms. The
// remaining map-specific installation tiles use static types 8/9, not troop
// slot numbers 12..19. The response has a hard capacity of 36 field objects.
func deploymentCandidates25(l Layout, side, slot int) []byte {
	fixtures := 0
	for _, objects := range l.Objects {
		for _, o := range objects {
			if o[1] > 0 && o[2] > 0 {
				fixtures++
			}
		}
	}
	limit := (36 - fixtures) / 2
	if slot >= limit || !usableSpawn25(l.Spawns[side][slot]) {
		return nil
	}
	if slot < 6 {
		return deploymentChoices25[:]
	}
	return []byte{8, 9}
}

type PlacementBallot25 struct {
	Side    byte     `json:"side"`
	Choices [10]byte `json:"choices"`
}
type PolicyBallot25 struct {
	Side    byte      `json:"side"`
	Choices [3]byte   `json:"choices"`
	Points  [3]uint32 `json:"points"`
}
type CommandReceipt25 struct {
	Side   byte    `json:"side"`
	Counts [6]byte `json:"counts"`
}
type StrategyVotes25 struct {
	Version          int                          `json:"version"`
	AIPlacements     [2][10][12]uint32            `json:"ai_placements"`
	Placements       map[uint32]PlacementBallot25 `json:"placement_ballots"`
	DeploymentResult [2][10]byte                  `json:"deployment_result"`
	Resolved         bool                         `json:"resolved"`
	AIPolicy         [2][3][8]uint32              `json:"ai_policy"`
	Policy           map[uint32]PolicyBallot25    `json:"policy_ballots"`
	AITick           int64                        `json:"ai_tick"`
	AICommands       [2][6]byte                   `json:"ai_commands"`
	Commands         map[uint32]CommandReceipt25  `json:"command_receipts"`
	OrderRevision36  int                          `json:"order_revision36,omitempty"`
}

func validDeployment25(choice byte) bool { return choice >= 5 && choice <= 9 || choice == 11 }
func usableSpawn25(p [2]byte) bool       { return p[0] > 0 && p[0] <= 50 && p[1] > 0 && p[1] <= 50 }

func (w *War) ensureVotes25(id uint32, s *Strategy, l Layout) bool {
	if s.Votes != nil {
		return s.Votes.normalizeOrders36()
	}
	v := &StrategyVotes25{Version: 25, OrderRevision36: 36, Placements: map[uint32]PlacementBallot25{}, Policy: map[uint32]PolicyBallot25{}, Commands: map[uint32]CommandReceipt25{}}
	// Each simulated company casts one complete placement ballot. Company and
	// slot preferences vary on EVERY map, both sides, and operation generation.
	// Persist once: neither polling nor restarting adds ballots.
	for side := 0; side < 2; side++ {
		for slot, p := range l.Spawns[side] {
			v.DeploymentResult[side][slot] = 11
			for company := 0; company < 12; company++ {
				choice := byte(11)
				choices := deploymentCandidates25(l, side, slot)
				if usableSpawn25(p) && len(choices) > 0 {
					preferred := (int(id) + side*2 + slot) % len(choices)
					index := preferred
					if company >= 5 {
						index = (preferred + company - 4) % len(choices)
					}
					choice = choices[index]
				}
				v.AIPlacements[side][slot][choice]++
			}
		}
		for kind := 0; kind < 3; kind++ {
			for company := 0; company < 12; company++ {
				choice := (int(id) + side*3 + kind*2 + company) % 7
				v.AIPolicy[side][kind][choice]++
			}
		}
		// Preserve an old server's saved, valid placement proposal on migration.
		valid, present := true, false
		old := PlacementBallot25{Side: byte(side), Choices: s.Placements[side]}
		for slot, choice := range old.Choices {
			if !validDeployment25(choice) {
				valid = false
				break
			}
			if choice != 11 {
				present = true
			}
			if !usableSpawn25(l.Spawns[side][slot]) {
				old.Choices[slot] = 11
			}
		}
		if valid && present {
			v.Placements[0xfffffff0+uint32(side)] = old
		}
	}
	s.Votes = v
	return true
}

func (v *StrategyVotes25) placementCounts25() [2][10][12]uint32 {
	totals := v.AIPlacements
	for _, b := range v.Placements {
		for slot, choice := range b.Choices {
			totals[b.Side][slot][choice] = saturate(totals[b.Side][slot][choice], 1)
		}
	}
	return totals
}
func (v *StrategyVotes25) policyCounts25() [2][3][8]uint32 {
	totals := v.AIPolicy
	for _, b := range v.Policy {
		for kind, choice := range b.Choices {
			if choice < 7 {
				totals[b.Side][kind][choice] = saturate(totals[b.Side][kind][choice], b.Points[kind])
			}
		}
	}
	return totals
}
func (v *StrategyVotes25) commandCounts25() [2][6]byte {
	var totals [2][6]byte
	left := [2]int{orderLimitPerSide36, orderLimitPerSide36}
	for side := 0; side < 2; side++ {
		for kind, n := range v.AICommands[side] {
			accepted := min(int(n), left[side])
			totals[side][kind] = byte(accepted)
			left[side] -= accepted
		}
	}
	for _, player := range v.orderPlayers36() {
		r := v.Commands[player]
		for kind, n := range r.Counts {
			accepted := min(int(n), left[r.Side])
			totals[r.Side][kind] += byte(accepted)
			left[r.Side] -= accepted
		}
	}
	return totals
}

// Resolve installation votes once at the same frozen date sent in APIs 21/24/29.
// Replace only the deployment tokens; forts, map fixtures, real players and
// already-moving tokens are kept. All coordinates come from the pinned map.
func (w *War) updateVotes25(id uint32, s *Strategy, l Layout, now time.Time) bool {
	changed := w.ensureVotes25(id, s, l)
	v := s.Votes
	if !now.Before(s.Began) && !v.Resolved {
		counts := v.placementCounts25()
		for side := 0; side < 2; side++ {
			for slot, p := range l.Spawns[side] {
				winner := byte(11)
				choices := deploymentCandidates25(l, side, slot)
				if usableSpawn25(p) && len(choices) > 0 {
					start := (int(id) + side*2 + slot) % len(choices)
					for k := 0; k < len(choices); k++ {
						choice := choices[(start+k)%len(choices)]
						if winner == 11 || counts[side][slot][choice] > counts[side][slot][winner] {
							winner = choice
						}
					}
					if counts[side][slot][11] > counts[side][slot][winner] {
						winner = 11
					}
				}
				v.DeploymentResult[side][slot] = winner
				// Only change IDs created for this exact deployment slot. This
				// cannot move a real player or recreate a defeated NPC army.
				objID := uint32(100 + side*30 + slot)
				found := false
				for j := range s.Objects {
					if s.Objects[j].ID != objID {
						continue
					}
					found = true
					if winner == 11 {
						s.Objects = append(s.Objects[:j], s.Objects[j+1:]...)
					} else {
						s.Objects[j].Type = winner
					}
					break
				}
				if !found && slot >= 6 && winner != 11 {
					if len(s.Objects) < 36 {
						s.Objects = append(s.Objects, FieldObject{ID: objID, Type: winner, Side: byte(side), X: p[0], Y: p[1], HP: 1000, MaxHP: 1000})
					}
				}
			}
		}
		v.Resolved = true
		changed = true
	}
	// A finite, deterministic 15-second cadence survives offline catch-up and
	// restart. Each AI action is selected from the combined policy votes.
	tick := int64(now.Sub(s.Began) / aiStep)
	if tick < 0 {
		tick = 0
	}
	if tick > 120 {
		tick = 120
	}
	if tick > v.AITick {
		totals := v.policyCounts25()
		for next := v.AITick + 1; next <= tick; next++ {
			for side := 0; side < 2; side++ {
				kind := int(next) % 3
				orderKind := (int(id) + side) % 3
				var sum uint32
				for choice := 0; choice < 6; choice++ {
					sum += totals[side][orderKind][choice]
				}
				orderTick := int64(4) // first army at one minute; opposing army at three.
				if side != int(id%2) {
					orderTick = 12
				}
				if next == orderTick && sum > 0 && v.orderTotal36(side) < orderLimitPerSide36 {
					pick := uint32((uint64(id)*17 + uint64(side)*11 + uint64(next)*23) % uint64(sum))
					for choice := 0; choice < 6; choice++ {
						if pick < totals[side][orderKind][choice] {
							v.AICommands[side][choice]++
							break
						}
						pick -= totals[side][orderKind][choice]
					}
				}
				choice := (int(id) + side*3 + kind*2 + int(next)) % 7
				v.AIPolicy[side][kind][choice] = saturate(v.AIPolicy[side][kind][choice], 1)
			}
		}
		v.AITick = tick
		changed = true
	}
	return changed
}

// RegisterScore carries three policy choices (a5:a8) and cumulative score
// totals (b4:c0). Store the full allocation, replacing the same player's
// previous choice; retrying or changing a choice cannot duplicate points.
func (w *War) policyVote25(dst, req []byte) error {
	id := binary.LittleEndian.Uint32(req[0xa0:])
	player := binary.LittleEndian.Uint32(req[0x24:])
	s := w.Strategies[id]
	if s == nil {
		return nil
	}
	l, ok := w.layout(id)
	if !ok {
		return fmt.Errorf("policy map unavailable: %d", id)
	}
	w.ensureVotes25(id, s, l)
	b := PolicyBallot25{Side: req[0xa4]}
	for k := 0; k < 3; k++ {
		b.Choices[k] = req[0xa5+k]
		if b.Choices[k] > 7 {
			return fmt.Errorf("invalid policy candidate %d", b.Choices[k])
		}
		b.Points[k] = min(uint32(999999), binary.LittleEndian.Uint32(req[0xb4+4*k:]))
		// Echo valid selections using the original API34 apply convention.
		dst[0x8c+k] = b.Choices[k]
	}
	s.Votes.Policy[player] = b
	return nil
}

func (w *War) registerOrder25(dst, req []byte) (bool, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	id, l, ok := w.strategyLocked(req)
	if !ok || req[0xa4] > 1 || w.Strategies[id] == nil {
		return false, nil
	}
	err := w.change(func() error {
		s := w.Strategies[id]
		w.updateVotes25(id, s, l, time.Now().UTC())
		player := binary.LittleEndian.Uint32(req[0x24:])
		if player == 0 {
			return fmt.Errorf("player ID required")
		}
		old := s.Votes.Commands[player]
		// Moving sides cannot refund an already accepted order or change its kind.
		used := 0
		for _, n := range old.Counts {
			used += int(n)
		}
		if used > 0 && old.Side != req[0xa4] {
			copy(dst[0x8c:0x92], old.Counts[:])
			return nil
		}
		if old.Side != req[0xa4] {
			old = CommandReceipt25{Side: req[0xa4]}
		}
		left := max(0, orderLimitPerSide36-s.Votes.orderTotal36(int(req[0xa4])))
		for k := 0; k < 6; k++ {
			increment := max(0, int(req[0xae+k])-int(old.Counts[k]))
			accepted := min(left, increment)
			old.Counts[k] += byte(accepted)
			left -= accepted
			dst[0x8c+k] = old.Counts[k]
		}
		s.Votes.Commands[player] = old
		return nil
	})
	return err == nil, err
}
