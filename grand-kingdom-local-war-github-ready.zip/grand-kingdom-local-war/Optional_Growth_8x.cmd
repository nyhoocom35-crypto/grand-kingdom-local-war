@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" -Mode growth8
if errorlevel 1 echo Command failed. See the message above.
pause
