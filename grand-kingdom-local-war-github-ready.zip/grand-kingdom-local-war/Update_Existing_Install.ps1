﻿$ErrorActionPreference='Stop'
try {
 if(Get-Process -Name Vita3K -ErrorAction SilentlyContinue){throw 'Vita3K를 완전히 종료한 뒤 갱신하세요.'}
 if(@(Get-Process -ErrorAction SilentlyContinue|Where-Object {$_.ProcessName -like 'GK_Server*'}).Count -gt 0){throw '기존 GK 서버 창을 모두 닫고 갱신하세요.'}
 $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'release.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 $recordPath=Join-Path $PSScriptRoot 'public-install.json'
 if(!(Test-Path -LiteralPath $recordPath -PathType Leaf)){$recordPath=Join-Path $PSScriptRoot 'active-install.json'}
 if(!(Test-Path -LiteralPath $recordPath -PathType Leaf)){throw '기존 설치 기록이 없습니다. 처음 설치는 1_Install_Standard.cmd 또는 Optional_Growth_8x.cmd를 사용하세요.'}
 $record=Get-Content -LiteralPath $recordPath -Raw -Encoding UTF8 | ConvertFrom-Json
 $target=[string]$record.target
 if([string]::IsNullOrWhiteSpace($target) -or !(Test-Path -LiteralPath $target -PathType Leaf)){throw '기존 게임 실행파일 위치를 확인할 수 없습니다.'}
 $hash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
 # Infer from the actual verified game bytes; preserve standard or growth8.
 $mode=[string]$manifest.supported_prior_modes.($hash.ToLowerInvariant())
 if($mode -notin @('standard','growth8')){throw '지원되는 기존 실행파일이 아닙니다. 기존 파일은 변경하지 않았습니다.'}
 Write-Host ('기존 성장 설정을 유지하여 배포본 1.5로 갱신합니다: '+$mode) -ForegroundColor Green
 & (Join-Path $PSScriptRoot 'Install.ps1') -Mode $mode
 if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
} catch {Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}
