﻿$ErrorActionPreference='Stop'
try{
 $m=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'release.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $r=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'public-install.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $hash=(Get-FileHash -LiteralPath $r.target -Algorithm SHA256).Hash
 $ok=$r.mode -in @('standard','growth8') -and $hash -eq $m.modes.($r.mode).patched_sha256
 $serverOK=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'GK_Server_29.exe') -Algorithm SHA256).Hash -eq $m.server_sha256
 $lines=@('Grand Kingdom Local War 1.5 audit',('Mode: '+$r.mode),('Client hash: '+$hash),('Verified client: '+$ok),('Verified server: '+$serverOK),'Required: OpenGL backend / VSync OFF')
 $running=$false
 try{$v=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1/status.json' -TimeoutSec 3;$s=$v.Content|ConvertFrom-Json;$running=$s.server_version -eq 29 -and $s.display_revision -eq 33 -and $s.finish_revision -eq 37;$lines+=('Running server: '+$s.server_version);$lines+=('Display revision: '+$s.display_revision);$lines+=('Operation finish revision: '+$s.finish_revision)}catch{$lines+='Running server: unavailable'}
 $lines|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'PATCH_AUDIT_PUBLIC.txt') -Encoding UTF8
 $lines|ForEach-Object {Write-Host $_}
 if(!$ok -or !$serverOK -or !$running){throw 'A check failed. Start 2_Start_Local_War.cmd and keep READY window open.'}
 Write-Host 'CHECK OK' -ForegroundColor Green
}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}
