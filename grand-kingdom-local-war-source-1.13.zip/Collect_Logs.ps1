﻿$ErrorActionPreference='Stop'
try{
 $work=Join-Path ([IO.Path]::GetTempPath()) ('GK_TEST_PUBLIC_'+[guid]::NewGuid().ToString('N'))
 [void](New-Item -ItemType Directory -Path $work)
 foreach($name in @('PATCH_AUDIT_PUBLIC.txt','PATCH_AUDIT_32.txt','PATCH_AUDIT_31.txt','PATCH_AUDIT_30.txt','PATCH_AUDIT_29.txt','PATCH_AUDIT_28.txt','PATCH_AUDIT_27.txt','server.log','war-state.json','PATCH_AUDIT_26.txt','PATCH_AUDIT_25.txt','PATCH_AUDIT_24.txt','PATCH_AUDIT_23.txt','PATCH_AUDIT_22.txt')){
  $p=Join-Path $PSScriptRoot $name
  if(Test-Path -LiteralPath $p){
   if($name -eq 'war-state.json'){
    # Include schedule only, excluding local user IDs / contract registrations.
    $r=Get-Content -LiteralPath $p -Raw -Encoding UTF8|ConvertFrom-Json
    @{id=$r.id;start=$r.start;end=$r.end;operation_generation=$r.operation_generation;operation_start=$r.operation_start;world_round=$r.world.round;world_tick=$r.world.tick;owners=$r.world.owners;fronts=$r.world.fronts;operations=$r.world.operations;research=$r.world.research;events=$r.world.events}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $work 'schedule.json') -Encoding UTF8
   }else{Copy-Item -LiteralPath $p -Destination $work}
  }
 }
 $install=Join-Path $PSScriptRoot 'public-install.json'
 if(Test-Path -LiteralPath $install){
  $r=Get-Content -LiteralPath $install -Raw -Encoding UTF8|ConvertFrom-Json
  $hash=(Get-FileHash -LiteralPath ([string]$r.target) -Algorithm SHA256).Hash
  ('Client executable SHA256: '+$hash)|Set-Content -LiteralPath (Join-Path $work 'client-hash.txt') -Encoding UTF8
 }
 $captures=Join-Path $PSScriptRoot 'captures'
 if(Test-Path -LiteralPath $captures){Copy-Item -LiteralPath $captures -Destination $work -Recurse}
 try {$s=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1/status.json' -TimeoutSec 3;$s.Content|Set-Content -LiteralPath (Join-Path $work 'contract-and-vote-status.json') -Encoding UTF8} catch {}
 $desktop=[Environment]::GetFolderPath('Desktop')
 $candidates=@((Join-Path $desktop 'vita3k\vita3k.log'),(Join-Path $env:APPDATA 'Vita3K\vita3k.log'),(Join-Path $env:APPDATA 'Vita3K\Vita3K\vita3k.log'))
 $logs=@($candidates|Select-Object -Unique|Where-Object {Test-Path -LiteralPath $_}|ForEach-Object {Get-Item -LiteralPath $_}|Sort-Object LastWriteTime -Descending)
 if($logs.Count -gt 0){$vitaLog=$logs[0].FullName}else{
  Add-Type -AssemblyName System.Windows.Forms
  $d=New-Object System.Windows.Forms.OpenFileDialog
  $d.Title='Select vita3k.log from your Vita3K program folder (Cancel to collect server logs only)'
  $d.Filter='Log files|*.log|All files|*.*'
  if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){$vitaLog=$d.FileName}
 }
 if($vitaLog){
  # Trace-level Vita3K logs can contain millions of lines. Stream diagnostic
  # severities into the report without changing the user's original log.
  $stream=[IO.File]::Open($vitaLog,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
  $tailBytes=8MB
  $tail=$stream.Length -gt $tailBytes
  if($tail){[void]$stream.Seek(-$tailBytes,[IO.SeekOrigin]::End)}
  $reader=New-Object IO.StreamReader($stream)
  if($tail){[void]$reader.ReadLine()}
  $writer=New-Object IO.StreamWriter((Join-Path $work 'vita3k.log'),$false,(New-Object Text.UTF8Encoding($false)))
  $diagnostic=New-Object Text.RegularExpressions.Regex('\|[IWEFC]\|',[Text.RegularExpressions.RegexOptions]::Compiled)
  try {
   $writer.WriteLine('Diagnostic export: Last 8 MiB only: INFO/WARN/ERROR/FATAL/CRITICAL retained; TRACE/DEBUG omitted. Original log was not changed.')
   while(($line=$reader.ReadLine()) -ne $null){if($diagnostic.IsMatch($line)){$writer.WriteLine($line)}}
  }finally{$reader.Dispose();$writer.Dispose()}
 }
 'Public release1.13 / display33 / native client47 / hud47 / rivals47 / secret46 / battle45 / rank45 / contract45 / shop43 / vote-transition44 / finish37 / merit3 / server29 / protocol22. Vita3K diagnostic severities only; trace/debug omitted. Read-only collection: local captures, server log, campaign schedule and optional Vita3K diagnostic log. No game binaries, save files or licenses.'|Set-Content -LiteralPath (Join-Path $work 'status.txt') -Encoding UTF8
 $zip=Join-Path $desktop ('GK_TEST_PUBLIC_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N').Substring(0,6)+'.zip')
 Compress-Archive -Path (Join-Path $work '*') -DestinationPath $zip
 Write-Host 'Upload this ZIP:' -ForegroundColor Green
 Write-Host $zip
}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}
