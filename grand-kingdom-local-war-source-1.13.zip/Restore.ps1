﻿$ErrorActionPreference='Stop'
try{
 if(Get-Process -Name Vita3K -ErrorAction SilentlyContinue){throw 'Close Vita3K before restoring.'}
 if(@(Get-Process -ErrorAction SilentlyContinue|Where-Object {$_.ProcessName -like 'GK_Server*'}).Count -gt 0){throw 'Close all GK server windows first.'}
 . (Join-Path $PSScriptRoot 'AtomicReplace.ps1')
 $record=Join-Path $PSScriptRoot 'public-install.json'
 $r=Get-Content -LiteralPath $record -Raw -Encoding UTF8|ConvertFrom-Json
 $m=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'release.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $current=(Get-FileHash -LiteralPath $r.target -Algorithm SHA256).Hash
 $hashes=@($m.modes.standard.patched_sha256,$m.modes.growth8.patched_sha256,$r.undo_sha256)
 if($current -notin $hashes){throw 'Game executable changed after installation. Nothing was restored.'}
 if((Get-FileHash -LiteralPath $r.undo_backup -Algorithm SHA256).Hash -ne $r.undo_sha256){throw 'Original executable backup verification failed.'}
 $stage=Join-Path (Split-Path $r.target -Parent) ('gk-public-restore-'+[guid]::NewGuid().ToString('N')+'.bin')
 try{Copy-Item -LiteralPath $r.undo_backup -Destination $stage;Replace-VerifiedFile $stage $r.target $r.undo_sha256}finally{if(Test-Path -LiteralPath $stage){Remove-Item -LiteralPath $stage}}
 Copy-Item -LiteralPath $record -Destination (Join-Path $PSScriptRoot 'restored-public-install.json') -Force
 Remove-Item -LiteralPath $record
 Write-Host 'RESTORED executable before first public installation. Current saves were retained.' -ForegroundColor Green
 Write-Host 'For an original game executable, start the original game normally. For a previous patch, use its previous server launcher.'
}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}
