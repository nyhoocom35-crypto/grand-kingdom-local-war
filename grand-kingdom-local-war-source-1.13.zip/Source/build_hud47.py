"""Rebuild revision47 from the owner's SELF and revision46 recipes.

The displayed HUD refreshes every regular UI update and reads the newest
received structure snapshot rather than the delayed rendered-world copy.
The troop population used by operation completion remains separate.
Rewards, experience and merit multipliers are preserved unchanged.
"""
import json, struct, sys
from pathlib import Path
from build_shop43 import asm, patches, diff, sha

def helpers(start):
    # Vtable +8 is the displayed HUD's regular update. Keep its original
    # base-class update, then refresh structure counts and HP from live data.
    return asm('push {r4,lr};mov r4,r0;bl 0x81011a14;mov r0,r4;bl 0x81225a5a;mov r0,r4;pop {r4,pc}',start)

def build(original, release, out):
    prepared=bytearray(original);host=b'kx01-prd-9bnapb338aimcuzl.elasticbeanstalk.com'
    assert prepared[0x46d180:0x46d180+len(host)]==host
    prepared[0x46d180:0x46d180+len(host)]=b'127.0.0.1'+bytes(len(host)-9)
    prior={};current={}
    for mode,m in release['modes'].items():
        f=m['fresh'];assert sha(prepared)==f['source_sha256'];c=f['clone_code']
        b=patches(prepared,f['patches']);b+=patches(b[c['offset']:c['offset']+c['length']],c['patches'])+bytes.fromhex(c['suffix_hex'])
        assert sha(b)==m['patched_sha256'];current[mode]=b;prior[sha(b)]=b
        for v in m['variants']:
            src=patches(b[:v['source_length']],v['patches'],True)
            assert sha(src)==v['source_sha256'];prior[sha(src)]=src
    targets={};records=[]
    for mode,b in current.items():
        t=bytearray(b);ph=struct.unpack_from('<Q',b,0x48)[0];si=struct.unpack_from('<Q',b,0x58)[0]
        fileoff=struct.unpack_from('<Q',b,si)[0];size=struct.unpack_from('<I',b,ph+16)[0]
        assert fileoff+size==len(b)
        code=helpers(0x81000000+size)
        assert 0x81000000+size+len(code)<=0x81498000
        # The receive callback populates WAR+13ddc; +13dd8 is the older
        # rendered-world copy, synchronized later by a separate scene update.
        edits=[(0x81225a24,asm(f'bl {hex(0x81000000+size)}',0x81225a24)),
               (0x8121cbcc,asm('bl 0x81060b58',0x8121cbcc)),
               (0x81497fac,asm('bl 0x81060b58',0x81497fac))]
        assert b[fileoff+0x497fac:fileoff+0x497fb0]==asm('bl 0x81060b64',0x81497fac)
        for va,op in edits:
            for offset in (0x10e0+va-0x81000000,fileoff+va-0x81000000):t[offset:offset+len(op)]=op
        t+=code
        struct.pack_into('<I',t,ph+16,size+len(code));struct.pack_into('<I',t,ph+20,size+len(code));struct.pack_into('<Q',t,si+8,size+len(code))
        struct.pack_into('<Q',t,0x20,len(t));struct.pack_into('<Q',t,0x18,struct.unpack_from('<Q',b,0x18)[0]+len(code))
        m=release['modes'][mode];f=m['fresh'];c=f['clone_code']
        f['patches']=diff(prepared,t[:len(prepared)])
        c['patches']=diff(t[c['offset']:c['offset']+c['length']],t[fileoff:fileoff+c['length']])
        c['suffix_hex']=t[fileoff+c['length']:].hex()
        assert len(bytes.fromhex(c['suffix_hex']))<=4096
        m['patched_sha256']=sha(t)
        m['variants']=[dict(source_sha256=h,source_length=len(src),patches=diff(src,t[:len(src)]),append_hex=t[len(src):].hex()) for h,src in prior.items()]
        m['variants'].append(dict(source_sha256=sha(t),source_length=len(t),patches=[],append_hex=''))
        release['supported_prior_modes'][sha(t)]=mode
        targets[mode]=t;(out/f'{mode}47.bin').write_bytes(t)
        records.append(dict(mode=mode,refresh_helper=hex(0x81000000+size),patch_site='0x81225a24',code_bytes=len(code),sha256=sha(t)))
    for mode,t in targets.items():
        for other,src in targets.items():
            if mode!=other:release['modes'][mode]['variants'].append(dict(source_sha256=sha(src),source_length=len(src),patches=diff(src,t),append_hex=''))
    release.update(release='1.13',native_client_base=47,hud_revision=47,rewards_unchanged=True,secret_reward_implemented=True, rival_revision=47, secret_reward_revision=46)
    (out/'release47.json').write_text(json.dumps(release,indent=2))
    (out/'HUD47_BUILD.json').write_text(json.dumps(records,indent=2))
    return records
if __name__=='__main__':
    out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
    print(json.dumps(build(Path(sys.argv[1]).read_bytes(),json.loads(Path(sys.argv[2]).read_text()),out),indent=2))
