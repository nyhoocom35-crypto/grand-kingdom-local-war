from pathlib import Path
import struct,sys,json,hashlib
from keystone import Ks,KS_ARCH_ARM,KS_MODE_THUMB
sys.path.insert(0,'analysis/re24');from import_loader import headers,bindings
sys.path.insert(0,'analysis/re23');from self_loader import relocations
ks=Ks(KS_ARCH_ARM,KS_MODE_THUMB)
sha=lambda b:hashlib.sha256(b).hexdigest()
def build(mode,path):
 src=path.read_bytes();h=headers(src)[0];dst=bytearray(src);suffix=bytearray();names={};hooks=[]
 assert h['file']+h['filesz']==len(src)
 # Standard mode needs ownership stamping and its percentage mask, but none
 # of the automatic growth hooks. Reuse the already verified client32 helpers.
 if mode=='standard':
  enhanced=Path('analysis/re32/patched32.bin').read_bytes()
  for a,n in [(0x8108ca4e,6),(0x8107de98,4)]:
   off=h['file']+a-h['addr'];dst[off:off+n]=enhanced[off:off+n]
 def asm(s,a):return bytes(ks.asm(s,a)[0])
 def helper(name,s):
  a=h['addr']+h['filesz']+len(suffix);names[name]=hex(a);suffix.extend(asm(s,a))
  if len(suffix)%4:suffix.extend(asm('nop',a+len(suffix)))
  return a
 scale=helper('own_positive_exp3', '''push {r4,lr}
ldr.w r4,[r0,#0x348]
lsrs r4,r4,#16
movw r12,#0x4752
cmp r4,r12
bne done
cmp r1,#0
ble done
movs r4,#3
umull r1,r12,r1,r4
cmp r12,#0
bne overflow
cmp r1,#0
bmi overflow
ldr.w r4,[r0,#0x218]
movw r12,#0xffff
movt r12,#0x7fff
subs r12,r12,r4
cmp r1,r12
bls done
mov r1,r12
b done
overflow:
ldr.w r4,[r0,#0x218]
movw r1,#0xffff
movt r1,#0x7fff
subs r1,r1,r4
done:
pop {r4,pc}''')
 final=helper('award',f'push {{r4,r5,r6,lr}}; mov r6,r0; bl {scale}; b.w 0x8107f168')
 preview=helper('preview',f'push.w {{r4,r5,r6,r7,r8,r9,r10,lr}}; mov r8,r0; bl {scale}; b.w 0x8107f0d6')
 for a,e,s in [(0x8107f164,'push {r4,r5,r6,lr}; adds r6,r0,#0',f'b.w {final}'),(0x8107f0d0,'push.w {r4,r5,r6,r7,r8,r9,r10,lr}; mov r8,r0',f'b.w {preview}; nop')]:
  before=asm(e,a);after=asm(s,a);off=h['file']+a-h['addr']
  assert len(before)==len(after) and src[off:off+len(before)]==before
  assert not [r for r in relocations(src) if r['patchseg']==0 and a-h['addr']<=r['offset']<a-h['addr']+len(after)]
  assert not [r for r in bindings(src) if r['patchseg']==0 and r['code'] and a-h['addr']<=r['offset']<a-h['addr']+len(after)]
  dst[off:off+len(after)]=after;hooks.append(hex(a))
 size=h['filesz']+len(suffix);assert h['addr']+size<headers(src)[1]['addr']
 ph=struct.unpack_from('<Q',src,0x48)[0];info=struct.unpack_from('<Q',src,0x58)[0]
 struct.pack_into('<I',dst,ph+16,size);struct.pack_into('<I',dst,ph+20,size);struct.pack_into('<Q',dst,info+8,size)
 struct.pack_into('<Q',dst,0x20,len(src)+len(suffix));struct.pack_into('<Q',dst,0x18,struct.unpack_from('<Q',src,0x18)[0]+len(suffix))
 dst+=suffix;Path(f'analysis/re34/{mode}.bin').write_bytes(dst)
 return dict(mode=mode,source_sha256=sha(src),patched_sha256=sha(dst),helpers=names,hooks=hooks,extra_bytes=len(suffix))
result=[build('standard',Path('analysis/public-release/standard.bin')),build('growth8',Path('analysis/re32/patched32.bin'))]
Path('analysis/re34/build.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
