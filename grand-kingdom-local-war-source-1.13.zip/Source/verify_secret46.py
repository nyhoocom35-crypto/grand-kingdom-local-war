"""Replay original secret bonus gates with the owner's WARBONUS parameters.
Usage: verify_secret46.py OWN_SELF OWN_WARBONUS_DAT
Save counters are modeled; this is not live campaign/collection validation.
"""
import json,struct,sys
from pathlib import Path
from native_replay46 import *

u=machine(Path(sys.argv[1]).read_bytes());raw=Path(sys.argv[2]).read_bytes()
BONUS=0x2900000;INNER=BONUS+0x100;ROW=BONUS+0x200
put(u,MGR+0x6c,BONUS);put(u,BONUS+0xc,INNER)
put(u,INNER,ROW);u.mem_write(ROW,raw[36:40])
put(u,INNER+8,ROW+0x100);put(u,INNER+0xc,13);u.mem_write(ROW+0x100,raw[44:96])
front=SAVE+0x8da0c
put(u,front+0x40,2);put(u,front+0x1c,1);put(u,front+0x38,2)
cases=0
for grade in range(1,14):
    put(u,SAVE+0x8e2f0,grade)
    for metric in range(3):
        required=run(u,0x810820ea,[MGR,grade,metric])
        assert required>0
        for country,side in [(1,0),(2,1)]:
            put(u,SAVE+0x8e2f4,country)
            for defeats in range(11):
                put(u,front+0x48,defeats)
                for value in (required-1,required):
                    put(u,front+4+side*28,0);put(u,front+16+side*28,value)
                    assert run(u,0x8109044c,[0,2,metric,country])==int(defeats>=10 and value>=required)
                    cases+=1
                put(u,front+4+side*28,1)
                assert run(u,0x8109044c,[0,2,metric,country])==int(defeats>=10)
                cases+=1
        put(u,SAVE+0x8e2f4,1)
        assert run(u,0x8109044c,[0,2,metric,2])==0
print(json.dumps(dict(native_gate_cases=cases,original_defeat_threshold=10,live_campaign_collection_verified=False),indent=2))
