"""Build contract revision45 from revision43 recipes and the owner's SELF.
Game bytes are private; release45.json contains only bounded patch recipes.
"""
import json,struct,sys
from pathlib import Path
from build_shop43 import asm,patches,diff,sha
from self_loader import relocations

def helpers(start):
    code=asm('''
expired:
 movw r0,#0x9b64
 movt r0,#0x8149
 ldr r1,[r0]
 add.w r0,r1,#0x26800
 ldr.w r2,[r0,#0x80]
 cmp r2,#4
 beq no_expiry
 movw r2,#0xd2d0
 movt r2,#8
 ldr r1,[r1,r2]
 cmp r1,#0
 beq no_expiry
 ldr r0,[r0,#0x7c]
 tst.w r0,#0x40000000
 it ne
 ubfxne r0,r0,#3,#27
 tst.w r1,#0x40000000
 it ne
 ubfxne r1,r1,#3,#27
 cmp r0,r1
 ite ls
 movls r0,#1
 movhi r0,#0
 bx lr
no_expiry:
 movs r0,#0
 bx lr
remaining:
 movw r0,#0x9b64
 movt r0,#0x8149
 ldr r2,[r0]
 add.w r0,r2,#0x26800
 ldr.w r1,[r0,#0x80]
 cmp r1,#4
 beq zero
 movw r1,#0xd2d0
 movt r1,#8
 ldr r1,[r2,r1]
 ldr.w r3,[r0,#0x84]
 cmp r1,#0
 beq full
 ldr r2,[r0,#0x7c]
 tst.w r1,#0x40000000
 it ne
 ubfxne r1,r1,#3,#27
 tst.w r2,#0x40000000
 it ne
 ubfxne r2,r2,#3,#27
 subs r1,r2,r1
 cmp r1,#0
 it lt
 movlt r1,#0
 cmp r1,r3
 it hi
 movhi r1,r3
 b store
full:
 mov r1,r3
 b store
zero:
 movs r1,#0
store:
 str.w r1,[r0,#0x88]
 bx lr
''',start)
    signature=asm('movw r0,#0x9b64;movt r0,#0x8149',0)
    remain=start+code.index(signature,len(signature))
    return code,remain

def build(original, release, out):
    prepared=bytearray(original);host=b'kx01-prd-9bnapb338aimcuzl.elasticbeanstalk.com'
    assert prepared[0x46d180:0x46d180+len(host)]==host
    prepared[0x46d180:0x46d180+len(host)]=b'127.0.0.1'+bytes(len(host)-9)
    prior={};current={}
    for mode,m in release['modes'].items():
        f=m['fresh'];assert sha(prepared)==f['source_sha256'];c=f['clone_code']
        b=patches(prepared,f['patches']);b=b+patches(b[c['offset']:c['offset']+c['length']],c['patches'])+bytes.fromhex(c['suffix_hex'])
        assert sha(b)==m['patched_sha256'];current[mode]=b;prior[sha(b)]=b
        for v in m['variants']:
            source=patches(b[:v['source_length']],v['patches'],True)
            assert sha(source)==v['source_sha256'];prior[sha(source)]=source
    targets={};records=[]
    for mode,b in current.items():
        t=bytearray(b);ph=struct.unpack_from('<Q',b,0x48)[0];si=struct.unpack_from('<Q',b,0x58)[0]
        fileoff=struct.unpack_from('<Q',b,si)[0];size=struct.unpack_from('<I',b,ph+16)[0]
        assert fileoff+size==len(b)
        code,remaining=helpers(0x81000000+size)
        assert 0x81000000+size+len(code)<0x81498000
        for va,dest in [(0x81089e06,0x81000000+size),(0x81089ece,remaining)]:
            op=asm(f'b.w {hex(dest)}',va);assert len(op)==4
            for offset in [0x10e0+va-0x81000000,fileoff+va-0x81000000]:t[offset:offset+4]=op
        # The old MOVW relocation would overwrite our tail branch on loading.
        r=next(r for r in relocations(t) if r['patchseg']==0 and r['offset']==0x89e06)
        assert r['format']==0 and r['code']==47
        word=struct.unpack_from('<I',t,r['record'])[0]
        assert ((word>>20)&255)==48 and ((word>>28)&15)*2==4
        assert struct.unpack_from('<I',t,r['record']+12)[0]&15==0
        struct.pack_into('<I',t,r['record'],word&~0xff00)
        t+=code
        struct.pack_into('<I',t,ph+16,size+len(code));struct.pack_into('<I',t,ph+20,size+len(code));struct.pack_into('<Q',t,si+8,size+len(code))
        struct.pack_into('<Q',t,0x20,len(t));struct.pack_into('<Q',t,0x18,struct.unpack_from('<Q',b,0x18)[0]+len(code))
        m=release['modes'][mode];f=m['fresh'];c=f['clone_code']
        f['patches']=diff(prepared,t[:len(prepared)])
        c['patches']=diff(t[c['offset']:c['offset']+c['length']],t[fileoff:fileoff+c['length']])
        c['suffix_hex']=t[fileoff+c['length']:].hex();assert len(bytes.fromhex(c['suffix_hex']))<=4096
        m['patched_sha256']=sha(t)
        m['variants']=[dict(source_sha256=h,source_length=len(src),patches=diff(src,t[:len(src)]),append_hex=t[len(src):].hex()) for h,src in prior.items()]
        m['variants'].append(dict(source_sha256=sha(t),source_length=len(t),patches=[],append_hex=''))
        release['supported_prior_modes'][sha(t)]=mode
        targets[mode]=t;(out/f'{mode}45.bin').write_bytes(t)
        records.append(dict(mode=mode,helper=hex(0x81000000+size),remaining=hex(remaining),code_bytes=len(code),sha256=sha(t)))
    for mode,t in targets.items():
        for other,src in targets.items():
            if mode!=other:release['modes'][mode]['variants'].append(dict(source_sha256=sha(src),source_length=len(src),patches=diff(src,t),append_hex=''))
    release.update(release='1.11',native_client_base=45,battle_revision=45,rank_revision=45,contract_revision=45)
    (out/'release45.json').write_text(json.dumps(release,indent=2))
    (out/'BATTLE45_BUILD.json').write_text(json.dumps(records,indent=2))
    return records
if __name__=='__main__':
    out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
    print(json.dumps(build(Path(sys.argv[1]).read_bytes(),json.loads(Path(sys.argv[2]).read_text()),out),indent=2))
