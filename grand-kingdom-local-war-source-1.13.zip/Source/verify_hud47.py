"""Run the actual displayed HUD update with changing live structure records.
Base UI lifecycle/troop counts are modeled; HP widgets, count/HP routines and frame hook are
native. This does not claim a live Vita3K screen test.
Usage: verify_hud47.py CLIENT47_DIRECTORY CLIENT46_DIRECTORY
"""
import json,sys,struct
from pathlib import Path
from native_replay46 import *

root,prior=map(Path,sys.argv[1:3])
layouts=json.loads((Path(__file__).parent/'server/world-layouts.json').read_text())
records=json.loads((root/'HUD47_BUILD.json').read_text())
HUD,SCENE,UI=0x2800000,0x2810000,0x2820000
report=dict(stale_render_copy_excluded=True,native_displayed_hud_updates=0,all_combat_maps=0,rewards_unchanged=True,actual_vita3k_verified=False)
for record in records:
 mode=record['mode'];b=(root/f'{mode}47.bin').read_bytes();old=(prior/f'{mode}46.bin').read_bytes()
 a=bytearray(relocated_segments(old)[0]);c=bytearray(relocated_segments(b)[0])
 for off in (0x225a24,0x21cbcc,0x497fac):a[off:off+4]=c[off:off+4]
 assert a==c[:len(a)],'unrelated code changed'
 u=machine(b);put(u,WAR+0x13ddc,MGR);put(u,WAR+0x13dd8,0x2830000);put(u,0x81499c58,SCENE)
 put(u,SCENE+0x2644,UI);put(u,HUD+0x18,4)
 gauges={};updates=[0]
 def hook(u,pc):
  if pc==0x81011a14:updates[0]+=1;returning(u)
  elif pc==0x8105fce0:returning(u,1)
  elif pc==0x8121c934:returning(u,0) # troop population, independent of structures

 for name,layout in layouts.items():
  if int(name.split(':')[0]) in (0,4,8,12):continue
  if mode=='standard':report['all_combat_maps']+=1
  put(u,HUD+0xb4,0)
  for stage in range(6):
   u.mem_write(MGR+0x64,bytes(32*44));hp=[0,0];maximum=[0,0];counts=[0,0];index=0
   for side,objects in enumerate(layout['objects']):
    for n,obj in enumerate(objects):
     if not obj[1] or not obj[2]:continue
     p=MGR+0x64+index*44;index+=1
     value=1000 if n else 1000-stage*200
     u.mem_write(p+4,struct.pack('<H',index));put(u,p+12,side);put(u,p+32,value);put(u,p+40,1000)
     counts[side]+=int(value>0);hp[side]+=value;maximum[side]+=1000
   # No event, scene reentry or result-screen call: ordinary frame update.
   run(u,0x81225a20,[HUD],hook)
   for side in (0,1):
    assert get(u,HUD+0x50+side*0x34)==counts[side],(mode,name,stage,side,'count')
    widget=HUD+0x54+side*0x34
    assert (get(u,widget+0x14),get(u,widget+4))==(hp[side],maximum[side]),(mode,name,stage,side,'bar')
    assert struct.unpack('<f',u.mem_read(widget+0x18,4))[0]==hp[side]
   report['native_displayed_hud_updates']+=1
 assert updates[0]>0,'base UI update skipped'
assert report['all_combat_maps']==84
print(json.dumps(report,indent=2))
