"""Replay server fixtures through authorized PCSG00474 native routines.

Usage: python verify_research_siege40.py OWN_DECRYPTED_SELF FIXTURE_DIRECTORY
Optional third argument: OWN_UNPACKED_RESEARCHPARAMETER_DAT.
Requires unicorn. This checks native data handling, not live Vita3K graphics.
"""
import json
import struct
import sys
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_HOOK_CODE
from unicorn.arm_const import *

game = Path(sys.argv[1]).read_bytes()
fixtures = Path(sys.argv[2])
REGS = [UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3]
UI, SAVE, INPUT, MANAGER, HEADER, TABLE, OUTPUT = [0x2000000+i*0x100000 for i in range(7)]
STACK, STOP = 0x2ff0000, 0x2fff000

def machine():
    u = Uc(UC_ARCH_ARM, UC_MODE_THUMB)
    u.mem_map(0x81000000, 0x800000)
    u.mem_write(0x81000000, game[0x10e0:])
    u.mem_map(0x2000000, 0x1000000)
    put(u, 0x81499c38, UI)
    put(u, 0x81499b64, SAVE)
    put(u, 0x81499bf0, MANAGER)
    u.reg_write(UC_ARM_REG_SP, STACK)
    u.reg_write(UC_ARM_REG_LR, STOP | 1)
    return u

def put(u, p, v): u.mem_write(p, struct.pack('<I', v))
def get(u, p): return struct.unpack('<I', u.mem_read(p, 4))[0]
def run(u, address, args, hook=None):
    for r, v in zip(REGS, args): u.reg_write(r, v)
    def stop(uc, pc, size, unused):
        if pc == STOP: uc.emu_stop()
        elif hook: hook(uc, pc)
    h = u.hook_add(UC_HOOK_CODE, stop)
    try: u.emu_start(address | 1, STOP, count=5000000)
    finally: u.hook_del(h)
    assert u.reg_read(UC_ARM_REG_PC) == STOP, hex(u.reg_read(UC_ARM_REG_PC))
    return u.reg_read(UC_ARM_REG_R0)

def returning(u, value=0):
    u.reg_write(UC_ARM_REG_R0, value)
    u.reg_write(UC_ARM_REG_PC, u.reg_read(UC_ARM_REG_LR))

def scope_hooks(u, pc):
    if pc in (0x810897b8, 0x810897bc): returning(u)

report = {'native_research_validator_cases':0,'native_research_completion_cases':0}
for moment in ('initial','after'):
    for nation in range(4):
        data = (fixtures/f'barrack_{moment}_{nation}.bin').read_bytes()
        u = machine(); u.mem_write(INPUT, data)
        assert run(u, 0x81064886, [INPUT]) == 1
        report['native_research_validator_cases'] += 1
        run(u, 0x8106455c, [INPUT], scope_hooks)
        for k in range(2):
            for category in range(4):
                wire = 0x8c+k*48+category*12
                native = UI+0x5e0+k*160+category*40
                assert get(u,native) == struct.unpack_from('<I',data,wire)[0]//1000
                assert get(u,native+0x10) == 0
                assert get(u,native+0xc) == data[wire+9]
                for country in range(4):
                    assert get(u,UI+0x7ac+k*64+country*16+category*4) == data[0x10c+k*16+country*4+category]
        report['native_research_completion_cases'] += 1

# Execute the actual object loop from GetStrategyData completion. Stub the
# scene constructors to inspect the native descriptors passed to them.
u = machine(); data = (fixtures/'strategy_destroyed.bin').read_bytes();u.mem_write(INPUT,data)
records = []
def objects_hook(u, pc):
    if pc == 0x81067aae:
        u.reg_write(UC_ARM_REG_PC, STOP | 1)
    elif pc == 0x81060b58: returning(u,MANAGER)
    elif pc == 0x810626c4: returning(u,HEADER)
    elif pc == 0x810624d2: returning(u,u.reg_read(UC_ARM_REG_R1))
    elif pc in (0x810a6d86,0x810a6d7a): returning(u)
    elif pc in (0x810a742a,0x810a6d8e,0x810a6e76,0x810a745e):
        p=u.reg_read(UC_ARM_REG_R1 if pc==0x810a6d8e else UC_ARM_REG_R2)
        records.append(bytes(u.mem_read(p,44)))
        returning(u)
run(u,0x81067980,[INPUT],objects_hook)
dead = [r for r in records if struct.unpack_from('<I',r,32)[0]==0]
expected=sum(struct.unpack_from('<I',data,0x230+i*28)[0]!=0 and data[0x230+i*28+8]!=10 for i in range(36))
assert len(dead)==expected,(len(dead),expected)
report['native_destroyed_object_descriptors']=len(dead)

if len(sys.argv)>3:
    param=Path(sys.argv[3]).read_bytes();count=struct.unpack_from('<I',param,32)[0]
    rows=[struct.unpack_from('<III',param,36+i*12) for i in range(count)]
    # The original inventory generator's parameter lookup, merge, item-ID
    # classification and output construction execute natively. Only its RNG
    # sampler and ownership lookup are deterministic stubs in this replay.
    def stock(levels):
        u=machine();put(u,MANAGER+0x24,HEADER);put(u,HEADER,TABLE);put(u,HEADER+4,count)
        u.mem_write(TABLE,param[36:])
        for category in range(5): put(u,HEADER+8+category*4,sum(r[0]//10000==category for r in rows))
        inp=bytearray(24);inp[0x10:0x14]=bytes(levels);u.mem_write(INPUT,bytes(inp))
        candidates=[];sample=0
        def shop_hooks(u,pc):
            nonlocal sample
            if pc in (0x81047a1e,0x81047a6a,0x810897b8,0x810897bc,0x810bbe38,0x810bc1b6): returning(u)
            elif pc==0x810bbea0: candidates.clear();sample=0;returning(u)
            elif pc==0x810bc66c: candidates.append(u.reg_read(UC_ARM_REG_R3));returning(u)
            elif pc==0x810bc2e6:
                returning(u,candidates[sample%len(candidates)]);sample+=1
            elif pc==0x8108e234: returning(u,1)
        run(u,0x81091a98,[UI,INPUT,OUTPUT],shop_hooks)
        n=get(u,OUTPUT+12)
        return [(get(u,OUTPUT+16+i*24+4),get(u,OUTPUT+16+i*24+16))for i in range(n)]
    before=stock([0]*4)
    after=[]
    fixed=(fixtures/'fixed_after.bin').read_bytes()
    for n in range(4):
        levels=fixed[0x8c+n*48+0x24:0x8c+n*48+0x28]
        inventory=stock(levels)
        assert len(inventory)>len(before),(n,levels,inventory)
        assert all(item in {r[1] for r in rows} for item,quantity in inventory)
        after.append({'country':n,'counts':list(levels),'native_inventory_items':len(inventory)})
    report['native_shop_initial_items']=len(before)
    report['native_shop_after_research']=after

print(json.dumps(report,indent=2))
