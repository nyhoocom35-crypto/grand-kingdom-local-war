"""Native replay helpers: relocated SELF, modeled process memory and stop gate."""
import struct
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_HOOK_CODE
from unicorn.arm_const import *
from self_loader import relocated_segments,segments
SAVE,WAR,INPUT,MGR,HEADER,SCORE,LIVE,CACHED=[0x2000000+i*0x100000 for i in range(8)]
STOP,STACK=0x2fff000,0x2ff0000
regs=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3]
def put(u,p,v):u.mem_write(p,struct.pack('<I',v))
def get(u,p):return struct.unpack('<I',u.mem_read(p,4))[0]
def machine(binary):
 u=Uc(UC_ARCH_ARM,UC_MODE_THUMB);u.reg_write(UC_ARM_REG_C1_C0_2,0xf00000);u.reg_write(UC_ARM_REG_FPEXC,0x40000000);u.mem_map(0x81000000,0x800000);u.mem_map(0x2000000,0x1000000)
 for i,data in relocated_segments(binary).items():u.mem_write(segments(binary)[i]['va'],bytes(data))
 for g,v in [(0x81499b64,SAVE),(0x81499c00,WAR),(0x81499bf0,MGR),(0x81499c38,MGR)]:put(u,g,v)
 put(u,WAR+0x13df0,SCORE);put(u,WAR+0x13de4,LIVE);put(u,WAR+0x13de0,CACHED)
 return u

def returning(u,v=0):u.reg_write(UC_ARM_REG_R0,v);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
def run(u,a,args=(),hook=None):
 u.reg_write(UC_ARM_REG_SP,STACK);u.reg_write(UC_ARM_REG_LR,STOP|1)
 for r,v in zip(regs,args):u.reg_write(r,v)
 def callback(u,pc,size,data):
  if pc==STOP:u.emu_stop()
  elif pc in (0x810897b8,0x810897bc):returning(u)
  elif hook:hook(u,pc)
 h=u.hook_add(UC_HOOK_CODE,callback)
 try:u.emu_start(a|1,STOP,count=2000000)
 except Exception:
  print("Native failure",hex(u.reg_read(UC_ARM_REG_PC)),[hex(u.reg_read(r))for r in regs]+[hex(u.reg_read(UC_ARM_REG_LR))]);raise
 finally:u.hook_del(h)
 assert u.reg_read(UC_ARM_REG_PC)==STOP,hex(u.reg_read(UC_ARM_REG_PC))
 return u.reg_read(UC_ARM_REG_R0)

