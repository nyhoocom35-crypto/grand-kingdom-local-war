from pathlib import Path
import sys,struct,json,hashlib
sys.path.insert(0,'analysis/re24')
from import_loader import bindings,fully_loaded
import os
mode=os.environ.get('GK38_MODE','growth8')
blob=Path(f'analysis/re37/{mode}38.bin').read_bytes()
assert hashlib.sha256(blob).hexdigest()==next(r['patched_sha256'] for r in json.loads(Path('analysis/re37/MERIT38_BUILD.json').read_text()) if r['mode']==mode)
exports={nid:0x125000+4*i for i,nid in enumerate(sorted({r['nid'] for r in bindings(blob)}))}
segments,addresses,normal,imports=fully_loaded(blob,exports)
prefix=Path('analysis/re17/probe_actual.py').read_text().split('for p in sorted(Path(')[0]
prefix=prefix.replace('g=FastGame();','g=FastGame();\nfor idx,segment in _loaded.items(): g.u.mem_write(_addresses[idx],bytes(segment))\n')
scope={'_loaded':segments,'_addresses':addresses};exec(prefix,scope)
g=scope['g'];base=scope['base'];data=scope['data'];args=scope['args'];war=scope['war'];save=scope['save'];cached=save+0x8d2d0
for addr in exports.values():g.put(addr,0xa1b2c3d4)
g.custom[0x810471d0]=lambda r:0;g.custom[0x810471ea]=lambda r:0
valid={21:0x81066cee,23:0x810678ae,24:0x81067e2c,28:0x81068abc,31:0x81068c9a,34:0x81069126}
def apply(path,api):
    f=path.read_bytes();slot=base+44*api
    g.put(slot+12,data);g.put(slot+20,len(f));g.u.mem_write(data,f);g.u.mem_write(args,struct.pack('<II',api,len(f)))
    g.call(0x8107b5f6,base,args)
    assert struct.unpack('<III',g.u.mem_read(slot+36,12))==(3,0,0),(path,'native decrypt/parser')
    assert g.call(valid[api],data)==1,(path,'native validator')
    handler=g.get(0x8146a8e4+api*24+4)
    g.put(slot+0x30,0);g.put(0x700000,handler)
    assert g.call(0x8107b0e6,base,api,0x171000,valid[api]|1)==1,(path,'completion')
    assert g.get(0x171000)==1
    return bytes(g.u.mem_read(data,len(f)-900))
world=Path('analysis/params_temp/WORLDPARAMETER.DAT').read_bytes()
g.put(0x81499bf0,0x630000);g.put(0x63001c,0x630100);g.put(0x630108,0x631000);g.put(0x63010c,119);g.u.mem_write(0x631000,world[652:])
g.put(0x81499bc8,0x680000);g.u.mem_write(0x680056,b'\x0a')
g.custom[0x8109101e]=lambda r:war+0x13dcc
