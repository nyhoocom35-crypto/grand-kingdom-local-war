"""Rebuild revision46 from the owner's SELF and revision45 recipes.

The HUD bar now measures the same structures as its adjacent structure count;
the troop population used by operation completion remains separate.
Rewards, experience and merit multipliers are preserved unchanged.
"""
import json, struct, sys
from pathlib import Path
from build_shop43 import asm, patches, diff, sha

def helpers(start):
    code = asm('''
current_hp:
 movs r2,#0x20
 b aggregate
maximum_hp:
 movs r2,#0x28
aggregate:
 push {r4,r5,r6,lr}
 mov r4,r1
 mov r5,r2
 movw r0,#0x9c00
 movt r0,#0x8149
 ldr r0,[r0]
 bl 0x81060b64
 adds r0,#0x64
 movs r1,#32
 movs r2,#0
loop:
 ldrh r3,[r0,#4]
 cbz r3,skip
 ldr r3,[r0,#0xc]
 cmp r3,r4
 bne skip
 ldr r3,[r0,r5]
 adds r2,r2,r3
skip:
 adds r0,#0x2c
 subs r1,#1
 bne loop
 mov r0,r2
 pop {r4,r5,r6,pc}
count_alive:
 ldrh r1,[r0,#4]
 cmp r1,#0
 beq count_skip
 ldr r1,[r0,#0x20]
 cmp r1,#0
 bne count_keep
count_skip:
 b.w 0x8121cbf4
count_keep:
 b.w 0x8121cbea
''', start)
    count = start + code.index(asm('ldrh r1,[r0,#4];cmp r1,#0',0))
    return code, start+4, count

def build(original, release, out):
    prepared=bytearray(original);host=b'kx01-prd-9bnapb338aimcuzl.elasticbeanstalk.com'
    assert prepared[0x46d180:0x46d180+len(host)]==host
    prepared[0x46d180:0x46d180+len(host)]=b'127.0.0.1'+bytes(len(host)-9)
    prior={};current={}
    for mode,m in release['modes'].items():
        f=m['fresh'];assert sha(prepared)==f['source_sha256'];c=f['clone_code']
        b=patches(prepared,f['patches']);b+=patches(b[c['offset']:c['offset']+c['length']],c['patches'])+bytes.fromhex(c['suffix_hex'])
        assert sha(b)==m['patched_sha256'];current[mode]=b;prior[sha(b)]=b
        for v in m['variants']:
            src=patches(b[:v['source_length']],v['patches'],True)
            assert sha(src)==v['source_sha256'];prior[sha(src)]=src
    targets={};records=[]
    for mode,b in current.items():
        t=bytearray(b);ph=struct.unpack_from('<Q',b,0x48)[0];si=struct.unpack_from('<Q',b,0x58)[0]
        fileoff=struct.unpack_from('<Q',b,si)[0];size=struct.unpack_from('<I',b,ph+16)[0]
        assert fileoff+size==len(b)
        code, maximum, count=helpers(0x81000000+size)
        assert 0x81000000+size+len(code)<=0x81498000
        edits=[(0x8121cbe6,asm(f'b.w {hex(count)}',0x8121cbe6))]
        for va,dest in [(0x81225ab2,maximum),(0x81225ac4,0x81000000+size),(0x81225ae0,0x81000000+size),(0x81225aea,maximum)]:
            edits.append((va,asm(f'bl {hex(dest)}',va)))
        for va,op in edits:
            for offset in (0x10e0+va-0x81000000,fileoff+va-0x81000000):t[offset:offset+len(op)]=op
        t+=code
        struct.pack_into('<I',t,ph+16,size+len(code));struct.pack_into('<I',t,ph+20,size+len(code));struct.pack_into('<Q',t,si+8,size+len(code))
        struct.pack_into('<Q',t,0x20,len(t));struct.pack_into('<Q',t,0x18,struct.unpack_from('<Q',b,0x18)[0]+len(code))
        m=release['modes'][mode];f=m['fresh'];c=f['clone_code']
        f['patches']=diff(prepared,t[:len(prepared)])
        c['patches']=diff(t[c['offset']:c['offset']+c['length']],t[fileoff:fileoff+c['length']])
        c['suffix_hex']=t[fileoff+c['length']:].hex()
        assert len(bytes.fromhex(c['suffix_hex']))<=4096
        m['patched_sha256']=sha(t)
        m['variants']=[dict(source_sha256=h,source_length=len(src),patches=diff(src,t[:len(src)]),append_hex=t[len(src):].hex()) for h,src in prior.items()]
        m['variants'].append(dict(source_sha256=sha(t),source_length=len(t),patches=[],append_hex=''))
        release['supported_prior_modes'][sha(t)]=mode
        targets[mode]=t;(out/f'{mode}46.bin').write_bytes(t)
        records.append(dict(mode=mode,current_hp=hex(0x81000000+size),maximum_hp=hex(maximum),count_alive=hex(count),code_bytes=len(code),sha256=sha(t)))
    for mode,t in targets.items():
        for other,src in targets.items():
            if mode!=other:release['modes'][mode]['variants'].append(dict(source_sha256=sha(src),source_length=len(src),patches=diff(src,t),append_hex=''))
    release.update(release='1.12',native_client_base=46,hud_revision=46,rewards_unchanged=True,secret_reward_implemented=True, rival_revision=46, secret_reward_revision=46)
    (out/'release46.json').write_text(json.dumps(release,indent=2))
    (out/'HUD46_BUILD.json').write_text(json.dumps(records,indent=2))
    return records
if __name__=='__main__':
    out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
    print(json.dumps(build(Path(sys.argv[1]).read_bytes(),json.loads(Path(sys.argv[2]).read_text()),out),indent=2))
