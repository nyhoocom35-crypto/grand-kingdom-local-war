"""Build shop-cache revision 43 from verified client-38 installer recipes.

Requires the owner's decrypted Japanese 1.06 SELF; never distributes game data.
Usage: python build_shop43.py OWN_SELF RELEASE38_JSON OUTPUT_DIRECTORY
"""
import hashlib, json, struct, sys
from pathlib import Path
from keystone import Ks, KS_ARCH_ARM, KS_MODE_THUMB

ks = Ks(KS_ARCH_ARM, KS_MODE_THUMB)
sha = lambda b: hashlib.sha256(b).hexdigest()
def asm(s, a): return bytes(ks.asm(s, a)[0])
def patches(b, ps, reverse=False):
    b = bytearray(b)
    for p in ps:
        x, y = p['before'], p['after']
        if reverse: x, y = y, x
        x, y = bytes.fromhex(x), bytes.fromhex(y); o = p['offset']
        assert b[o:o+len(x)] == x, hex(o)
        b[o:o+len(x)] = y
    return b
def diff(a, b):
    result=[]; i=0
    while i<len(a):
        if a[i]==b[i]: i+=1; continue
        j=i+1
        while j<len(a) and a[j]!=b[j]: j+=1
        result.append(dict(offset=i,before=a[i:j].hex(),after=b[i:j].hex())); i=j
    return result

def helper(start, state=0x814b4c18):
    # A separate 20-byte identity per nation stores exactly the native shop
    # descriptor (nation, war ID, global seed, national seed, four counts).
    # Repeated snapshots do not restock purchased goods. No save fields reused.
    def code(state):
        return asm(f'''
snapshot:
 push.w {{r1,r2,r3,r4,r5,r6,r7,r8,r12,lr}}
 sub sp,#24
 mov r6,r4
 add.w r6,r6,#0x480
 movs r7,#0
snap_loop:
 str r7,[sp]
 ldr.w r1,[r6,#0x1c0]
 str r1,[sp,#4]
 ldr.w r1,[r6,#0x1bc]
 str r1,[sp,#8]
 movs r1,#48
 mla r8,r7,r1,r6
 ldr.w r1,[r8,#0xac]
 str r1,[sp,#12]
 ldr.w r1,[r8,#0xb0]
 str r1,[sp,#16]
 mov r0,sp
 bl sync_country
 adds r7,#1
 cmp r7,#4
 blo snap_loop
 add sp,#24
 pop.w {{r1,r2,r3,r4,r5,r6,r7,r8,r12,lr}}
 movw r0,#0x9c00
 bx lr
barrack_wrapper:
 push {{r4,lr}}
 mov r4,r0
 bl original_barrack
 mov r0,r4
 bl barrack_stock
 pop {{r4,pc}}
original_barrack:
 push.w {{r4,r5,r6,r7,r8,r9,r10,r11,lr}}
 b.w 0x81064560
barrack_stock:
 push.w {{r4,r5,r6,r7,r8,lr}}
 sub sp,#24
 mov r6,r0
 movw r0,#0x9c00
 movt r0,#0x8149
 ldr r8,[r0]
 cmp r8,#0
 beq barrack_done
 ldr r1,[r8]
 cmp r1,#0
 beq barrack_done
 movs r7,#0
barrack_loop:
 str r7,[sp]
 ldr.w r1,[r6,#0x12c]
 str r1,[sp,#4]
 ldr.w r1,[r8,#0x548]
 str r1,[sp,#8]
 movw r0,#{state & 65535}
 movt r0,#{state >> 16}
 movs r1,#20
 mla r0,r7,r1,r0
 ldr r1,[r0,#12]
 cmp r1,#0
 it eq
 moveq r1,#1
 str r1,[sp,#12]
 add.w r0,r6,r7,lsl #2
 ldr.w r1,[r0,#0x11c]
 str r1,[sp,#16]
 mov r0,sp
 bl sync_country
 adds r7,#1
 cmp r7,#4
 blo barrack_loop
barrack_done:
 add sp,#24
 pop.w {{r4,r5,r6,r7,r8,pc}}
sync_country:
 push.w {{r4,r5,r6,r7,r8,lr}}
 mov r4,r0
 movw r0,#0x9c00
 movt r0,#0x8149
 ldr r5,[r0]
 cmp r5,#0
 beq sync_done
 movw r0,#0x9b64
 movt r0,#0x8149
 ldr r6,[r0]
 cmp r6,#0
 beq sync_done
 ldr r7,[r4]
 movw r0,#0x4ce8
 mla r5,r7,r0,r5
 add.w r5,r5,#0x550
 movw r0,#0x7900
 movt r0,#2
 add r6,r0
 movw r0,#0x6280
 mla r6,r7,r0,r6
 movw r8,#{state & 65535}
 movt r8,#{state >> 16}
 movs r0,#20
 mla r8,r7,r0,r8
 movs r3,#0
compare:
 ldr r0,[r4,r3]
 ldr r1,[r8,r3]
 cmp r0,r1
 bne refresh
 adds r3,#4
 cmp r3,#20
 blo compare
 b sync_done
refresh:
 movs r0,#0
 mov r1,r4
 add.w r2,r5,#12
 bl 0x81091a98
 add.w r0,r6,#0x118
 add.w r1,r5,#12
 movw r2,#0x4c00
 bl 0x810472ac
 mov r0,r8
 mov r1,r4
 movs r2,#20
 bl 0x810472ac
sync_done:
 pop.w {{r4,r5,r6,r7,r8,pc}}
''',start)
    binary=code(state)
    # Keep client41 length for in-place upgrades. These padding bytes are RX;
    # all mutable identity data lives in the declared RW BSS extension.
    binary += bytes((-len(binary))%4)+bytes(80)
    # Find wrapper from its unique push/mov prefix; addresses stay mode-specific.
    wrapper=start+binary.index(asm('push {r4,lr};mov r4,r0',0))
    return binary,wrapper,state

def build(original, old, out):
    prepared=bytearray(original); host=b'kx01-prd-9bnapb338aimcuzl.elasticbeanstalk.com'
    assert prepared[0x46d180:0x46d180+len(host)]==host
    prepared[0x46d180:0x46d180+len(host)]=b'127.0.0.1'+bytes(len(host)-9)
    prior={}; current={}
    for mode,m in old['modes'].items():
        f=m['fresh']; assert sha(prepared)==f['source_sha256']
        base=patches(prepared,f['patches']); c=f['clone_code']
        clone=patches(base[c['offset']:c['offset']+c['length']],c['patches'])
        b=base+clone+bytes.fromhex(c['suffix_hex']); assert sha(b)==m['patched_sha256']
        current[mode]=b; prior[sha(b)]=b
        for v in m['variants']:
            src=patches(b[:v['source_length']],v['patches'],True)
            assert sha(src)==v['source_sha256']; prior[sha(src)]=src
    release=json.loads(json.dumps(old)); records=[]; targets={}
    for revision in (41,42):
        known=json.loads((Path(__file__).parent/f'RELEASE{revision}_BUILD_INPUT.json').read_text())
        for mode,m in known['modes'].items():
            f=m['fresh'];base=patches(prepared,f['patches']);c=f['clone_code']
            src=base+patches(base[c['offset']:c['offset']+c['length']],c['patches'])+bytes.fromhex(c['suffix_hex'])
            assert sha(src)==m['patched_sha256'];prior[sha(src)]=src
            release['supported_prior_modes'][sha(src)]=mode
    for mode,b in current.items():
        target=bytearray(b); ph=struct.unpack_from('<Q',b,0x48)[0]; si=struct.unpack_from('<Q',b,0x58)[0]
        fileoff=struct.unpack_from('<Q',b,si)[0]; size=struct.unpack_from('<I',b,ph+16)[0]
        assert fileoff+size==len(b)
        code,wrapper,state=helper(0x81000000+size)
        hooks=[(0x8108b972,asm(f'bl {hex(0x81000000+size)}',0x8108b972)),
               (0x8106455c,asm(f'b.w {hex(wrapper)}',0x8106455c))]
        for va,op in hooks:
            assert len(op)==4
            for offset in (va-0x81000000+0x10e0,fileoff+va-0x81000000): target[offset:offset+4]=op
        target+=code
        struct.pack_into('<I',target,ph+16,size+len(code)); struct.pack_into('<I',target,ph+20,size+len(code));struct.pack_into('<Q',target,si+8,size+len(code))
        # Extend only the original RW BSS, keeping every existing global address.
        # Executable memory never contains mutable shop state.
        struct.pack_into('<I',target,ph+24,5)
        assert struct.unpack_from('<II',b,ph+32+8)[0]==0x81498000
        assert struct.unpack_from('<I',b,ph+32+20)[0]==0x1cc18
        struct.pack_into('<I',target,ph+32+20,0x1cc68)
        struct.pack_into('<Q',target,0x20,len(target));struct.pack_into('<Q',target,0x18,struct.unpack_from('<Q',b,0x18)[0]+len(code))
        assert 0x81000000+size+len(code)<0x81498000
        # The inherited MOVW relocation at 8108b972 overwrites the new BL.
        # Disable only its low-half write. Keep the paired MOVT at 8108b976.
        # The next record is format0, so relocation state is reset immediately.
        from self_loader import relocations
        relocs=relocations(target)
        affected=[r for r in relocs if r['patchseg']==0 and r['offset']==0x8b972]
        assert len(affected)==1 and affected[0]['format']==0 and affected[0]['code']==47
        record=affected[0]['record']
        word=struct.unpack_from('<I',target,record)[0]
        assert ((word>>20)&255)==48 and ((word>>28)&15)*2==4
        assert struct.unpack_from('<I',target,record+12)[0]&15==0
        struct.pack_into('<I',target,record,word&~0xff00)
        f=release['modes'][mode]['fresh']; c=f['clone_code']
        f['patches']=diff(prepared,target[:len(prepared)])
        clonebase=target[c['offset']:c['offset']+c['length']]
        actualclone=target[fileoff:fileoff+c['length']]
        c['patches']=diff(clonebase,actualclone)
        c['suffix_hex']=target[fileoff+c['length']:].hex()
        assert len(bytes.fromhex(c['suffix_hex']))<=4096
        m=release['modes'][mode];m['patched_sha256']=sha(target)
        m['variants']=[dict(source_sha256=h,source_length=len(src),patches=diff(src,target[:len(src)]),append_hex=target[len(src):].hex())for h,src in prior.items()]
        m['variants'].append(dict(source_sha256=sha(target),source_length=len(target),patches=[],append_hex=''))
        (out/f'{mode}43.bin').write_bytes(target)
        targets[mode]=target
        release['supported_prior_modes'][sha(target)]=mode
        records.append(dict(mode=mode,sha256=sha(target),helper=hex(0x81000000+size),wrapper=hex(wrapper),state=hex(state),extra_bytes=len(code)))
    for mode,target in targets.items():
        for other,src in targets.items():
            if other!=mode:
                release['modes'][mode]['variants'].append(dict(source_sha256=sha(src),source_length=len(src),patches=diff(src,target),append_hex=''))
    release.update(release='1.9',native_client_base=43,shop_revision=43)
    (out/'release43.json').write_text(json.dumps(release,indent=2))
    (out/'SHOP43_BUILD.json').write_text(json.dumps(records,indent=2))
    return records
if __name__=='__main__':
    out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
    print(json.dumps(build(Path(sys.argv[1]).read_bytes(),json.loads(Path(sys.argv[2]).read_text()),out),indent=2))
