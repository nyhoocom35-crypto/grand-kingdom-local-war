"""Replay revision45 with all SELF segment relocations applied.
Usage: verify_battle45.py OWN_SELF CLIENT45_DIRECTORY
OS and scene allocation are modeled; this is not a live Vita3K graphics test.
"""
import json,struct,sys
from pathlib import Path
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_HOOK_CODE
from unicorn.arm_const import *
from self_loader import relocated_segments,segments
from build_shop43 import patches,sha

root=Path(sys.argv[2]);release=json.loads((root/'release45.json').read_text())
own=bytearray(Path(sys.argv[1]).read_bytes());host=b'kx01-prd-9bnapb338aimcuzl.elasticbeanstalk.com';own[0x46d180:0x46d180+len(host)]=b'127.0.0.1'+bytes(len(host)-9)
SAVE,WAR,INPUT,MGR,HEADER,SCORE,LIVE,CACHED=[0x2000000+i*0x100000 for i in range(8)]
STOP,STACK=0x2fff000,0x2ff0000
regs=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3]
def put(u,p,v):u.mem_write(p,struct.pack('<I',v))
def get(u,p):return struct.unpack('<I',u.mem_read(p,4))[0]
def machine(binary):
 u=Uc(UC_ARCH_ARM,UC_MODE_THUMB);u.reg_write(UC_ARM_REG_C1_C0_2,0xf00000);u.reg_write(UC_ARM_REG_FPEXC,0x40000000);u.mem_map(0x81000000,0x800000);u.mem_map(0x2000000,0x1000000)
 for i,data in relocated_segments(binary).items():u.mem_write(segments(binary)[i]['va'],bytes(data))
 for g,v in [(0x81499b64,SAVE),(0x81499c00,WAR),(0x81499bf0,MGR),(0x81499c38,MGR)]:put(u,g,v)
 put(u,WAR+0x13df0,SCORE);put(u,WAR+0x13de4,LIVE);put(u,WAR+0x13de0,CACHED)
 return u

def returning(u,v=0):u.reg_write(UC_ARM_REG_R0,v);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
def run(u,a,args=(),hook=None):
 u.reg_write(UC_ARM_REG_SP,STACK);u.reg_write(UC_ARM_REG_LR,STOP|1)
 for r,v in zip(regs,args):u.reg_write(r,v)
 def callback(u,pc,size,data):
  if pc==STOP:u.emu_stop()
  elif pc in (0x810897b8,0x810897bc):returning(u)
  elif hook:hook(u,pc)
 h=u.hook_add(UC_HOOK_CODE,callback)
 try:u.emu_start(a|1,STOP,count=2000000)
 finally:u.hook_del(h)
 assert u.reg_read(UC_ARM_REG_PC)==STOP,hex(u.reg_read(UC_ARM_REG_PC))
 return u.reg_read(UC_ARM_REG_R0)

report=dict(recipes=0,contract_cases=0,native_rank_callbacks=0,native_population_cases=0,native_siege_hp_cases=0,actual_vita3k_verified=False)
for mode,m in release['modes'].items():
 binary=(root/f'{mode}45.bin').read_bytes();assert sha(binary)==m['patched_sha256']
 f=m['fresh'];c=f['clone_code'];base=patches(own,f['patches'])
 assert base+patches(base[c['offset']:c['offset']+c['length']],c['patches'])+bytes.fromhex(c['suffix_hex'])==binary
 for v in m['variants']:
  src=patches(binary[:v['source_length']],v['patches'],True);assert sha(src)==v['source_sha256']
  assert patches(src,v['patches'])+bytes.fromhex(v['append_hex'])==binary;report['recipes']+=1
 memory=relocated_segments(binary);raw=binary[segments(binary)[0]['off']:]
 for a,b in [(0x89e06,0x89e0a),(0x89ece,0x89ed2),(0x497ef4,segments(binary)[0]['size'])]:assert memory[0][a:b]==raw[a:b]
 # These original functions execute THROUGH the patched and relocated branches.
 u=machine(binary)
 for count in (1,3,5):
  for elapsed in range(count+2):
   for round in range(6):
    put(u,SAVE+0x26880,0);put(u,SAVE+0x26884,count)
    put(u,SAVE+0x2687c,0x40000000|((93+count)<<3))
    put(u,SAVE+0x8d2d0,0x40000000|((93+elapsed)<<3)|round)
    run(u,0x81089ece)
    assert get(u,SAVE+0x26888)==max(0,count-elapsed),(mode,count,elapsed,round)
    assert run(u,0x81089e06)==int(elapsed>=count)
    report['contract_cases']+=1
 put(u,SAVE+0x26880,4);run(u,0x81089ece);assert get(u,SAVE+0x26888)==0 and run(u,0x81089e06)==0
 put(u,SAVE+0x26880,0);put(u,SAVE+0x8d2d0,0);run(u,0x81089ece);assert get(u,SAVE+0x26888)==5 and run(u,0x81089e06)==0
 # Original rank callbacks update the native score object and rank getter.
 for rank in range(7):
  u.mem_write(INPUT,bytes(0x8c)+bytes([rank]*3)+bytes(100))
  run(u,0x810690a8,[INPUT])
  for metric in range(3):assert run(u,0x8106355c,[WAR,metric])==rank
  report['native_rank_callbacks']+=1
 # Native RegisterBattle builder serializes independent stage victory flags.
 put(u,WAR+0x13dcc,0);put(u,WAR+0x13f40,2);put(u,WAR+0x13f44,14)
 put(u,WAR+0x13f50,0);put(u,WAR+0x13f58,11);put(u,WAR+0x13f8c,5)
 for k,v in enumerate([1,1,1,0,0]):put(u,WAR+0x13f5c+4*k,v)
 def builder_hook(u,pc):
  if pc==0x81063432:returning(u,9)
  elif pc==0x810634ac:
   u.mem_write(u.reg_read(UC_ARM_REG_R2),b'\x05');u.mem_write(u.reg_read(UC_ARM_REG_R3),b'\x05');returning(u)
  elif pc==0x810634ec:
   u.mem_write(u.reg_read(UC_ARM_REG_R2),b'\x05');u.mem_write(u.reg_read(UC_ARM_REG_R3),b'\x05');returning(u)
  elif pc==0x81063414:returning(u,0)
 run(u,0x81068e3a,[INPUT],builder_hook)
 req=bytes(u.mem_read(INPUT,224));assert req[0xa5]==0 and list(req[0xc5:0xca])==[1,1,1,0,0]
 # Original GetStrategyData completion consumes all six rank histograms.
 q=(root/'fixtures/strategy45.plain').read_bytes();u.mem_write(INPUT,q)
 def snapshot_hook(u,pc):
  if pc==0x81067cb2:u.reg_write(UC_ARM_REG_PC,STOP|1)
  elif pc==0x81060b58:returning(u,MGR)
  elif pc==0x810626c4:returning(u,HEADER)
  elif pc==0x810624d2:returning(u,u.reg_read(UC_ARM_REG_R1))
  elif pc in (0x810a6d86,0x810a6d7a,0x810a742a,0x810a6d8e,0x810a6e76,0x810a745e,0x810608e0):returning(u)
 run(u,0x81067980,[INPUT],snapshot_hook)
 run(u,0x810a7c4a,[CACHED,LIVE])
 for side in range(2):
  for metric in range(3):
   for rank in range(8):
    want=struct.unpack_from('<I',q,0x98+side*0xb4+0x54+metric*32+rank*4)[0]
    assert run(u,0x810628c8,[WAR,side,metric,rank])==want
    report['native_population_cases']+=1
 # Verify HP after native descriptor construction, including the destroy flag.
 for filename,hp in [('siege45_partial.plain',400),('siege45_destroyed.plain',0)]:
  q=(root/'fixtures'/filename).read_bytes();u.mem_write(INPUT,q);descriptors=[]
  def hp_hook(u,pc):
   if pc==0x81067aae:u.reg_write(UC_ARM_REG_PC,STOP|1)
   elif pc==0x81060b58:returning(u,MGR)
   elif pc==0x810626c4:returning(u,HEADER)
   elif pc==0x810624d2:returning(u,u.reg_read(UC_ARM_REG_R1))
   elif pc in (0x810a6d86,0x810a6d7a):returning(u)
   elif pc in (0x810a742a,0x810a6d8e,0x810a6e76,0x810a745e):
    p=u.reg_read(UC_ARM_REG_R1 if pc==0x810a6d8e else UC_ARM_REG_R2)
    descriptors.append(bytes(u.mem_read(p,44)));returning(u)
  run(u,0x81067980,[INPUT],hp_hook)
  hq=[d for d in descriptors if struct.unpack_from('<I',d,8)[0]==0 and struct.unpack_from('<I',d,12)[0]==1]
  assert len(hq)==1 and struct.unpack_from('<I',hq[0],32)[0]==hp,(filename,hq)
  report['native_siege_hp_cases']+=1
print(json.dumps(report,indent=2))
