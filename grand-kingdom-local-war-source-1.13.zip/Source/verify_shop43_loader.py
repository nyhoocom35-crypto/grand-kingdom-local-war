"""Verify revision43 fresh/upgrade recipes and reproduce revision42 loader fault.

Usage: verify_shop43_loader.py OWN_SELF CLIENT42_DIR CLIENT43_DIR
Private game binaries are never included in the distribution.
"""
import json,struct,sys
from pathlib import Path
from capstone import Cs,CS_ARCH_ARM,CS_MODE_THUMB
from build_shop43 import patches,sha
from self_loader import relocations,relocated_segments,segments

own=bytearray(Path(sys.argv[1]).read_bytes());old=Path(sys.argv[2]);new=Path(sys.argv[3])
host=b'kx01-prd-9bnapb338aimcuzl.elasticbeanstalk.com'
assert own[0x46d180:0x46d180+len(host)]==host
own[0x46d180:0x46d180+len(host)]=b'127.0.0.1'+bytes(len(host)-9)
release=json.loads((new/'release43.json').read_text());cs=Cs(CS_ARCH_ARM,CS_MODE_THUMB)
checked=0
for mode,m in release['modes'].items():
    target=(new/f'{mode}43.bin').read_bytes();previous=(old/f'{mode}42.bin').read_bytes()
    assert sha(target)==m['patched_sha256']
    assert len(target)==len(previous)
    byte_diff=[i for i,(a,b) in enumerate(zip(previous,target)) if a!=b]
    assert len(byte_diff)==1,byte_diff
    records=relocations(previous)
    r=next(r for r in records if r['patchseg']==0 and r['offset']==0x8b972)
    assert byte_diff==[r['record']+1] and previous[byte_diff[0]]==47 and target[byte_diff[0]]==0
    before=relocated_segments(previous);after=relocated_segments(target)
    assert before[1]==after[1]
    assert before[0][:0x8b972]==after[0][:0x8b972] and before[0][0x8b976:]==after[0][0x8b976:]
    bad=list(cs.disasm(bytes(before[0][0x8b972:0x8b976]),0x8108b972))[0]
    good=list(cs.disasm(bytes(after[0][0x8b972:0x8b976]),0x8108b972))[0]
    assert bad.mnemonic=='blx' and bad.op_str=='#0x80094b74'
    assert good.mnemonic=='bl' and good.op_str=='#0x81497d50'
    ss=segments(target);code=target[ss[0]['off']:ss[0]['off']+ss[0]['size']]
    for start,end in [(0x6455c,0x64560),(0x497d50,0x497ef4)]:assert after[0][start:end]==code[start:end]
    f=m['fresh'];assert sha(own)==f['source_sha256']
    base=patches(own,f['patches']);c=f['clone_code']
    fresh=base+patches(base[c['offset']:c['offset']+c['length']],c['patches'])+bytes.fromhex(c['suffix_hex'])
    assert fresh==target
    for v in m['variants']:
        src=patches(target[:v['source_length']],v['patches'],True)
        assert sha(src)==v['source_sha256']
        upgraded=patches(src,v['patches'])+bytes.fromhex(v['append_hex'])
        assert upgraded==target
        checked+=1
print(json.dumps(dict(fresh_modes_checked=2,upgrade_and_switch_recipes_checked=checked,
    client42_fault_after_segment_relocation='BLX 80094b74',client43_correct_loaded_call='BL 81497d50',
    only_one_relocation_byte_changed_per_mode=True,paired_MOVT_preserved=True,
    every_unrelated_segment_relocation_preserved=True,all_new_hooks_and_helper_intact_after_loading=True,
    all_before_bytes_and_output_SHA256_verified=True,actual_vita3k_verified=False),indent=2))
