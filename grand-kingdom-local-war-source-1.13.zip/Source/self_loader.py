"""Decode SCE relocation streams using Vita3K kernel/src/relocation.cpp formats.

Relocation records retain their source byte offsets for patch-site audits.
"""
import struct

def segments(blob):
    ph=struct.unpack_from('<Q',blob,0x48)[0]
    si=struct.unpack_from('<Q',blob,0x58)[0]
    # This owner's decrypted SELF has four program headers.
    return [dict(index=i,type=struct.unpack_from('<I',blob,ph+i*32)[0],
                 va=struct.unpack_from('<I',blob,ph+i*32+8)[0],
                 memsz=struct.unpack_from('<I',blob,ph+i*32+20)[0],
                 off=struct.unpack_from('<Q',blob,si+i*32)[0],
                 size=struct.unpack_from('<Q',blob,si+i*32+8)[0]) for i in range(4)]

def relocations(blob):
    out=[]
    for seg in segments(blob):
        if seg['type']!=0x60000000:continue
        pos,end=seg['off'],seg['off']+seg['size']
        offset=patchseg=symseg=addend=code=code2=0
        def emit(c,o):
            out.append(dict(record=pos,format=fmt,patchseg=patchseg,offset=o,
                            symseg=symseg,addend=addend,code=c))
        while pos<end:
            w=struct.unpack_from('<I',blob,pos)[0];fmt=w&15
            n=12 if fmt==0 else 8 if fmt in (1,2,3) else 4
            if fmt==0:
                symseg=(w>>4)&15;code=(w>>8)&255;patchseg=(w>>16)&15
                code2=(w>>20)&255;addend,offset=struct.unpack_from('<II',blob,pos+4)
                emit(code,offset)
                if code2:emit(code2,offset+((w>>28)&15)*2)
            elif fmt==1:
                v=struct.unpack_from('<I',blob,pos+4)[0]
                symseg=(w>>4)&15;code=(w>>8)&255;patchseg=(w>>16)&15
                offset=(w>>20)|((v&1023)<<12);addend=v>>10;code2=0;emit(code,offset)
            elif fmt==2:
                symseg=(w>>4)&15;code=(w>>8)&255;offset+=w>>16
                addend=struct.unpack_from('<I',blob,pos+4)[0];code2=0;emit(code,offset)
            elif fmt==3:
                symseg=(w>>4)&15;code=47 if (w>>8)&1 else 43;code2=code+1
                offset+=(w>>9)&0x3ffff;addend=struct.unpack_from('<I',blob,pos+4)[0]&0x3fffff
                emit(code,offset);emit(code2,offset+(w>>27))
            elif fmt==4:
                offset+=(w>>4)&0x7fffff;emit(code,offset);emit(code2,offset+(w>>27))
            elif fmt==5:
                offset+=(w>>4)&511;emit(code,offset);emit(code2,offset+((w>>13)&31))
                offset+=(w>>18)&511;emit(code,offset);emit(code2,offset+(w>>27))
            elif fmt in (6,7,8,9):
                deltas=[]
                if fmt==6:deltas=[w>>4]
                else:
                    bits={7:7,8:4,9:2}[fmt];v=w>>4
                    while True:
                        deltas.append((v&((1<<bits)-1))*4);v>>=bits
                        if not v:break
                code=2;code2=0
                for delta in deltas:offset+=delta;emit(code,offset)
            else:raise ValueError((hex(pos),fmt))
            pos+=n
        assert pos==end
    return out

def relocated_segments(blob):
    segs=segments(blob);memory={s['index']:bytearray(blob[s['off']:s['off']+s['size']])+bytearray(max(0,s['memsz']-s['size'])) for s in segs if s['type']==1}
    for r in relocations(blob):
        c=r['code'];p=r['offset'];s=memory[r['patchseg']]
        if c in (0,40,255):continue
        addr=segs[r['patchseg']]['va']+p
        val=((segs[r['symseg']]['va'] if r['symseg']!=15 else 0)+r['addend'])&0xffffffff
        if r['format']>=6:continue # preferred-address Abs32 is unchanged
        if c in (3,41,42,10,28,29):val=(val-addr)&0xffffffff
        if c in (2,38,3,41,42):struct.pack_into('<I',s,p,val& (0x7fffffff if c==42 else 0xffffffff))
        elif c==8:s[p]=val&255
        elif c in (47,48):
            if c==48:val>>=16
            a,b=struct.unpack_from('<HH',s,p)
            a=(a&~0x40f)|((val>>12)&15)|(((val>>11)&1)<<10)
            b=(b&~0x70ff)|(val&255)|(((val>>8)&7)<<12)
            struct.pack_into('<HH',s,p,a,b)
        elif c in (43,44):
            if c==44:val>>=16
            v=struct.unpack_from('<I',s,p)[0];struct.pack_into('<I',s,p,(v&~0xf0fff)|(val&4095)|(((val>>12)&15)<<16))
        elif c in (28,29):
            v=struct.unpack_from('<I',s,p)[0];struct.pack_into('<I',s,p,(v&0xff000000)|((val>>2)&0xffffff))
        elif c==10:
            a,b=struct.unpack_from('<HH',s,p);sign=(val>>24)&1
            a=(a&~0x7ff)|((val>>12)&1023)|(sign<<10)
            b=(b&~0x2fff)|((val>>1)&2047)|((sign^((~val>>22)&1))<<11)|((sign^((~val>>23)&1))<<13)
            struct.pack_into('<HH',s,p,a,b)
        else:raise ValueError(c)
    return memory
