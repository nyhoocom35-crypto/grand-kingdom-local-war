from pathlib import Path
import sys,struct,json,hashlib
from keystone import Ks,KS_ARCH_ARM,KS_MODE_THUMB
sys.path.insert(0,'analysis/re24');from import_loader import headers,bindings
sys.path.insert(0,'analysis/re23');from self_loader import relocations
ks=Ks(KS_ARCH_ARM,KS_MODE_THUMB)
sha=lambda b:hashlib.sha256(b).hexdigest()
def build(mode):
 src=Path(f'analysis/re34/{mode}.bin').read_bytes();h=headers(src)[0]
 dst=bytearray(src);suffix=bytearray();hooks=[]
 assert h['file']+h['filesz']==len(src)
 for a,field in [(0x810a77f2,8),(0x810a783a,12),(0x810a7882,16)]:
  helper=h['addr']+h['filesz']+len(suffix)
  s=f'''push.w {{r2,r3,r12,lr}}
movw r2,#0x9c00
movt r2,#0x8149
ldr r2,[r2]
cmp r2,#0
beq done
add.w r2,r2,#0x13000
ldr.w r2,[r2,#0xdf0]
cmp r0,r2
bne done
cmp r1,#0
ble done
movw r12,#0xd724
movt r12,#0x8146
ldr.w r12,[r12]
ldr r3,[r0,#{field}]
subs.w r12,r12,r3
bgt room
movs r1,#0
b done
room:
movs r3,#3
umull r1,r2,r1,r3
cmp r2,#0
bne limit
cmp r1,r12
bls done
limit:
mov r1,r12
done:
pop.w {{r2,r3,r12,lr}}
push {{r4,lr}}
sub sp,#8
b.w {hex(a+4)}'''
  code=bytes(ks.asm(s,helper)[0]);suffix+=code
  if len(suffix)%4:suffix+=bytes(ks.asm('nop',helper+len(code))[0])
  off=h['file']+a-h['addr']
  before=bytes(ks.asm('push {r4,lr};sub sp,#8',a)[0])
  after=bytes(ks.asm(f'b.w {hex(helper)}',a)[0])
  assert src[off:off+4]==before and len(after)==4
  assert not [r for r in relocations(src) if r['patchseg']==0 and a-h['addr']<=r['offset']<a-h['addr']+4]
  assert not [r for r in bindings(src) if r['patchseg']==0 and r['code'] and a-h['addr']<=r['offset']<a-h['addr']+4]
  dst[off:off+4]=after;hooks.append({'original':hex(a),'field':field,'helper':hex(helper)})
 size=h['filesz']+len(suffix);assert h['addr']+size<headers(src)[1]['addr']
 ph=struct.unpack_from('<Q',src,0x48)[0];info=struct.unpack_from('<Q',src,0x58)[0]
 struct.pack_into('<I',dst,ph+16,size);struct.pack_into('<I',dst,ph+20,size);struct.pack_into('<Q',dst,info+8,size)
 struct.pack_into('<Q',dst,0x20,len(src)+len(suffix));struct.pack_into('<Q',dst,0x18,struct.unpack_from('<Q',src,0x18)[0]+len(suffix))
 dst+=suffix;Path(f'analysis/re37/{mode}38.bin').write_bytes(dst)
 return {'mode':mode,'source_sha256':sha(src),'patched_sha256':sha(dst),'native_client_version':38,'positive_merit_multiplier':3,'hooks':hooks,'extra_bytes':len(suffix),'negative_costs_unchanged':True,'own_operation_score_object_guard':True}
report=[build(m) for m in ('standard','growth8')]
Path('analysis/re37/MERIT38_BUILD.json').write_text(json.dumps(report,indent=2))
print('MERIT38 BUILT',[(r['mode'],r['extra_bytes']) for r in report])
