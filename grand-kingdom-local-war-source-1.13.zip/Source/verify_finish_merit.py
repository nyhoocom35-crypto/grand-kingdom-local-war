from pathlib import Path
exec(Path('analysis/re37/native_prefix.py').read_text())
root=Path('analysis/re37/native-fixtures')
checks=0
for path in sorted(root.glob('map_*_23.response.bin')):
 _,region,b,winner,_=path.name.split('_');region=int(region);b=int(b);winner=int(winner)
 for side in range(2):
  q21=apply(path.with_name(path.name.replace('_23.','_21.')),21)
  id=struct.unpack_from('<I',q21,0x8c+8+0x30)[0];wire=struct.unpack_from('<I',q21,0x44c)[0]
  for off,val in [(0x13dc0,region),(0x13dc4,b),(0x13dc8,side),(0x13dcc,wire),(0x13dd0,id),(0x13dd4,0x650000),(0x13ddc,0x640000),(0x13de0,0x6d0000),(0x13de4,0x660000),(0x13dec,0x670000),(0x13df0,0x6c0000),(0x13ee4,0),(0x13e80,0)]:g.put(war+off,val)
  apply(path,23)
  q=apply(path.with_name(path.name.replace('_23.','_24.')),24)
  assert g.call(0x81060a22,war)==1,(path,'live finish')
  g.call(0x810a7c4a,0x6d0000,0x660000)
  assert g.call(0x81060582,war)==1,(path,'UI finish')
  g.call(0x810605a6,war)
  assert g.get(war+0x13ee4)==1,(path,'original finish')
  assert g.get(war+0x13e80)==winner,(path,'winner',g.get(war+0x13e80),winner)
  checks+=1
  if checks%56==0:print('All maps, both winners, both player sides:',checks,'/336 PASS',flush=True)
assert checks==336
# Exact failed request's fixed reply, with the original country/front snapshot.
m=json.loads((root/'captured_meta.json').read_text())
apply(Path('analysis/re37/user/captures/20261006_053329.773950100_21.response.bin'),21)
for off,val in [(0x13dc0,m['region']),(0x13dc4,m['base']),(0x13dc8,0),(0x13dcc,m['wire']),(0x13dd0,m['id']),(0x13dd4,0x650000),(0x13ddc,0x640000),(0x13de0,0x6d0000),(0x13de4,0x660000),(0x13dec,0x670000),(0x13df0,0x6c0000),(0x13ee4,0),(0x13e80,0)]:g.put(war+off,val)
apply(root/'captured_repaired_24.response.bin',24)
assert g.call(0x81060a22,war)==1
# Prior ordinary operation remains ongoing.
path=Path('analysis/re36/source/testdata/votes25/map_00_0_0_23.response.bin')
q21=apply(path.with_name('map_00_0_21.response.bin'),21)
for off,val in [(0x13dc0,0),(0x13dc4,0),(0x13dc8,0),(0x13dcc,struct.unpack_from('<I',q21,0x44c)[0]),(0x13dd0,struct.unpack_from('<I',q21,0xc4)[0]),(0x13ee4,0)]:g.put(war+off,val)
apply(path,23);apply(path.with_name('map_00_0_0_24.response.bin'),24)
g.call(0x810a7c4a,0x6d0000,0x660000)
assert g.call(0x81060582,war)==0
finish={'native_client_sha256':hashlib.sha256(blob).hexdigest(),'all84_maps_both_winners_both_player_sides':checks,'original_frame_parser_validator_completion_dispatcher':True,'native_live_and_UI_finish_getters':True,'original_finish_function_and_time_finalizer':True,'original_captured_failed_request_repaired_reply':True,'ordinary_ongoing_operation_not_ended':True,'real_reward_UI_and_gold_grant_verified':False,'actual_vita3k_verified':False,'OS_services_modeled':True}
Path('analysis/re37/NATIVE_FINISH37.json').write_text(json.dumps(finish,indent=2))
print('FINISH37 NATIVE PASS',flush=True)
# Execute actual patched native merit adders, keeping the original capped add and stack guard.
cap=10000;g.put(0x8146d724,cap);own=0x6c0000;other=0x6e0000;g.put(war+0x13df0,own)
merit_checks=0
for addr,field in [(0x810a77f2,8),(0x810a783a,12),(0x810a7882,16)]:
 for obj,mult in [(own,3),(other,1)]:
  for current,delta in [(0,10),(100,17),(100,-10),(100,0),(cap-2,10),(cap,10),(100,0x7fffffff)]:
   g.put(obj+field,current)
   g.call(addr,obj,delta&0xffffffff)
   expected=max(0,min(cap,current+(delta*mult if delta>0 else delta)))
   got=g.get(obj+field)
   # Overflow behavior in untouched foreign objects is the original game's behavior.
   if obj==other and delta==0x7fffffff:continue
   assert got==expected,(hex(addr),hex(obj),current,delta,got,expected)
   merit_checks+=1
# Check actual outgoing RegisterScore request contains boosted current and cumulative values.
for field,val in [(8,10),(12,20),(16,30)]:g.put(own+field,0)
for addr,val in [(0x810a77f2,10),(0x810a783a,20),(0x810a7882,30)]:g.call(addr,own,val)
for i in range(3):g.put(war+0x13e28+i*4,100*(i+1))
g.put(0x8146b720,999999)
# Native builder signature checked below if needed.
request=0x720000
g.call(0x81068f70,request)
current=[g.get(request+0xa8+i*4) for i in range(3)];total=[g.get(request+0xb4+i*4) for i in range(3)]
assert current==[30,60,90] and total==[130,260,390],(current,total)
merit={'native_client_sha256':hashlib.sha256(blob).hexdigest(),'positive_own_merit_multiplier':3,'original_native_adder_cases':merit_checks,'all_three_merit_categories':True,'other_score_objects_unchanged':True,'negative_costs_unchanged':True,'cap_and_positive_overflow_safe':True,'native_RegisterScore_current':current,'native_RegisterScore_cumulative':total,'existing_banked_merit_unchanged':True,'no_server_second_multiplier':True,'actual_vita3k_verified':False}
Path('analysis/re37/NATIVE_MERIT38.json').write_text(json.dumps(merit,indent=2))
print('MERIT38 NATIVE PASS',flush=True)
