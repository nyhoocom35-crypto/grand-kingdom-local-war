const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(process.argv[2]||'analysis/re33/source/status.go','utf8');
const js=source.match(/<script>([\s\S]*?)<\/script>/)[1];
const data=JSON.parse(fs.readFileSync(process.argv[3]||'analysis/re33/status-fixture.json','utf8'));
class Element {
 constructor(tag){this.tag=tag;this.textContent='';this.children=[];}
 append(e){this.children.push(e)} replaceChildren(){this.children=[]}
}
const elements=Object.fromEntries(['clock','error','contracts','fronts','owners','votes','research','strategyvotes','dispatches','events'].map(id=>[id,new Element('div')]));
const context={document:{createElement:tag=>new Element(tag),getElementById:id=>elements[id],querySelector:sel=>elements[sel.slice(1)]},fetch:async()=>({ok:true,json:async()=>data}),setInterval:()=>{},console};
vm.createContext(context);vm.runInContext(js,context);
const content=e=>[e.textContent,...e.children.map(content)].join(' ');
const rows=id=>elements[id].children.filter(e=>e.tag==='table').flatMap(t=>t.children.slice(1));
(async()=>{
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(elements.error.textContent,'');
 const owners=rows('owners');assert.equal(owners.length,16);
 owners.forEach((row,r)=>{assert.equal(row.children[0].textContent,data.region_names[r]);assert.equal(row.children[1].textContent,data.country_names[data.owners[r]]);});
 const frontRows=rows('fronts');frontRows.forEach((row,i)=>{
  const f=data.fronts[i];assert.equal(row.children[0].textContent,data.region_names[f.region]);assert.equal(row.children[3].textContent,f.bases.map(b=>data.base_names[f.region][b]).join(', '));
 });
 assert.equal(elements.strategyvotes.children.filter(e=>e.tag==='h3').length,84);
 elements.strategyvotes.children.filter(e=>e.tag==='h3').forEach((h,i)=>{
  const m=data.strategy_votes[i].map;assert(h.textContent.startsWith(data.region_names[m.Region]+' / '+data.base_names[m.Region][m.Base]));
 });
 // Exercise every region/base combination, including neutral region and sentinel.
 data.votes=[];for(let r=0;r<17;r++)for(let b=0;b<7;b++)data.votes.push({country:0,region:r,base:b,ai:2,player:1,total:3});
 data.votes.push({country:0,region:0,base:23,ai:0,player:42,total:42});
 await vm.runInContext('refresh()',context);
 const voteRows=rows('votes');assert.equal(voteRows.length,120);
 voteRows.forEach((row,i)=>{
  const v=data.votes[i];assert.equal(row.children[0].textContent,data.region_names[v.region]);
  assert.equal(row.children[1].textContent,v.base===23?'지역 전체':data.base_names[v.region][v.base]);assert.equal(row.children[4].textContent,v.total);
 });
 assert(content(elements.events).includes('에클리스 영토 소유권: 랜더스 → 발키르'));
 const counts=Object.fromEntries(Object.entries(elements).map(([id,e])=>[id,e.children.length]));
 await vm.runInContext('refresh()',context);
 Object.entries(counts).forEach(([id,count])=>assert.equal(elements[id].children.length,count,'duplicate refresh rows'));
 assert.equal(elements.error.textContent,'');
 const rankTables=elements.strategyvotes.children.filter(e=>e.tag==='table').filter((_,i)=>i%2===1);
 rankTables.forEach((table,i)=>{
  assert.equal(table.children.length,43);
  const v=data.strategy_votes[i];let index=1;
  for(let side=0;side<2;side++)for(let metric=0;metric<3;metric++)for(let rank=0;rank<7;rank++){
   const row=table.children[index++];assert.equal(row.children[2].textContent,['S','A','B','C','D','E','F'][rank]);
   assert.equal(row.children[3].textContent,v.rank_population[side][metric][rank]);
  }
 });
 console.log('PASS: numeric rank populations on every battlefield; dashboard 4 nations, 16 territory rows, 119 bases, 84 battle headings, numeric votes and repeat refresh.');
})().catch(e=>{console.error(e);process.exitCode=1});
