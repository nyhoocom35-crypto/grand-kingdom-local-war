"""Replay the real native troop decoder and cosmetic loot builder.
Usage: verify_rivals46.py SELF CLIENT46_FIXTURES OWNER_PARAMETER_DIRECTORY
The byte-stream interface, inventory ownership and RNG are modeled. Cosmetic
and appearance lookups execute natively against the owner's parameter rows.
"""
import json,struct,sys
from pathlib import Path
from native_replay46 import *

binary=Path(sys.argv[1]).read_bytes();fixtures=Path(sys.argv[2]);params=Path(sys.argv[3])
u=machine(binary)
P=0x2900000;OBJ=0x2800000;OUT=0x2810000;PARTY=0x2820000;VT=0x2830000
def table(ptr, rows):
    u.mem_write(ptr,b''.join(rows));return len(rows)
items=(params/'ITEMPARAMETER.DAT').read_bytes()
special=[]
for item in list(range(70100,70180))+list(range(70300,70321)):
    at=items.find(struct.pack('<III',item,item,item));assert at>=0,item
    special.append(items[at:at+12]+bytes(8)+items[at+12:at+28])
put(u,MGR+8,P);put(u,P+0x50,P+0x1000);put(u,P+0x54,table(P+0x1000,special))
weapons=[]
for item in (20000,20500,21500,20400,20100,20300,20700,20800,20900,21100,20600):
    at=items.find(struct.pack('<III',item,item,item));assert at>=0,item
    weapons.append(items[at:at+12]+bytes(0x94-12))
put(u,P+0x18,P+0xb000);put(u,P+0x1c,table(P+0xb000,weapons))

for key,filename,width,offset in [(0xc,'PAWNPARAMETER.DAT',20,0x2000),(0x10,'FLAGPARAMETER.DAT',16,0x3000)]:
    raw=(params/filename).read_bytes();count=struct.unpack_from('<I',raw,32)[0]
    put(u,MGR+key,P+offset);put(u,P+offset,P+offset+0x100);put(u,P+offset+4,count)
    u.mem_write(P+offset+0x100,raw[36:36+count*width])
# UNITEDIT file rows are expanded by the original loader with reserved tail words.
edit=(params/'UNITEDIT.DAT').read_bytes();put(u,MGR+0x20,P+0x4000)
for field,countfield,at,n,inwidth,outwidth,target in [
    (8,0x84,176,612,8,8,0x5000),(0x88,0x8c,5076,9,8,12,0x7000),
    (0x90,0x94,5152,12,8,16,0x7100),(0x98,0x9c,5252,300,24,28,0x8000)]:
    rows=[edit[at+i*inwidth:at+(i+1)*inwidth]+bytes(outwidth-inwidth)for i in range(n)]
    if inwidth==24:rows=[r[:12]+bytes(4)+r[12:24]for r in rows]
    put(u,P+0x4000+field,P+target);put(u,P+0x4000+countfield,table(P+target,rows))
put(u,OBJ,VT)
methods={0x2f00000:1,0x2f00004:2,0x2f00008:4}
for field,addr in zip((0x40,0x44,0x48),methods):put(u,VT+field,addr|1)
random_value=0;owned=set();checks=0
def hook(u,pc):
    global checks
    if pc in methods:
        r0,r1=u.reg_read(UC_ARM_REG_R0),u.reg_read(UC_ARM_REG_R1)
        n=methods[pc];at=get(u,r0+0x18);src=get(u,r0+4)
        u.mem_write(r1,bytes(u.mem_read(src+at,n)));put(u,r0+0x18,at+n);returning(u,1)
    elif pc==0x810592f2:returning(u,0)
    elif pc in (0x810472a4,0x810472ac,0x814124f0):
        a,b,n=[u.reg_read(r)for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
        u.mem_write(a,bytes(u.mem_read(b,n)));returning(u,a)
    elif pc==0x810472be:
        a,n=u.reg_read(UC_ARM_REG_R0),u.reg_read(UC_ARM_REG_R1);u.mem_write(a,bytes(n));returning(u,a)
    elif pc==0x8108dcfc:returning(u,int(u.reg_read(UC_ARM_REG_R1)in owned))
    elif pc==0x81047cb6:returning(u,random_value)
report=dict(native_troop_decodes=0,native_cosmetic_drops=0,actual_vita3k_verified=False)
for path in sorted(fixtures.glob('nation*.plain')):
    raw=path.read_bytes()
    for i in range(30):
        at=0x8c+i*0x518
        if not struct.unpack_from('<I',raw,at)[0]:continue
        troop=raw[at+24:at+24+1084];u.mem_write(INPUT,troop)
        put(u,OBJ+4,INPUT);put(u,OBJ+0x18,0)
        result=run(u,0x8106af22,[OBJ,OUT,4],hook)
        assert result==1,(path.name,i,hex(u.reg_read(UC_ARM_REG_PC)),get(u,OBJ+0x18))
        assert get(u,OBJ+0x18)==1084
        report['native_troop_decodes']+=1
        # The original runtime cosmetic fields consumed by the loot builder.
        flag=troop[0xde];piece=70300+struct.unpack_from('<H',troop,0xdc)[0]
        put(u,PARTY+0x114,flag);put(u,PARTY+0x118,piece)
        for random_value,want in [(0,2),(99,0)]:
            u.mem_write(PARTY+0x16d0,bytes(24));owned.clear()
            run(u,0x81062ae8,[WAR,0,PARTY],hook)
            drops=[get(u,PARTY+0x16d0+j*8)for j in range(3)if get(u,PARTY+0x16d4+j*8)]
            # Some original pawn types have zero drop rate; flags all selected
            # here have a nonzero original rate. Keep those original rates.
            assert set(drops)==({70100+flag,piece} if random_value==0 else set()),(path.name,i,flag,piece,drops)
            assert set(drops).issubset({70100+flag,piece})
            owned.update(drops);u.mem_write(PARTY+0x16d0,bytes(24))
            run(u,0x81062ae8,[WAR,0,PARTY],hook)
            assert not any(get(u,PARTY+0x16d4+j*8)for j in range(3))
            report['native_cosmetic_drops']+=1
print(json.dumps(report,indent=2))
