"""Replay HUD46 with full SELF relocations; no live Vita3K test is claimed.
Usage: verify_hud46.py CLIENT46_DIRECTORY CLIENT45_DIRECTORY
"""
import json, sys, struct
from pathlib import Path
from native_replay46 import *

root, prior = map(Path, sys.argv[1:3])
metadata = json.loads((root/'HUD46_BUILD.json').read_text())
layouts = json.loads((Path(__file__).parent/'server/world-layouts.json').read_text())
report = dict(hud_cases=0, unchanged_reward_functions=True, actual_vita3k_verified=False)
for record in metadata:
    mode=record['mode']; binary=(root/f'{mode}46.bin').read_bytes()
    old=(prior/f'{mode}45.bin').read_bytes()
    oldseg,newseg=segments(old),segments(binary)
    # HUD edits cannot change reward/XP/merit code or any other old code bytes.
    expected=[(0x21cbe6,4),(0x225ab2,4),(0x225ac4,4),(0x225ae0,4),(0x225aea,4)]
    a=bytearray(old[oldseg[0]['off']:oldseg[0]['off']+oldseg[0]['size']])
    b=bytearray(binary[newseg[0]['off']:newseg[0]['off']+oldseg[0]['size']])
    for off,n in expected:a[off:off+n]=b[off:off+n]
    assert a==b, 'non-HUD native code changed'
    memory=relocated_segments(binary)
    for off,n in expected:assert memory[0][off:off+n]==b[off:off+n]
    helper=int(record['current_hp'],16)-0x81000000
    assert memory[0][helper:]==binary[newseg[0]['off']+helper:]
    u=machine(binary);put(u,WAR+0x13dd8,MGR)
    for name,layout in layouts.items():
        region=int(name.split(':')[0])
        if region in (0,4,8,12):continue
        for stage in range(6):
            u.mem_write(MGR+0x64,bytes(32*44));counts=[0,0];hp=[0,0];maximum=[0,0];index=0
            for side,objects in enumerate(layout['objects']):
                for n,o in enumerate(objects):
                    if not o[1] or not o[2]:continue
                    p=MGR+0x64+44*index;index+=1
                    value=1000 if n else 1000-stage*200
                    u.mem_write(p+4,struct.pack('<H',index));put(u,p+12,side)
                    put(u,p+32,value);put(u,p+40,1000)
                    counts[side]+=int(value>0);hp[side]+=value;maximum[side]+=1000
            for side in (0,1):
                assert run(u,0x8121cbb8,[0,side])==counts[side],(mode,name,stage,side,'count')
                assert run(u,int(record['current_hp'],16),[0,side])==hp[side]
                assert run(u,int(record['maximum_hp'],16),[0,side])==maximum[side]
                report['hud_cases']+=1
print(json.dumps(report,indent=2))
