"""Replay actual native snapshot, research and national-shop category paths.

Usage: python verify_shop41.py OWN_CLIENT_BIN OWN_RESEARCHPARAMETER_DAT FIXTURES
Uses deterministic RNG sampling; no graphics/OS emulation is claimed.
"""
import json, struct, sys
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_HOOK_CODE
from unicorn import UC_PROT_READ, UC_PROT_EXEC
from unicorn.arm_const import *

blob=Path(sys.argv[1]).read_bytes();param=Path(sys.argv[2]).read_bytes();fixtures=Path(sys.argv[3])
ph=struct.unpack_from('<Q',blob,0x48)[0];si=struct.unpack_from('<Q',blob,0x58)[0]
off,size=struct.unpack_from('<QQ',blob,si)
count=struct.unpack_from('<I',param,32)[0]
rows=[struct.unpack_from('<III',param,36+i*12)for i in range(count)]
SAVE,INPUT,WAR,MANAGER,HEADER,TABLE,UI= [0x2000000+i*0x100000 for i in range(7)]
STACK,STOP=0x2ff0000,0x2fff000
def put(u,a,v):u.mem_write(a,struct.pack('<I',v))
def get(u,a):return struct.unpack('<I',u.mem_read(a,4))[0]
def ret(u,v=0):u.reg_write(UC_ARM_REG_R0,v);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
def country(n):return SAVE+0x27900+n*0x6280
def run(u,addr,args):
    u.reg_write(UC_ARM_REG_SP,STACK);u.reg_write(UC_ARM_REG_LR,STOP|1)
    for r,v in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],args):u.reg_write(r,v)
    try: u.emu_start(addr|1,STOP,count=120000000)
    except Exception:
        print('Native failure',hex(u.reg_read(UC_ARM_REG_PC)),[hex(u.reg_read(r))for r in [UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_LR]],file=sys.stderr)
        raise
    assert u.reg_read(UC_ARM_REG_PC)==STOP,hex(u.reg_read(UC_ARM_REG_PC))
    return u.reg_read(UC_ARM_REG_R0)
def inventory(u,n):
    p=country(n);return [(get(u,p+0x128+i*24),get(u,p+0x12c+i*24),get(u,p+0x138+i*24))for i in range(get(u,p+0x124))]
def machine():
    u=Uc(UC_ARCH_ARM,UC_MODE_THUMB);u.mem_map(0x81000000,0x800000);u.mem_write(0x81000000,blob[off:off+size])
    u.reg_write(UC_ARM_REG_C1_C0_2,0xf00000);u.reg_write(UC_ARM_REG_FPEXC,0x40000000)
    # Original constants/globals are in subsequent SELF segments. They remain
    # flat in this verified decrypted SELF; mutable globals start at 81498000.
    dataoff,datasize=struct.unpack_from('<QQ',blob,si+32)
    u.mem_write(0x81498000,blob[dataoff:dataoff+datasize])
    if '--relocated' in sys.argv:
        from self_loader import relocated_segments,segments
        for i,data in relocated_segments(blob).items():u.mem_write(segments(blob)[i]['va'],bytes(data))
    if '--no-code-writes' in sys.argv:u.mem_protect(0x81000000,0x498000,UC_PROT_READ|UC_PROT_EXEC)
    u.mem_map(0x2000000,0x1000000)
    for a,v in [(0x81499b64,SAVE),(0x81499c00,WAR),(0x81499c38,UI),(0x81499bf0,MANAGER),(0x81499b9c,HEADER+0x100)]:put(u,a,v)
    put(u,HEADER+0x100+0x3b0,0x9f4)
    put(u,MANAGER+0x24,HEADER);put(u,HEADER,TABLE);put(u,HEADER+4,count);u.mem_write(TABLE,param[36:])
    for c in range(5):put(u,HEADER+8+c*4,sum(r[0]//10000==c for r in rows))
    candidates=[];sample=0;categories=[]
    heap=0x2700000
    real_rng='--real-rng' in sys.argv
    def hook(u,pc,size,unused):
        nonlocal sample,heap
        if pc==STOP:u.emu_stop()
        elif pc in (0x81047a1e,0x81047a6a,0x810897b8,0x810897bc,0x8107376e,0x81073620):ret(u)
        elif real_rng and pc==0x81047378:
            alloc=heap;heap+=(u.reg_read(UC_ARM_REG_R0)+15)//16*16
            assert heap<0x2e00000
            ret(u,alloc)
        elif real_rng and pc in (0x8104738c,0x81047396):ret(u)
        elif real_rng and pc==0x813eb58c:ret(u,u.reg_read(UC_ARM_REG_R1))
        elif pc==0x81073d9e:
            a,b=u.reg_read(UC_ARM_REG_R0),u.reg_read(UC_ARM_REG_R1);u.mem_write(a,bytes(u.mem_read(b,8)));ret(u,a)
        elif pc==0x810472ac:
            a,b,c=[u.reg_read(r)for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
            if '--no-code-writes' in sys.argv: assert not (0x81000000<=a<0x81498000),f'host memcpy into executable memory: {a:#x}'
            u.mem_write(a,bytes(u.mem_read(b,c)));ret(u,a)
        elif not real_rng and pc in (0x810bbe38,0x810bc1b6):ret(u)
        elif not real_rng and pc==0x810bbea0:candidates.clear();sample=0;ret(u)
        elif not real_rng and pc==0x810bc66c:candidates.append(u.reg_read(UC_ARM_REG_R3));ret(u)
        elif not real_rng and pc==0x810bc2e6:ret(u,candidates[sample%len(candidates)]);sample+=1
        # Ownership/inventory flag lookup executes natively against this save.
        elif pc==0x8139e3e4:categories.append(u.reg_read(UC_ARM_REG_R1));ret(u)
        elif pc==0x8118ecc6:u.reg_write(UC_ARM_REG_PC,STOP|1)
    for pc in [STOP,0x81047a1e,0x81047a6a,0x810897b8,0x810897bc,0x8107376e,0x81073620,0x81047378,0x8104738c,0x81047396,0x813eb58c,0x81073d9e,0x810472ac,0x810bbe38,0x810bc1b6,0x810bbea0,0x810bc66c,0x810bc2e6,0x8139e3e4,0x8118ecc6]:
        u.hook_add(UC_HOOK_CODE,hook,begin=pc,end=pc)
    return u,categories

def snapshot(u,counts,warid=0x40000009):
    f=bytearray((fixtures/'fixed_initial.bin').read_bytes());struct.pack_into('<I',f,0x1c0,warid)
    for n in range(4):f[0x8c+n*48+0x24:0x8c+n*48+0x28]=bytes(counts[n])
    b=bytearray(0x9f4);b[0x480:0x480+len(f)]=f;struct.pack_into('<I',b,0x44c,warid)
    for n in range(4):b[0x8c+n*0xf0+0xed]=f[0x14c+n*16+12]
    u.mem_write(INPUT,bytes(b));run(u,0x8108b9b4,[INPUT])
def barrack(u,counts,warid=0x40000009):
    b=bytearray((fixtures/'barrack_initial_0.bin').read_bytes());struct.pack_into('<I',b,0x12c,warid)
    for n in range(4):b[0x11c+n*4:0x120+n*4]=bytes(counts[n])
    u.mem_write(INPUT,bytes(b));run(u,0x8106455c,[INPUT])
def ui_categories(u,n,out):
    out.clear();put(u,UI+0x80,n);run(u,0x8118ec3e,[UI]);return list(out)

u,cat=machine();initial=[[0]*4 for _ in range(4)];snapshot(u,initial)
if '--baseline' in sys.argv:
    # Model the baseline stock already stored by the original first login.
    for n in range(4):u.mem_write(country(n)+0x118,bytes(u.mem_read(WAR+0x55c+n*0x4ce8,0x4c00)))
    snapshot(u,[[1,0,0,0] for _ in range(4)])
    assert all(get(u,WAR+0x568+n*0x4ce8)==6 and get(u,country(n)+0x124)==5 for n in range(4))
    assert all(2 not in ui_categories(u,n,cat) for n in range(4))
    print(json.dumps(dict(client38_regression_reproduced=True,native_generated_items=6,native_shop_stale_items=5,actual_shop_UI_weapon_category_missing=True),indent=2))
    sys.exit(0)
assert all(len(inventory(u,n))==5 for n in range(4))
# Each original research category is a distinct real item class in the actual
# national-shop UI, populated through the native save-country accessor.
counts=[[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
snapshot(u,counts)
native_rows=[]
for n in range(4):
    inv=inventory(u,n);assert len(inv)>5,(n,inv)
    categories=ui_categories(u,n,cat);assert 2 in categories if n<2 else (3 in categories if n==2 else 4 in categories),(n,categories,inv)
    native_rows.append(dict(country=n,items=len(inv),ui_categories=categories))
# Purchase depletion survives identical GetNow snapshots and research refreshes.
p=country(0);put(u,p+0x138,0);snapshot(u,counts);assert get(u,p+0x138)==0
barrack(u,counts);assert get(u,p+0x138)==0
# New completed research becomes visible immediately on GetBarrackData, without
# a new campaign/round ID or an extra GetNow request.
counts[0]=[10,11,0,0];unchanged=bytes(u.mem_read(country(1)+0x118,0x4c00))
barrack(u,counts);assert sum(row[2] for row in inventory(u,0))==26,inventory(u,0)
assert bytes(u.mem_read(country(1)+0x118,0x4c00))==unchanged
assert 2 in ui_categories(u,0,cat)
put(u,country(0)+0x138,0);barrack(u,counts);snapshot(u,counts);assert get(u,country(0)+0x138)==0
# Next campaign restocks using the new original war identity, all four nations.
snapshot(u,counts,0x40000011);assert get(u,country(0)+0x138)>0
if '--capture' in sys.argv:
    u,cat=machine();raw=Path(sys.argv[sys.argv.index('--capture')+1]).read_bytes();u.mem_write(INPUT,raw);run(u,0x8108b9b4,[INPUT]);assert all(get(u,country(n)+0x124)>5 for n in range(4))
print(json.dumps(dict(native_snapshot_and_original_research_handler=True,native_shop_UI_category_path=True,all_four_categories=native_rows,reported_counts_10_and_11_replayed=True,same_round_research_refresh=True,repeated_requests_preserve_purchase_depletion=True,other_countries_unchanged=True,new_campaign_restock=True,ownership_lookup_native=True,RNG_sampler_deterministic_stub='--real-rng' not in sys.argv,heap_and_OS_services_modeled=True,crash_login_capture_replayed='--capture' in sys.argv,no_code_memory_writes='--no-code-writes' in sys.argv,SELF_segment_relocations_applied='--relocated' in sys.argv,actual_vita3k_verified=False),indent=2))
