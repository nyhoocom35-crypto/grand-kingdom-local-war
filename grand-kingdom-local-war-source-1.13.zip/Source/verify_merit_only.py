from pathlib import Path
exec(Path('analysis/re37/native_prefix.py').read_text())
# Execute actual patched native merit adders, keeping the original capped add and stack guard.
cap=10000;g.put(0x8146d724,cap);own=0x6c0000;other=0x6e0000;g.put(war+0x13df0,own)
merit_checks=0
for addr,field in [(0x810a77f2,8),(0x810a783a,12),(0x810a7882,16)]:
 for obj,mult in [(own,3),(other,1)]:
  for current,delta in [(0,10),(100,17),(100,-10),(100,0),(cap-2,10),(cap,10),(100,0x7fffffff)]:
   g.put(obj+field,current)
   g.call(addr,obj,delta&0xffffffff)
   expected=max(0,min(cap,current+(delta*mult if delta>0 else delta)))
   got=g.get(obj+field)
   # Overflow behavior in untouched foreign objects is the original game's behavior.
   if obj==other and delta==0x7fffffff:continue
   assert got==expected,(hex(addr),hex(obj),current,delta,got,expected)
   merit_checks+=1
# Check actual outgoing RegisterScore request contains boosted current and cumulative values.
for field,val in [(8,10),(12,20),(16,30)]:g.put(own+field,0)
for addr,val in [(0x810a77f2,10),(0x810a783a,20),(0x810a7882,30)]:g.call(addr,own,val)
for i in range(3):g.put(war+0x13e28+i*4,100*(i+1))
g.put(0x8146b720,999999)
# Native builder signature checked below if needed.
request=0x720000
g.call(0x81068f70,request)
current=[g.get(request+0xa8+i*4) for i in range(3)];total=[g.get(request+0xb4+i*4) for i in range(3)]
assert current==[30,60,90] and total==[130,260,390],(current,total)
Path('analysis/re37/native_request38.bin').write_bytes(bytes(g.u.mem_read(request,256)))
merit={'native_client_sha256':hashlib.sha256(blob).hexdigest(),'positive_own_merit_multiplier':3,'original_native_adder_cases':merit_checks,'all_three_merit_categories':True,'other_score_objects_unchanged':True,'negative_costs_unchanged':True,'cap_and_positive_overflow_safe':True,'native_RegisterScore_current':current,'native_RegisterScore_cumulative':total,'existing_banked_merit_unchanged':True,'no_server_second_multiplier':True,'actual_vita3k_verified':False}
Path(f'analysis/re37/NATIVE_MERIT38_{mode}.json').write_text(json.dumps(merit,indent=2))
print('MERIT38 NATIVE PASS',flush=True)
