package main

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func publishDispatch35(t *testing.T, w *War, at time.Time, slot, country byte) {
	t.Helper()
	_, r := request16(t, 35)
	r[0x9c], r[0x9d], r[0xa4] = slot, 1, country
	c, _ := aiCompany(0xf0000000)
	copy(r[0xa8:], generatedTroop(c, 0xf0000000))
	d := make([]byte, 1456)
	if err := w.companyRequest(35, d, r, at); err != nil {
		t.Fatal(err)
	}
	if d[0x8c] != 1 || d[0x8d] != 255 {
		t.Fatal("publication limit", d[0x8c:0x8e])
	}
}

func TestDispatch35TimeScalesBeyondTenAcrossCountriesAndSlots(t *testing.T) {
	for country := byte(0); country <= 4; country++ {
		w := campaignWar(t)
		start := w.Start
		for slot := byte(0); slot < 6; slot++ {
			publishDispatch35(t, w, start, slot, country)
		}
		for _, minute := range []int{0, 1, 9, 10, 11, 30, 60, 120, 254, 255, 256, 1440} {
			d := make([]byte, 1456)
			_, req := request16(t, 38)
			at := start.Add(time.Duration(minute) * time.Minute)
			if err := w.companyRequest(38, d, req, at); err != nil {
				t.Fatal(err)
			}
			for slot := byte(0); slot < 6; slot++ {
				troop := w.Dispatches[123][slot]
				if troop.Battles != byte(min(minute, 255)) || d[0x8c+int(slot)] != troop.Battles || troop.Wins > troop.Battles {
					t.Fatal(country, slot, minute, troop.Battles, troop.Wins)
				}
			}
			before := w.World.Fronts
			if err := w.companyRequest(38, d, req, at); err != nil {
				t.Fatal(err)
			}
			if before != w.World.Fronts {
				t.Fatal("duplicate poll awarded influence")
			}
			saved, err := loadWar(w.path)
			if err != nil {
				t.Fatal(err)
			}
			w = saved
		}
	}
}

func TestDispatch35OldTenBattleSaveCatchupAndReturnReplay(t *testing.T) {
	w := campaignWar(t)
	start := w.Start
	publishDispatch35(t, w, start, 0, 2)
	// Emulate an existing server33 deployment stopped at ten battles, with the
	// original Started timestamp retained across upgrade and server shutdown.
	w.advanceDispatches(start.Add(10 * time.Minute))
	if w.Dispatches[123][0].Battles != 10 || w.Dispatches[123][0].Wins != 6 {
		t.Fatal("old fixture")
	}
	if err := w.save(); err != nil {
		t.Fatal(err)
	}
	w, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	d := make([]byte, 1456)
	_, ret := request16(t, 36)
	if err := w.companyRequest(36, d, ret, start.Add(time.Hour)); err != nil {
		t.Fatal(err)
	}
	if d[0x8d] != 60 || d[0x8c] != 36 {
		t.Fatal("return should include elapsed offline time", d[0x8c:0x8e])
	}
	payload := append([]byte(nil), d[0x8c:0x5b0]...)
	w, err = loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	before := w.World.Fronts
	clear(d)
	if err := w.companyRequest(36, d, ret, start.Add(2*time.Hour)); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(payload, d[0x8c:0x5b0]) || before != w.World.Fronts {
		t.Fatal("return retry changed credited result")
	}
	publishDispatch35(t, w, start.Add(3*time.Hour), 0, 2)
	_, counts := request16(t, 38)
	if err := w.companyRequest(38, d, counts, start.Add(3*time.Hour+time.Minute)); err != nil {
		t.Fatal(err)
	}
	if d[0x8c] != 1 {
		t.Fatal("redispatch must start from zero")
	}
}

func TestDispatch35ClockRollbackDoesNotDuplicateResults(t *testing.T) {
	w := campaignWar(t)
	start := w.Start
	publishDispatch35(t, w, start, 0, 0)
	w.advanceDispatches(start.Add(time.Hour))
	w.advanceDispatches(start.Add(20 * time.Minute))
	w.advanceDispatches(start.Add(time.Hour))
	if w.Dispatches[123][0].Battles != 60 {
		t.Fatal("clock rollback duplicated battles")
	}
	if err := w.save(); err != nil {
		t.Fatal(err)
	}
	if _, err := loadWar(w.path); err != nil {
		t.Fatal(err)
	}
}

func TestDispatch35NativeWireFixtures(t *testing.T) {
	if os.Getenv("GK35_NATIVE_CAPTURE") == "" {
		t.Skip("private native replay output not requested")
	}
	p := testProtocol(t)
	for _, battles := range []int{10, 11, 30, 60, 120, 254, 255} {
		w := campaignWar(t)
		start := time.Now().UTC().Add(-time.Duration(battles) * time.Minute)
		publishDispatch35(t, w, start, 0, 2)
		w.advanceDispatches(start.Add(time.Duration(battles) * time.Minute))
		b := &Backend{p: p, war: w}
		for _, api := range []int{35, 38, 36} {
			ep, req := request16(t, api)
			if api == 35 {
				c, _ := aiCompany(0xf0000000)
				copy(req[0xa8:], generatedTroop(c, 0xf0000000))
				req[0xa4] = 2
			}
			frame, status, err := b.response(ep, req)
			if err != nil || status != "OK" || len(frame) != ep.ResponseFrame {
				t.Fatal(api, status, err)
			}
			out := filepath.Join(os.Getenv("GK35_NATIVE_CAPTURE"), stringID35(battles)+"_"+jsonNumber(api)+".response.bin")
			if err := os.WriteFile(out, frame, 0600); err != nil {
				t.Fatal(err)
			}
		}
	}
}

func stringID35(n int) string { return jsonNumber(n) }
