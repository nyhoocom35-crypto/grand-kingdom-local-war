package main

import (
	"encoding/binary"
	"sort"
)

// GetRivalTroop is thirty sequential opponents for the requested enemy nation,
// not twelve field-object slots. Zero-ID rows deliberately retain native NPCs.
const rivalRow46 = 0x518

// IDs present in the owner's 1.06 base appearance/flag/pawn parameter tables.
// These are identifiers only, not game assets or serialized original troops.
var rivalClasses46 = [...]uint16{0, 1, 2, 3, 4, 5, 6, 8, 9, 10, 12, 13, 16, 17, 18, 20, 22}

// Matching weapon families from UNITPARAMETER +14, verified in ITEMPARAMETER.
// Values are relative to the native weapon base ID 20000.
var rivalWeapons46 = [...]uint16{0, 500, 1500, 400, 0, 100, 100, 500, 300, 700, 800, 900, 100, 1100, 0, 600, 700}
var rivalFlags46 = [...]byte{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 25, 27, 28, 29, 30, 31, 33, 34, 35, 36, 37, 39, 43, 44, 46, 47, 51, 52, 53, 54, 55, 56, 57, 58, 59, 64, 65, 66, 68, 71, 72, 74, 75, 76, 77, 79}
var rivalPieces46 = [...]uint16{0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20}

func variedRival46(c Company, id uint32, variant, level int) []byte {
	d := generatedTroop(c, id)
	seed := int((id - 0xf0000000) % 100)
	// Wire excludes eight native owner/slot bytes: dc is the piece item
	// (70300 + pawn ID); de is the flag ID.
	u16(d, 0xdc, rivalPieces46[(seed*3+variant)%len(rivalPieces46)])
	d[0xde] = rivalFlags46[(seed*5+variant)%len(rivalFlags46)]
	d[0xdf] = byte((seed + variant) % 7)
	d[0xe0] = byte((seed + variant) % 4)
	for row := 0; row < 2; row++ {
		for i := 0; i < 4; i++ {
			d[0xe4+row*8+i*2] = byte(1 + i*3)
			d[0xe5+row*8+i*2] = byte((row + seed + variant) % 3)
		}
	}
	for i := 0; i < 4; i++ {
		u := d[276+i*202 : 276+(i+1)*202]
		class := (seed*4 + variant*3 + i) % len(rivalClasses46)
		u16(u, 0, rivalClasses46[class])
		u[2], u[3] = byte((seed+variant+i)%5), byte((seed+variant+i)%4)
		// Zero appearance indices select this class's base equipment models.
		// ffff here would fail the native equipment-model lookup.
		for o := 0x34; o < 0x5c; o += 2 {
			u16(u, o, 0xffff)
		}
		u16(u, 0x34, rivalWeapons46[class])
		sets := rivalSkills47[rivalClasses46[class]]
		skills := sets[(seed+variant+i)%len(sets)]
		for slot, skill := range skills {
			u[0x84+slot] = skill
		}
		u[0x28] = byte(max(1, min(99, level+variant%5-2)))
	}
	return d
}

func (w *War) rivals46(dst, req []byte) bool {
	if len(dst) < 0x8c+30*rivalRow46 || len(req) < 0x9f || req[0x9c] >= 4 {
		return false
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	country := req[0x9c]
	ids := []uint32{}
	if w.World != nil {
		for id, rank := range w.World.Ranks {
			if rank.AI && rank.Country == country {
				if _, ok := aiCompany(id); ok {
					ids = append(ids, id)
				}
			}
		}
	} else {
		for i := uint32(0); i < 6; i++ {
			ids = append(ids, 0xf0000000+uint32(country)*100+i)
		}
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })
	if len(ids) == 0 {
		return true // native NPC fallback when no AI has a contract here
	}
	level := max(1, min(99, int(req[0x9e])))
	for i := 0; i < 30; i++ {
		if i%3 == 0 {
			continue // ten native NPCs remain mixed with twenty AI troops
		}
		id := ids[(i+i/6)%len(ids)]
		c, ok := w.company(id)
		if !ok {
			continue
		}
		o := 0x8c + i*rivalRow46
		binary.LittleEndian.PutUint32(dst[o:], id)
		putText(dst[o+4:o+0x15], c.Username)
		dst[o+0x15] = byte(i % 6)
		copy(dst[o+0x18:o+0x18+troopSize], variedRival46(c, id, i+int(w.ID%59)*30, level))
	}
	return true
}
