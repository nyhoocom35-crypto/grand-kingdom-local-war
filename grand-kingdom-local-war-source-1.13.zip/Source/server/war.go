package main

import (
	"encoding/binary"
	"encoding/json"
	"errors"
	"os"
	"sync"
	"time"
)

// Local campaign information. Contract/payment handling remains in the client.
type War struct {
	AIContracts26       map[uint32]AIContract26       `json:"ai_contracts26,omitempty"`
	Companies           map[uint32]Company            `json:"companies,omitempty"`
	Dispatches          map[uint32]map[byte]*Dispatch `json:"dispatches,omitempty"`
	World               *Campaign                     `json:"world,omitempty"`
	OperationGeneration uint32                        `json:"operation_generation,omitempty"`
	OperationStart      time.Time                     `json:"operation_start,omitempty"`
	mu                  sync.Mutex
	ID                  uint32               `json:"id"`
	Start               time.Time            `json:"start"`
	End                 time.Time            `json:"end"`
	Contracts           map[uint32]byte      `json:"contracts"`
	Strategies          map[uint32]*Strategy `json:"strategies,omitempty"`
	VoteDeadlines44     map[uint32]time.Time `json:"vote_deadlines44,omitempty"`
	path                string
}

func loadWar(path string) (*War, error) {
	if worldLayoutsError22 != nil {
		return nil, worldLayoutsError22
	}
	w := &War{path: path}
	data, e := os.ReadFile(path)
	if os.IsNotExist(e) {
		w.ID = 1
		w.Start = time.Now().UTC().Truncate(24 * time.Hour)
		w.End = w.Start.Add(30 * 24 * time.Hour)
		w.Contracts = map[uint32]byte{}
		return w, w.save()
	}
	if e != nil {
		return nil, e
	}
	if e = json.Unmarshal(data, w); e != nil {
		return nil, e
	}
	if w.OperationGeneration > 357913856 || w.ID == 0 || w.Start.IsZero() || !w.End.After(w.Start) || w.End.Sub(w.Start) > 365*24*time.Hour {
		return nil, errors.New("invalid local war state; preserve war-state.json and report it")
	}
	if w.Contracts == nil {
		w.Contracts = map[uint32]byte{}
	}
	for _, c := range w.Contracts {
		if c > 4 {
			return nil, errors.New("invalid stored contract country")
		}
	}
	if e := w.validateCompanies(); e != nil {
		return nil, e
	}
	if e := w.validateWorld(); e != nil {
		return nil, e
	}
	if e := w.validateContracts26(); e != nil {
		return nil, e
	}
	if e := w.validateStrategies(); e != nil {
		return nil, e
	}
	return w, nil
}
func (w *War) save() error {
	d, e := json.MarshalIndent(w, "", "  ")
	if e != nil {
		return e
	}
	return atomicWrite(w.path, d)
}
func (w *War) rememberContract(id uint32, country byte) error {
	if id == 0 || country > 4 {
		return errors.New("invalid contract registration")
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	old, existed := w.Contracts[id]
	w.Contracts[id] = country
	if e := w.save(); e != nil {
		if existed {
			w.Contracts[id] = old
		} else {
			delete(w.Contracts, id)
		}
		return e
	}
	return nil
}
func u32(dst []byte, off int, v uint32) { binary.LittleEndian.PutUint32(dst[off:], v) }
func u16(dst []byte, off int, v uint16) { binary.LittleEndian.PutUint16(dst[off:], v) }

var regions = [4]byte{2, 6, 10, 14}
var attackers = [4]byte{1, 2, 3, 0}

func (w *War) fixed(dst []byte) {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.fixedLocked(dst)
}
func (w *War) fixedLocked(dst []byte) {
	territories, _ := w.territoryCounts26()
	// Four countries; existing client contract/payment code stays responsible for
	// negotiating and paying. These are campaign modifiers and world ownership.
	for i := 0; i < 4; i++ {
		o := 0x8c + 0x30*i
		for j := 0; j < 10; j++ {
			u16(dst, o+2*j, 100)
		}
		for j := 0; j < 8; j++ {
			dst[o+0x14+j] = 1
		}
		dst[o+0x1c] = 50
		dst[o+0x1d] = 1
		dst[o+0x1e] = 1
		if w.World != nil {
			w.writeCountryResearch39(dst, o, i)
		}
		u32(dst, o+0x20, 1)
		u32(dst, o+0x28, 1)
		u32(dst, o+0x2c, territories[i])
		f := 0x14c + 16*i
		for j := 0; j < 3; j++ {
			u32(dst, f+4*j, w.secretReward46(i, j))
		}
		dst[f+12] = regions[i]
		if w.World != nil {
			dst[f+12] = w.World.Fronts[i].Region
		}
		dst[f+13] = attackers[i]
		if w.World != nil {
			dst[f+13] = w.World.Fronts[i].Attacker
		}
		dst[f+14] = 0
	}
	for i := 0; i < 16; i++ {
		dst[0x1cc+i] = byte(i / 4)
		if w.World != nil {
			dst[0x1cc+i] = w.World.Owners[i]
		}
	}
	putDate(dst[0x18c:], w.Start)
	putDate(dst[0x198:], w.End)
	putDate(dst[0x1a4:], w.fightingEnd())
	putDate(dst[0x1b0:], w.End)
	u32(dst, 0x1bc, 1)
	u32(dst, 0x1c0, w.wireID())
	secs := uint32(w.End.Sub(w.Start) / time.Second)
	u32(dst, 0x1c4, 0) // preparation ends at campaign start
	if w.World != nil {
		secs = uint32(w.fightingEnd().Sub(w.Start)/time.Second) + 3600
	}
	u32(dst, 0x1c8, secs-3600) // fighting ends one hour before result deadline
	dst[0x1dc] = 1
}
func (w *War) now(dst []byte) {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.nowLocked(dst)
}
func (w *War) nowLocked(dst []byte) {
	for i := 0; i < 4; i++ {
		o := 0x8c + 0xf0*i
		u32(dst, o, 500)
		u32(dst, o+4, 500)
		for j := 0; j < 3; j++ {
			item := o + 8 + 0x44*j
			voteEnd := w.voteDeadline(w.operationID(i*3 + j))
			for _, d := range []int{0, 12, 24, 36} {
				dt := w.operationStart()
				if d == 12 || d == 24 {
					// Native voting checks operation +0x28. A past value sends
					// dummy API 5 instead of the actual placement API 28.
					// HUD/FinishPreparing use +0x30: freeze both to this deadline.
					dt = voteEnd
				}
				if d == 36 {
					dt = w.fightingEnd()
				}
				putDate(dst[item+d:], dt)
			}
			u32(dst, item+0x30, w.operationID(i*3+j))
			u32(dst, item+0x40, 100)
			dst[item+0x34] = byte(3 + j)
			if w.World != nil {
				dst[item+0x34] = w.World.Fronts[i].Bases[j]
				u32(dst, item+0x38, w.World.Fronts[i].Influence[0])
				u32(dst, item+0x3c, w.World.Fronts[i].Influence[1])
				u32(dst, item+0x40, max(uint32(10000), max(w.World.Fronts[i].Influence[0], w.World.Fronts[i].Influence[1])))
			}
		}
		u32(dst, o+0xd4, 1000)
		u32(dst, o+0xd8, 1000)
		dst[o+0xdc] = 3
		dst[o+0xdd] = 0
		dst[o+0xde] = 0
		for j := 0; j < 7; j++ {
			dst[o+0xe4+j] = byte(i)
			if j < 3 {
				dst[o+0xe4+j] = attackers[i]
			}
		}
		dst[o+0xed] = regions[i]
		if w.World != nil {
			f := w.World.Fronts[i]
			dst[o+0xed] = f.Region
			for j := 0; j < 7; j++ {
				dst[o+0xe4+j] = w.World.BaseOwners[f.Region][j]
			}
			u32(dst, o, f.Influence[0])
			u32(dst, o+4, f.Influence[1])
		}
	}
	u32(dst, 0x44c, w.wireID())
	dst[0x450] = 0 // 1 makes the original client report unavailable phase 3
	dst[0x451] = 1
	putDate(dst[0x454:], w.Start)
	putDate(dst[0x460:], w.End)
	u32(dst, 0x46c, 4)
	u32(dst, 0x470, 0)
}
func (w *War) contractStatus(dst []byte) {
	w.mu.Lock()
	defer w.mu.Unlock()
	dst[0x8c] = 1
	for c, row := range w.contractNations26() {
		u32(dst, 0x90+4*c, row.Total)
	}

}

// Each advertised, unjoined operation offers 60 seconds to vote. Entry freezes
// the latest advertised deadline as Began so polling and restarts cannot extend
// a joined operation's countdown. The client copies this deadline before entry.
func (w *War) voteDeadline(id uint32) time.Time {
	if s := w.Strategies[id]; s != nil {
		return s.Began
	}
	if w.VoteDeadlines44 == nil {
		w.VoteDeadlines44 = map[uint32]time.Time{}
	}
	deadline := time.Now().UTC().Add(60 * time.Second).Truncate(time.Second)
	if w.World != nil && deadline.After(w.fightingEnd()) {
		deadline = w.fightingEnd()
	}
	w.VoteDeadlines44[id] = deadline
	return deadline
}

// Each round changes fixed front identities. The native cache copies fixed data
// only on a new war ID; expose a round revision while retaining 30-minute state.
func (w *War) wireID() uint32 {
	if w.World == nil {
		return w.ID
	}
	return 0x40000000 | (w.ID << 3) | uint32(w.World.Round)
}
func campaignNumber(id uint32) uint32 {
	if id&0x40000000 != 0 {
		return (id & 0x3fffffff) >> 3
	}
	return id
}

// Both native front handlers must observe the same revision and map selection.
func (w *War) snapshot22(dst []byte) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	// Persist every advertised deadline before replying, so a restart between
	// selecting a map and entering it cannot create another voting minute.
	return w.change(func() error {
		w.fixedLocked(dst[1152:])
		w.nowLocked(dst[:1152])
		return nil
	})
}
