package main

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestBattle45AllMapsPartialChainsAndRetries(t *testing.T) {
	w := campaignWar(t)
	w.Strategies = map[uint32]*Strategy{}
	maps := 0
	for name, l := range worldLayouts22 {
		var region, base int
		fmt.Sscanf(name, "%d:%d", &region, &base)
		if !combatRegion(byte(region)) {
			continue
		}
		maps++
		for side := byte(0); side < 2; side++ {
			for _, kind := range []byte{0, 1, 2, 3, 4, 6, 7, 8, 9} {
				op := w.operationID(0)
				p := l.Spawns[side][0]
				w.World.Operations[op] = Operation{byte(region), byte(base), 0, 1, w.ID}
				s := &Strategy{Began: time.Now().UTC(), Objects: []FieldObject{{ID: 14, Type: kind, Side: 1 - side, X: p[0], Y: p[1], HP: 1000, MaxHP: 1000}}}
				w.Strategies[op] = s
				w.World.Receipts = map[string]bool{}
				req := campaignReq(w, 123, 33)
				u32(req, 0xa0, op)
				req[0xa4] = side
				u16(req, 0xcc, 14)
				req[0xc5] = 1
				req[0xc6] = 1
				req[0xc7] = 1 // overall flag remains 0 after retreat.
				for n := 0; n < 2; n++ {
					if err := w.campaignRequest(33, make([]byte, 144), req); err != nil {
						t.Fatal(err)
					}
				}
				if s.Objects[0].HP != 400 {
					t.Fatal(name, side, kind, "partial wins or retry")
				}
				req[0xca]++
				req[0xc7] = 0
				if err := w.campaignRequest(33, make([]byte, 144), req); err != nil {
					t.Fatal(err)
				}
				if s.Objects[0].HP != 0 {
					t.Fatal(name, side, kind, "five stage wins")
				}
			}
		}
	}
	if maps != 84 {
		t.Fatal(maps)
	}
}
func TestRank45ProgressCountsPersistenceAndCampaignTotals(t *testing.T) {
	w := campaignWar(t)
	op := w.operationID(0)
	req := campaignReq(w, 123, 23)
	u32(req, 0xa0, op)
	if ok, err := w.enter(make([]byte, 17000), req); !ok || err != nil {
		t.Fatal(ok, err)
	}
	s := w.Strategies[op]
	s.Began = time.Now().UTC().Add(-time.Minute)
	reply := make([]byte, 160)
	for i, score := range []uint32{0, 25, 75, 150, 300, 600, 1200} {
		for k := 0; k < 3; k++ {
			req[0xa5+k] = 7
			u32(req, 0xa8+4*k, score)
			u32(req, 0xb4+4*k, score)
		}
		for n := 0; n < 3; n++ {
			if err := w.campaignRequest(34, reply, req); err != nil {
				t.Fatal(err)
			}
		}
		for _, r := range reply[0x8c:0x8f] {
			if r != byte(6-i) {
				t.Fatal(score, r)
			}
		}
		counts := w.rankPopulation45(op, s, time.Now().UTC())
		for side := 0; side < 2; side++ {
			for metric := 0; metric < 3; metric++ {
				var total uint32
				for _, n := range counts[side][metric] {
					total += n
				}
				want := len(s.RankPopulation45.Companies[side])
				if side == 0 {
					want++
				}
				if total != uint32(want) {
					t.Fatal("points counted as people", score, total, want)
				}
			}
		}
	}
	if w.World.Ranks[123].Scores != [3]uint32{1200, 1200, 1200} {
		t.Fatal("retry score duplicated")
	}
	op2 := w.operationID(1)
	u32(req, 0xa0, op2)
	if ok, err := w.enter(make([]byte, 17000), req); !ok || err != nil {
		t.Fatal(ok, err)
	}
	for k := 0; k < 3; k++ {
		u32(req, 0xa8+4*k, 10)
		u32(req, 0xb4+4*k, 1210)
	}
	if err := w.campaignRequest(34, reply, req); err != nil {
		t.Fatal(err)
	}
	if w.World.Ranks[123].Scores != [3]uint32{1210, 1210, 1210} {
		t.Fatal("previous operation recredited", w.World.Ranks[123])
	}
	u32(req, 0xa0, op)
	s.Began = time.Now().UTC().Add(-10 * time.Minute)
	s.Finish37.End = time.Now().UTC().Add(-time.Second)
	q := make([]byte, 20000)
	if ok, err := w.strategyData(q, req); !ok || err != nil {
		t.Fatal(ok, err)
	}
	before := w.rankPopulation45(op, s, time.Now().UTC())
	reloaded, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	if reloaded.Strategies[op].RankPopulation45.Frozen == nil {
		t.Fatal("histogram not persisted")
	}
	reloaded.World.Ranks = map[uint32]*Rank{}
	after := reloaded.rankPopulation45(op, reloaded.Strategies[op], time.Now().UTC().Add(time.Hour))
	if before != after {
		t.Fatal("ended distribution changed")
	}
	for side := 0; side < 2; side++ {
		for metric := 0; metric < 3; metric++ {
			for rank := 0; rank < 8; rank++ {
				if binary.LittleEndian.Uint32(q[0x98+side*0xb4+0x54+metric*32+rank*4:]) != before[side][metric][rank] {
					t.Fatal("wire histogram")
				}
			}
		}
	}
	if dir := os.Getenv("GK_NATIVE45_FIXTURES"); dir != "" {
		os.MkdirAll(dir, 0700)
		os.WriteFile(filepath.Join(dir, "strategy45.plain"), q, 0600)
		os.WriteFile(filepath.Join(dir, "rank45.plain"), reply, 0600)
	}
}
func TestBattle45LateResultRetainsDamageWithoutNewCampaignCredit(t *testing.T) {
	w := campaignWar(t)
	w.Strategies = map[uint32]*Strategy{}
	op := w.operationID(0)
	req := campaignReq(w, 123, 33)
	u32(req, 0xa0, op)
	s := &Strategy{Began: time.Now().UTC(), Objects: []FieldObject{{ID: 14, Type: 0, Side: 1, X: 5, Y: 5, HP: 1000, MaxHP: 1000}}}
	w.Strategies[op] = s
	u16(req, 0xcc, 14)
	req[0xc5] = 1
	req[0xc6] = 1
	w.ID++
	w.World.Ranks = map[uint32]*Rank{}
	if err := w.campaignRequest(33, make([]byte, 144), req); err != nil {
		t.Fatal(err)
	}
	w.World.Receipts = map[string]bool{}
	if err := w.campaignRequest(33, make([]byte, 144), req); err != nil {
		t.Fatal(err)
	}
	if s.Objects[0].HP != 600 || len(w.World.Ranks) != 0 {
		t.Fatal("late result lost or credited next campaign")
	}
}

func TestContract45HonorsRequestedCountAcrossAllRounds(t *testing.T) {
	w := campaignWar(t)
	p := testProtocol(t)
	var endpoints []Endpoint
	json.Unmarshal(schemaData, &endpoints)
	b := &Backend{p: p, war: w}
	for _, count := range []byte{1, 3, 5} {
		for round := 0; round < 6; round++ {
			w.World.Round = round
			req := make([]byte, endpoints[13].RequestPadded)
			u32(req, 4, 0x3130786b)
			u32(req, 8, endpoints[13].OperationCode)
			u32(req, 12, uint32(endpoints[13].ResponseLogical))
			u32(req, 0x24, 123)
			req[0x9c] = 0
			req[0x9d] = count
			frame, status, err := b.response(endpoints[13], req)
			if err != nil || status != "OK" {
				t.Fatal(status, err)
			}
			q, err := p.decode(frame, true)
			if err != nil {
				t.Fatal(err)
			}
			got := binary.LittleEndian.Uint32(q[0x8c:])
			want := uint32(0x40000000) | ((w.ID + uint32(count)) << 3)
			if got != want {
				t.Fatal(count, round, got, want)
			}
		}
	}
}
func TestBattle45NativeHPWireFixtures(t *testing.T) {
	dir := os.Getenv("GK_NATIVE45_FIXTURES")
	if dir == "" {
		t.Skip("private native replay not requested")
	}
	w := campaignWar(t)
	op := w.operationID(0)
	req := campaignReq(w, 123, 23)
	u32(req, 0xa0, op)
	if ok, err := w.enter(make([]byte, 17000), req); !ok || err != nil {
		t.Fatal(ok, err)
	}
	s := w.Strategies[op]
	var target uint32
	for _, o := range s.Objects {
		if o.Side == 1 && o.Type == 0 {
			target = o.ID
			break
		}
	}
	if target == 0 {
		t.Fatal("HQ absent")
	}
	u16(req, 0xcc, uint16(target))
	req[0xc5] = 1
	req[0xc6] = 1
	req[0xc7] = 1
	if err := w.campaignRequest(33, make([]byte, 144), req); err != nil {
		t.Fatal(err)
	}
	q := make([]byte, 20000)
	if ok, err := w.strategyData(q, req); !ok || err != nil {
		t.Fatal(ok, err)
	}
	os.MkdirAll(dir, 0700)
	os.WriteFile(filepath.Join(dir, "siege45_partial.plain"), q, 0600)
	req[0xca]++
	req[0xc7] = 0
	if err := w.campaignRequest(33, make([]byte, 144), req); err != nil {
		t.Fatal(err)
	}
	q = make([]byte, 20000)
	if ok, err := w.strategyData(q, req); !ok || err != nil {
		t.Fatal(ok, err)
	}
	os.WriteFile(filepath.Join(dir, "siege45_destroyed.plain"), q, 0600)
}
