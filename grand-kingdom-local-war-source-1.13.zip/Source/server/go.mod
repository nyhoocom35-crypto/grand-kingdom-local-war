module gk-local

go 1.23
