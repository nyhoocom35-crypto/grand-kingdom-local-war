package main

import (
	"errors"
	"sort"
)

// The existing 24 ranked companies are the population, not display-only counters.
// Two home companies per country retain their contract; mobile companies renew
// at staggered 2-minute intervals and prefer countries that need more territory.
type AIContract26 struct {
	Country   byte   `json:"country"`
	Campaign  uint32 `json:"campaign"`
	RenewTick int64  `json:"renew_tick"`
}
type ContractNation26 struct {
	Country           byte    `json:"country"`
	Territories       uint32  `json:"territories"`
	CombatTerritories uint32  `json:"combat_territories"`
	AI                uint32  `json:"ai"`
	Player            uint32  `json:"player"`
	Total             uint32  `json:"total"`
	Percent           float64 `json:"percent"`
}

func (w *War) territoryCounts26() (all, combat [4]uint32) {
	for r := 0; r < 16; r++ {
		owner := initialOwners[r]
		if w.World != nil {
			owner = w.World.Owners[r]
		}
		if owner < 4 {
			all[owner]++
			if combatRegion(byte(r)) {
				combat[owner]++
			}
		}
	}
	return
}
func (w *War) resetAIContracts26() {
	w.AIContracts26 = map[uint32]AIContract26{}
	if w.World == nil {
		return
	}
	for id, r := range w.World.Ranks {
		if _, ok := aiCompany(id); !ok || !r.AI {
			continue
		}
		member := int64((id - 0xf0000000) % 100)
		w.AIContracts26[id] = AIContract26{r.Country, w.ID, w.World.Tick + 1 + (member+int64(id%17))%8}
	}
}
func (w *War) enableContracts26() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.World == nil {
		return nil
	}
	if w.AIContracts26 != nil {
		return w.validateContracts26()
	}
	return w.change(func() error { w.resetAIContracts26(); return nil })
}
func (w *War) validateContracts26() error {
	if w.AIContracts26 == nil {
		return nil
	}
	if w.World == nil || len(w.AIContracts26) != 24 {
		return errors.New("invalid AI contract population")
	}
	for id, a := range w.AIContracts26 {
		r := w.World.Ranks[id]
		_, ok := aiCompany(id)
		if !ok || r == nil || !r.AI || a.Country > 3 || r.Country != a.Country || a.Campaign != w.ID || a.RenewTick < 0 || a.RenewTick > 128 {
			return errors.New("invalid AI company contract")
		}
	}
	return nil
}
func mixContract26(v uint32) uint32 {
	v ^= v >> 16
	v *= 0x7feb352d
	v ^= v >> 15
	v *= 0x846ca68b
	return v ^ v>>16
}
func (w *War) renewAIContracts26(tick int64) {
	if w.AIContracts26 == nil {
		w.resetAIContracts26()
	}
	_, territories := w.territoryCounts26()
	weights := [4]uint32{}
	total := uint32(0)
	for c := range weights {
		weights[c] = 4 + 2*(12-territories[c])
		total += weights[c]
	}
	for id, a := range w.AIContracts26 {
		if tick < a.RenewTick {
			continue
		}
		if (id-0xf0000000)%100 >= 2 {
			pick := mixContract26(id^w.ID*0x9e3779b9^uint32(tick)*0x85ebca6b) % total
			for c, weight := range weights {
				if pick < weight {
					a.Country = byte(c)
					break
				}
				pick -= weight
			}
		}
		a.RenewTick = tick + 8
		w.AIContracts26[id] = a
		w.World.Ranks[id].Country = a.Country
	}
}
func (w *War) aiContractRanks26(country byte) []*Rank {
	rows := []*Rank{}
	for _, r := range w.World.Ranks {
		if r.AI && r.Country == country {
			rows = append(rows, r)
		}
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].ID < rows[j].ID })
	return rows
}
func (w *War) contractNations26() [4]ContractNation26 {
	all, combat := w.territoryCounts26()
	var rows [4]ContractNation26
	for c := range rows {
		rows[c] = ContractNation26{Country: byte(c), Territories: all[c], CombatTerritories: combat[c]}
	}
	if w.World != nil {
		for _, r := range w.World.Ranks {
			if r.AI && r.Country < 4 {
				rows[r.Country].AI++
			}
		}
	}
	for _, c := range w.Contracts {
		if c < 4 {
			rows[c].Player++
		}
	}
	total := uint32(0)
	for c := range rows {
		rows[c].Total = rows[c].AI + rows[c].Player
		total += rows[c].Total
	}
	if total > 0 {
		for c := range rows {
			rows[c].Percent = 100 * float64(rows[c].Total) / float64(total)
		}
	}
	return rows
}
