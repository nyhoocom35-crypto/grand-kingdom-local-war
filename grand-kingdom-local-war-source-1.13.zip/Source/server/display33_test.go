package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
)

func TestNamedDashboardKeepsCampaignAndWireIDs(t *testing.T) {
	w := campaignWar(t)
	w.Strategies = map[uint32]*Strategy{}
	w.World.Events = []string{
		"Round 2: country 0 vote selected region 0 base 0 (17 votes)",
		"Round 2: country 3 defeats country 2 at region 14, influence 80:70",
		"Territory 0 captured: country 0 -> 1",
		"Country 2 player ballot: region 8 base 23 weight 42",
		"Country 1 barrack 0 automatically selected item 7, level 3",
		"Campaign 1 finished",
		"Unrecognized future event retained",
	}
	for key, l := range worldLayouts22 {
		var region, base int
		if _, e := fmt.Sscanf(key, "%d:%d", &region, &base); e != nil {
			t.Fatal(e)
		}
		if !combatRegion(byte(region)) {
			continue
		}
		id := uint32(90000 + region*10 + base)
		w.World.Operations[id] = Operation{Region: byte(region), Base: byte(base), Attacker: 0, Defender: 3, Campaign: w.ID}
		s := &Strategy{Began: w.Start}
		w.ensureVotes25(id, s, l)
		w.Strategies[id] = s
	}
	if len(w.Strategies) != 84 {
		t.Fatal("missing map coverage", len(w.Strategies))
	}
	if e := w.save(); e != nil {
		t.Fatal(e)
	}
	before, _ := json.Marshal(w)
	diskBefore, _ := os.ReadFile(w.path)
	b := &Backend{war: w}
	var body []byte
	for i := 0; i < 3; i++ {
		rw := httptest.NewRecorder()
		if !b.statusHTTP(rw, httptest.NewRequest("GET", "/status.json", nil)) || rw.Code != 200 {
			t.Fatal("dashboard failed")
		}
		body = rw.Body.Bytes()
	}
	after, _ := json.Marshal(w)
	diskAfter, _ := os.ReadFile(w.path)
	if !bytes.Equal(before, after) || !bytes.Equal(diskBefore, diskAfter) {
		t.Fatal("display refresh changed campaign/state")
	}
	var data struct {
		DisplayNames33
		Revision int      `json:"display_revision"`
		Owners   [16]byte `json:"owners"`
		Events   []string `json:"events"`
		Strategy []struct {
			Map Operation `json:"map"`
		} `json:"strategy_votes"`
	}
	if e := json.Unmarshal(body, &data); e != nil {
		t.Fatal(e)
	}
	if data.Revision != 33 || len(data.Countries) != 4 || len(data.Regions) != 17 || len(data.Bases) != 17 {
		t.Fatal("incomplete catalog")
	}
	if data.Owners != w.World.Owners {
		t.Fatal("wire IDs changed")
	}
	for _, op := range data.Strategy {
		if regionName33(int(op.Map.Region)) == "알 수 없는 지역" || baseName33(int(op.Map.Region), int(op.Map.Base)) == "알 수 없는 거점" {
			t.Fatal("unknown battlefield")
		}
	}
	want := []string{
		"2라운드: 랜더스 침공 투표 — 에클리스 / 서쪽 숲 (17표)",
		"2라운드: 나이절에서 마기온 승리, 피엘 패배 (공격·방어 영향력 80:70)",
		"에클리스 영토 소유권: 랜더스 → 발키르",
		"피엘 플레이어 침공 투표: 네데 / 지역 전체 (42표)",
		"발키르 병영 병기 연구 자동 결정: 항목 7, 레벨 3",
		"캠페인 1 종료", "Unrecognized future event retained",
	}
	for i, e := range want {
		if data.Events[i] != e {
			t.Fatalf("event %d: %q", i, data.Events[i])
		}
	}
	if file := os.Getenv("GK33_CAPTURE"); file != "" {
		if e := os.WriteFile(file, body, 0600); e != nil {
			t.Fatal(e)
		}
	}
	rw := httptest.NewRecorder()
	b.statusHTTP(rw, httptest.NewRequest("GET", "/status", nil))
	if rw.Code != 200 || strings.Contains(rw.Body.String(), "원본 통신 번호") {
		t.Fatal("outdated page")
	}
}
