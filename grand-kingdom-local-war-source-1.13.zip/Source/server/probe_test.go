package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestOriginalAuxiliaryProbes(t *testing.T) {
	p := testProtocol(t)
	w, e := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p, war: w}
	before, e := os.ReadFile(w.path)
	if e != nil {
		t.Fatal(e)
	}
	for _, n := range []int{5, 6} {
		raw, e := os.ReadFile(fmt.Sprintf("testdata/%02d.request.bin", n))
		if e != nil {
			t.Fatal(e)
		}
		req, e := p.decode(raw, false)
		if e != nil {
			t.Fatal(e)
		}
		// The actual original fill writes random bytes, with no operation, side,
		// object ID or vote fields in this payload.
		distinct := map[byte]bool{}
		for _, v := range req[0x9c:0x49c] {
			distinct[v] = true
		}
		if len(distinct) < 100 {
			t.Fatal("fixture does not exercise the original random fill", n)
		}
		frame, status, e := b.response(eps[n], req)
		if e != nil || status != "OK" || len(frame) != eps[n].ResponseFrame {
			t.Fatal(n, status, e)
		}
		dec, e := p.decode(frame, true)
		if e != nil || string(dec[:4]) != "@suc" {
			t.Fatal(n, e)
		}
		if e = os.WriteFile(fmt.Sprintf("testdata/%02d.response.bin", n), frame, 0600); e != nil {
			t.Fatal(e)
		}
	}
	after, e := os.ReadFile(w.path)
	if e != nil || !bytes.Equal(before, after) {
		t.Fatal("stateless probe modified persistent state", e)
	}
}

func TestRealFailedVoteProbeReplay(t *testing.T) {
	root := os.Getenv("GK_VOTE_CAPTURE_DIR")
	if root == "" {
		t.Skip("private replay not requested")
	}
	p := testProtocol(t)
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p}
	files, e := os.ReadDir(root)
	if e != nil {
		t.Fatal(e)
	}
	seen := 0
	for _, f := range files {
		if !strings.HasSuffix(f.Name(), "_05.request.bin") {
			continue
		}
		raw, e := os.ReadFile(filepath.Join(root, f.Name()))
		if e != nil {
			t.Fatal(e)
		}
		req, e := p.decode(raw, false)
		if e != nil {
			t.Fatal(e)
		}
		frame, status, e := b.response(eps[5], req)
		if e != nil || status != "OK" {
			t.Fatal(status, e)
		}
		dec, e := p.decode(frame, true)
		if e != nil || string(dec[:4]) != "@suc" {
			t.Fatal(e)
		}
		seen++
	}
	if seen != 1 {
		t.Fatal("expected one vote-path auxiliary probe", seen)
	}
}
