package main

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
)

// GetBarrackData has eight selected-country category records, followed by
// four-country completion tables. GetFixedWarData independently carries the
// equipment counts consumed by the original national shop generator.
type ResearchCategory39 struct {
	Completed byte   `json:"completed"`
	Progress  uint32 `json:"progress"`
	Gold      uint32 `json:"gold"`
	Resources uint32 `json:"resources"`
}
type BarrackResearch39 struct {
	Version    int                         `json:"version"`
	Categories [4][2][4]ResearchCategory39 `json:"categories"`
}

func validateResearch39(b *BarrackResearch39) error {
	if b == nil {
		return nil
	}
	if b.Version != 39 {
		return errors.New("invalid saved barrack version")
	}
	for _, nation := range b.Categories {
		for _, kind := range nation {
			for _, r := range kind {
				if r.Completed > 46 || r.Progress >= 100 {
					return errors.New("invalid saved category research")
				}
			}
		}
	}
	return nil
}
func (w *War) ensureResearch39() {
	if w.World.Barrack39 != nil {
		return
	}
	b := &BarrackResearch39{Version: 39}
	for n := 0; n < 4; n++ {
		for k := 0; k < 2; k++ {
			// User-requested one-time reset: old completions, donations and
			// progress are cleared. Persisting Barrack39 prevents later resets.
			w.World.Research[n][k] = Research{Item: byte(k), Candidates: [4]byte{0, 1, 2, 3}}
		}
	}
	w.World.Barrack39 = b
	w.event("Barrack research reset once: all four countries start at zero under category research 39")
}
func researchRate39(nation, kind, category int) uint32 {
	order := (category - nation - kind + 8) % 4
	return [...]uint32{6, 1, 2, 3}[order]
}
func progressResearch39(r *ResearchCategory39, gain uint32) {
	if r.Completed >= 46 {
		r.Progress = 0
		return
	}
	p := uint64(r.Progress) + uint64(gain)
	steps := min(uint64(46-r.Completed), p/100)
	r.Completed += byte(steps)
	r.Progress = uint32(p % 100)
	if r.Completed == 46 {
		r.Progress = 0
	}
}
func (w *War) advanceResearch39(tick int64) {
	w.ensureResearch39()
	for n := 0; n < 4; n++ {
		for k := 0; k < 2; k++ {
			legacy := &w.World.Research[n][k]
			legacy.Progress = min(uint32(100), legacy.Progress+5)
			choice := (int(tick) + n*3 + k*7) % 4
			legacy.Votes[choice] = saturate(legacy.Votes[choice], uint32(1+(int(tick)+n+k)%3))
			for j := 0; j < 4; j++ {
				progressResearch39(&w.World.Barrack39.Categories[n][k][j], researchRate39(n, k, j))
			}
		}
	}
}
func (w *War) contributeResearch39(dst, req []byte) error {
	kind, category, nation := int(req[0xc4]), int(req[0xc5]), int(req[0xc6])
	if kind > 1 || category > 3 || nation > 3 {
		return errors.New("invalid barrack contribution category/country")
	}
	w.ensureResearch39()
	r := &w.World.Barrack39.Categories[nation][kind][category]
	id := binary.LittleEndian.Uint32(req[0x24:])
	digest := sha256.Sum256(req[0x9c:0xc8])
	key := fmt.Sprintf("research39:%d:%s", id, hex.EncodeToString(digest[:]))
	gain := uint32(0)
	if !w.World.Receipts[key] {
		// Native a0 is the previous personal total; a4 is THIS donation value.
		gold := binary.LittleEndian.Uint32(req[0xa4:])
		resources := uint32(0)
		for o := 0xa8; o <= 0xc0; o += 4 {
			resources = saturate(resources, binary.LittleEndian.Uint32(req[o:]))
		}
		r.Gold = saturate(r.Gold, gold)
		r.Resources = saturate(r.Resources, resources)
		gain = min(uint32(1000), saturate(gold/100, resources))
		progressResearch39(r, gain)
		legacy := &w.World.Research[nation][kind]
		legacy.Gold = saturate(legacy.Gold, gold)
		legacy.Resources = saturate(legacy.Resources, resources)
		legacy.Progress = min(uint32(100), saturate(legacy.Progress, gain))
		w.World.Receipts[key] = true
	}
	u32(dst, 0x8c, min(r.Gold, uint32(0x044aa200)))
	u32(dst, 0x90, gain)
	dst[0x94] = 0
	return nil
}

func (w *War) researchCounts39(nation, kind int) [4]byte {
	var result [4]byte
	if b := w.World.Barrack39; b != nil {
		for j, r := range b.Categories[nation][kind] {
			result[j] = r.Completed
		}
	} else {
		for j := range result {
			result[j] = w.World.Research[nation][kind].Level
		}
	}
	return result
}
func writeWeaponResearch39(dst []byte, base int, counts [4]byte) {
	// Original validators: percentages <=999, range/installation <=9,
	// support chance <=100. Wire fields are NOT equipment research levels.
	for j := 0; j < 10; j++ {
		category := min(3, j/2)
		u16(dst, base+2*j, min(uint16(999), 100+uint16(counts[category])*10))
	}
	for j := 0; j < 8; j++ {
		dst[base+0x14+j] = min(byte(9), 1+counts[min(3, j/2)]/2)
	}
	dst[base+0x1c] = min(byte(100), 50+counts[3])
}
func (w *War) writeCountryResearch39(dst []byte, base, nation int) {
	writeWeaponResearch39(dst, base, w.researchCounts39(nation, 0))
	counts := w.researchCounts39(nation, 1)
	copy(dst[base+0x24:base+0x28], counts[:])
}
func (w *War) writeResearch39(dst []byte, nation int) {
	for kind := 0; kind < 2; kind++ {
		for j := 0; j < 4; j++ {
			r := ResearchCategory39{Completed: w.World.Research[nation][kind].Level}
			if b := w.World.Barrack39; b != nil {
				r = b.Categories[nation][kind][j]
			}
			o := 0x8c + kind*0x30 + j*12
			seconds := uint32(0)
			if r.Completed < 46 {
				rate := researchRate39(nation, kind, j)
				seconds = (100 - r.Progress + rate - 1) / rate * 15
			}
			u32(dst, o, seconds*1000)
			// Both time fields are milliseconds on the wire. Donation totals
			// belong in API 11 and must never be interpreted as clock seconds.
			u32(dst, o+4, seconds*1000)
			dst[o+8] = byte(r.Progress)
			dst[o+9] = r.Completed
			dst[o+10] = 0 // Native nonzero flag formats the indefinite timer as 99:99.
		}
	}
	writeWeaponResearch39(dst, 0xec, w.researchCounts39(nation, 0))
	for n := 0; n < 4; n++ {
		for k := 0; k < 2; k++ {
			counts := w.researchCounts39(n, k)
			copy(dst[0x10c+k*16+n*4:], counts[:])
		}
	}
	u32(dst, 0x12c, w.wireID())
}
