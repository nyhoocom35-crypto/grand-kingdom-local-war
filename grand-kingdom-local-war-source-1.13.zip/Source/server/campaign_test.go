package main

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"
)

func campaignWar(t *testing.T) *War {
	t.Helper()
	w, e := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	if e = w.enableCampaign(time.Now().UTC().Truncate(time.Second)); e != nil {
		t.Fatal(e)
	}
	return w
}
func campaignReq(w *War, id uint32, api int) []byte {
	r := make([]byte, 256)
	copy(r[0x10:], "LOCAL_PLAYER")
	u32(r, 0x24, id)
	u32(r, 0x9c, w.wireID())
	return r
}
func TestCampaignClockCatchupAndRestart(t *testing.T) {
	w := campaignWar(t)
	start := w.Start
	w.Contracts[123] = 2
	if e := w.save(); e != nil {
		t.Fatal(e)
	}
	if e := w.advance(start.Add(17 * time.Minute)); e != nil {
		t.Fatal(e)
	}
	if w.World.Round != 3 || w.World.Tick != 68 {
		t.Fatal(w.World.Round, w.World.Tick)
	}
	d, _ := json.Marshal(w)
	reloaded, e := loadWar(w.path)
	if e != nil {
		t.Fatal(e)
	}
	if e = reloaded.enableCampaign(start.Add(time.Hour)); e != nil {
		t.Fatal(e)
	}
	if e = reloaded.advance(start.Add(17 * time.Minute)); e != nil {
		t.Fatal(e)
	}
	d2, _ := json.Marshal(reloaded)
	if string(d) != string(d2) {
		t.Fatal("restart altered clock or simulation")
	}
	direct := campaignWar(t)
	direct.Contracts[123] = 2
	for i := 1; i <= 68; i++ {
		if e := direct.advance(start.Add(time.Duration(i) * aiStep)); e != nil {
			t.Fatal(e)
		}
	}
	a, _ := json.Marshal(w.World)
	b, _ := json.Marshal(direct.World)
	if string(a) != string(b) {
		t.Fatal("catch-up diverged from live ticks")
	}
	if e = w.advance(start.Add(30 * time.Minute)); e != nil {
		t.Fatal(e)
	}
	if w.ID != 2 || w.Start != start.Add(30*time.Minute) || w.End.Sub(w.Start) != 30*time.Minute || len(w.World.History) != 1 || w.Contracts[123] != 2 {
		t.Fatal("rollover lost schedule/contracts/history")
	}
	if len(w.World.History[0].Ranks) != 24 {
		t.Fatal("AI ranking archive lost")
	}
	if e = w.advance(start.Add(25 * time.Hour)); e != nil {
		t.Fatal(e)
	}
	if w.ID != 51 || w.Start.After(start.Add(25*time.Hour)) || w.End.Before(start.Add(25*time.Hour)) {
		t.Fatal("offline jump", w.ID, w.Start, w.End)
	}
	if e = w.validateWorld(); e != nil {
		t.Fatal(e)
	}
}
func TestCampaignScoresVotesAndResearch(t *testing.T) {
	w := campaignWar(t)
	w.Contracts[123] = 0
	req := campaignReq(w, 123, 10)
	dst := make([]byte, 17000)
	// A large player vote must beat AI ballots and select the actual map layout.
	region := -1
	for i := 0; i < 16; i++ {
		if combatRegion(byte(i)) && w.World.Owners[i] != 0 && w.reachable(0, byte(i)) {
			region = i
			break
		}
	}
	if region < 0 {
		t.Fatal("no reachable targets")
	}
	u16(req, 0xa0, 9000)
	req[0xa2] = byte(region)
	req[0xa3] = 6
	if e := w.campaignRequest(10, dst, req); e != nil {
		t.Fatal(e)
	}
	if e := w.campaignRequest(10, dst, req); e != nil {
		t.Fatal(e)
	}
	if len(w.World.Votes) != 1 {
		t.Fatal("duplicate ballot")
	}
	w.selectFronts()
	f := w.World.Fronts[3]
	if f.Region != byte(region) || f.Bases[0] != 6 {
		t.Fatal("vote not used", f)
	}
	op := w.operationID(9)
	req = campaignReq(w, 123, 34)
	u32(req, 0xa0, op)
	u32(req, 0xbc, 10)
	if e := w.campaignRequest(34, dst, req); e != nil {
		t.Fatal(e)
	}
	if e := w.campaignRequest(34, dst, req); e != nil {
		t.Fatal(e)
	}
	if w.World.Ranks[123].Scores[2] != 10 || w.World.Fronts[3].Influence[0] != 11 || dst[0x8c] != 8 {
		t.Fatal("duplicate score or command mutation")
	}
	u32(req, 0xbc, 16)
	if e := w.campaignRequest(34, dst, req); e != nil {
		t.Fatal(e)
	}
	if w.World.Ranks[123].Scores[2] != 16 {
		t.Fatal("score accumulation")
	}
	req = campaignReq(w, 123, 11)
	req[0xc4] = 1
	req[0xc5] = 2
	u32(req, 0xa0, 5000)
	u32(req, 0xa8, 20)
	if e := w.campaignRequest(11, dst, req); e != nil {
		t.Fatal(e)
	}
	rs := w.World.Research[2][1]
	if e := w.campaignRequest(11, dst, req); e != nil {
		t.Fatal(e)
	}
	if w.World.Research[2][1] != rs || binary.LittleEndian.Uint32(dst[0x90:]) != 0 {
		t.Fatal("duplicate contribution")
	}
	if e := w.advance(w.Start.Add(5 * time.Minute)); e != nil {
		t.Fatal(e)
	}
	if w.World.Research[2][1].Level != 1 {
		t.Fatal("research did not resolve automatically")
	}
	req = campaignReq(w, 123, 33)
	u32(req, 0xa0, op)
	req[0xa5] = 1
	if e := w.campaignRequest(33, dst, req); e != nil {
		t.Fatal(e)
	}
	if e := w.campaignRequest(33, dst, req); e != nil {
		t.Fatal(e)
	}
	if w.World.Ranks[123].Wins != 1 {
		t.Fatal("duplicate battle")
	}
}
func TestCampaignOwnershipUsesInfluence(t *testing.T) {
	w := campaignWar(t)
	region := w.World.Fronts[0].Region
	attacker := w.World.Fronts[0].Attacker
	// Control overlap so a high margin captures three bases, then one more.
	for i := 1; i < 4; i++ {
		w.World.Fronts[i].Region = byte((int(region) + i) % 16)
		w.World.Fronts[i].Influence = [2]uint32{1, 1}
	}
	w.World.Fronts[0].Bases = [3]byte{0, 1, 2}
	w.World.Fronts[0].Influence = [2]uint32{900, 1}
	w.finishRound()
	if w.World.Owners[region] == attacker {
		t.Fatal("three of seven must not capture whole region")
	}
	w.World.Fronts[0].Bases = [3]byte{3, 4, 5}
	w.finishRound()
	if w.World.Owners[region] != attacker {
		t.Fatal("influence winner did not capture region")
	}
}
func TestCampaignOldMapAndWriteRollback(t *testing.T) {
	w := campaignWar(t)
	req := campaignReq(w, 123, 23)
	u32(req, 0xa0, w.operationID(0))
	dst := make([]byte, 2000)
	if ok, e := w.enter(dst, req); !ok || e != nil {
		t.Fatal(ok, e)
	}
	if e := w.advance(w.Start.Add(5 * time.Minute)); e != nil {
		t.Fatal(e)
	}
	if ok, e := w.strategyData(dst, req); !ok || e != nil {
		t.Fatal("in-flight operation lost", ok, e)
	}
	if ok, _ := w.enter(dst, req); !ok {
		t.Fatal("same-campaign operation lost at round boundary")
	}
	before, _ := json.Marshal(w)
	w.path = filepath.Join(t.TempDir(), "missing", "war.json")
	if e := w.advance(w.Start.Add(10 * time.Minute)); e == nil {
		t.Fatal("failed write accepted")
	}
	after, _ := json.Marshal(w)
	if string(before) != string(after) {
		t.Fatal("failed write mutated durable state")
	}
}
func TestCampaignConcurrentReadsAndAdvance(t *testing.T) {
	w := campaignWar(t)
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		for i := 0; i < 30; i++ {
			if e := w.advance(w.Start.Add(time.Duration(i) * time.Second)); e != nil {
				t.Error(e)
			}
		}
	}()
	go func() {
		defer wg.Done()
		for i := 0; i < 30; i++ {
			dst := make([]byte, 17000)
			req := campaignReq(w, 123, 43)
			w.fixed(dst)
			w.now(dst)
			w.barrackCountry(dst, 0)
			w.ranking(dst, req, 43)
		}
	}()
	wg.Wait()
}
func TestCampaignNativeFixtures(t *testing.T) {
	p := testProtocol(t)
	w := campaignWar(t)
	w.Contracts[123] = 0
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{war: w, p: p}
	dir := "testdata/campaign"
	os.MkdirAll(dir, 0700)
	for _, n := range []int{9, 10, 11, 12, 20, 21, 22, 33, 34, 43, 44} {
		req := make([]byte, eps[n].RequestPadded)
		u32(req, 4, 0x3130786b)
		u32(req, 8, eps[n].OperationCode)
		u32(req, 12, uint32(eps[n].ResponseLogical))
		copy(req[0x10:], "LOCAL_PLAYER")
		u32(req, 0x24, 123)
		u32(req, 0x9c, w.ID)
		switch n {
		case 10:
			u16(req, 0xa0, 10)
			req[0xa2] = 2
			req[0xa3] = 3
		case 11:
			u32(req, 0xa0, 1000)
		case 12:
			req[0x9c] = 0
			req[0x9d] = 0
			req[0x9e] = 0
			req[0x9f] = 0
		case 33, 34:
			u32(req, 0xa0, w.operationID(0))
			req[0xa4] = 1
			if n == 34 {
				u32(req, 0xbc, 10)
			}
		case 43, 44:
			req[0x9c] = 0
			req[0x9d] = 0
			req[0x9e] = 0
			req[0x9f] = 0
		}
		frame, status, e := b.response(eps[n], req)
		if e != nil || status != "OK" {
			t.Fatal(n, status, e)
		}
		decoded, e := p.decode(frame, true)
		if e != nil || string(decoded[:4]) != "@suc" {
			t.Fatal(n, e)
		}
		if e = os.WriteFile(fmt.Sprintf("%s/%02d.response.bin", dir, n), frame, 0600); e != nil {
			t.Fatal(e)
		}
	}
}
func TestWorldLayoutCoverageAndUniqueFronts(t *testing.T) {
	w := campaignWar(t)
	for region := 0; region < 16; region++ {
		for base := 0; base < 7; base++ {
			id := w.operationID(0)
			w.World.Operations[id] = Operation{byte(region), byte(base), 1, 0, w.ID}
			l, ok := w.layout(id)
			if !combatRegion(byte(region)) {
				if ok {
					t.Fatal("capital exposed as battle map")
				}
				continue
			}
			if !ok {
				t.Fatal("missing map", region, base)
			}
			for side := 0; side < 2; side++ {
				if len(l.Spawns[side]) != 10 || len(l.Objects[side]) != 9 {
					t.Fatal("incomplete map", region, base)
				}
				for _, p := range l.Spawns[side] {
					if p != [2]byte{0, 0} && (p[0] == 0 || p[1] == 0 || p[0] > 50 || p[1] > 50) {
						t.Fatal("bad spawn", region, base, p)
					}
				}
			}
		}
	}
	for i := 0; i < 30; i++ {
		if e := w.advance(w.Start.Add(time.Duration(i) * aiStep)); e != nil {
			t.Fatal(e)
		}
		seen := map[byte]bool{}
		for _, f := range w.World.Fronts {
			if seen[f.Region] {
				t.Fatal("native front lookup would be ambiguous")
			}
			seen[f.Region] = true
		}
	}
}
func TestCapturedBattleAndScore14(t *testing.T) {
	dir := os.Getenv("GK_CAMPAIGN_CAPTURE_DIR")
	if dir == "" {
		t.Skip("GK_CAMPAIGN_CAPTURE_DIR required")
	}
	p := testProtocol(t)
	w := campaignWar(t)
	for _, api := range []int{33, 34} {
		entries, e := os.ReadDir(dir)
		if e != nil {
			t.Fatal(e)
		}
		var raw []byte
		for _, f := range entries {
			if len(f.Name()) >= len("_33.request.bin") && f.Name()[len(f.Name())-len("_33.request.bin"):] == fmt.Sprintf("_%02d.request.bin", api) {
				raw, e = os.ReadFile(filepath.Join(dir, f.Name()))
				if e != nil {
					t.Fatal(e)
				}
				break
			}
		}
		if raw == nil {
			t.Fatal("capture absent", api)
		}
		req, e := p.decode(raw, false)
		if e != nil {
			t.Fatal(e)
		}
		u32(req, 0x9c, w.ID)
		u32(req, 0xa0, w.operationID(0))
		dst := make([]byte, 160)
		if e = w.campaignRequest(api, dst, req); e != nil {
			t.Fatal(e)
		}
		if e = w.campaignRequest(api, dst, req); e != nil {
			t.Fatal(e)
		}
		id := binary.LittleEndian.Uint32(req[0x24:])
		r := w.World.Ranks[id]
		if api == 33 && r.Losses != 1 {
			t.Fatal("actual captured defeat not stored once")
		}
		if api == 34 && r.Scores[2] != 10 {
			t.Fatal("actual captured ten-point score not stored once")
		}
	}
}

func TestArchivedCampaignNativeResult(t *testing.T) {
	p := testProtocol(t)
	w := campaignWar(t)
	start := w.Start
	if e := w.advance(start.Add(30 * time.Minute)); e != nil {
		t.Fatal(e)
	}
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{war: w, p: p}
	req := make([]byte, eps[22].RequestPadded)
	u32(req, 4, 0x3130786b)
	u32(req, 8, eps[22].OperationCode)
	u32(req, 12, uint32(eps[22].ResponseLogical))
	u32(req, 0x9c, 1)
	frame, status, e := b.response(eps[22], req)
	if e != nil || status != "OK" {
		t.Fatal(status, e)
	}
	decoded, e := p.decode(frame, true)
	if e != nil || decoded[0xae] == 0xff {
		t.Fatal("archived front result absent", e)
	}
	if e = os.WriteFile("testdata/campaign/22.archived.response.bin", frame, 0600); e != nil {
		t.Fatal(e)
	}
}
