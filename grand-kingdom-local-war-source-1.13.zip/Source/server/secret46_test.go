package main

import (
	"bytes"
	"encoding/binary"
	"testing"
)

func TestSecret46SlotsStableAcrossPollingAndRestart(t *testing.T) {
	w := campaignWar(t)
	first := make([]byte, 0x200)
	w.fixed(first)
	for front := 0; front < 4; front++ {
		seen := map[uint32]bool{}
		for slot := 0; slot < 3; slot++ {
			id := binary.LittleEndian.Uint32(first[0x14c+16*front+4*slot:])
			valid := false
			for _, known := range secretItems46 {
				if id == known {
					valid = true
				}
			}
			if !valid || seen[id] {
				t.Fatal("invalid or duplicate secret item", front, id)
			}
			seen[id] = true
		}
	}
	if err := w.save(); err != nil {
		t.Fatal(err)
	}
	w, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	second := make([]byte, len(first))
	w.fixed(second)
	if !bytes.Equal(first, second) {
		t.Fatal("secret rewards changed on restart")
	}
}
