package main

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"sort"
	"time"
)

// Native rank codes are S=0 through F=6; 7 is unranked and 8 means keep.
// Local-server balance: operation accomplishments, separately for each metric.
var rankThresholds45 = [...]uint32{1200, 600, 300, 150, 75, 25, 0}

func scoreRank45(score uint32) byte {
	for rank, floor := range rankThresholds45 {
		if score >= floor {
			return byte(rank)
		}
	}
	return 6
}

// RegisterBattle's overall flag is not the count of victories in a five-fight
// encounter. Native 81061e52 writes 1 for each won stage, 81061f4c writes 0 for
// each lost stage, and 81068e3a serializes these to c5:c9, even after retreat.
func battleWins45(req []byte) byte {
	var wins byte
	for _, result := range req[0xc5:0xca] {
		if result == 1 {
			wins++
		}
	}
	// Compatibility with older local tools that sent only the overall flag.
	if wins == 0 && req[0xa5] == 1 {
		wins = 1
	}
	return wins
}
func (w *War) recordBattle45(req []byte, r *Rank) {
	player := binary.LittleEndian.Uint32(req[0x24:])
	op := binary.LittleEndian.Uint32(req[0xa0:])
	digest := sha256.Sum256(req[0x9c:0xd2])
	key := fmt.Sprintf("battle:%d:%s", player, hex.EncodeToString(digest[:]))
	s := w.Strategies[op]
	if s != nil && s.BattleReceipts45 == nil {
		s.BattleReceipts45 = map[string]bool{}
	}
	duplicate := w.World.Receipts[key] || s != nil && s.BattleReceipts45[key]
	if s != nil {
		s.BattleReceipts45[key] = true
	}
	if duplicate {
		return
	}
	w.World.Receipts[key] = true
	if r != nil {
		if req[0xa5] == 1 {
			r.Wins++
		} else {
			r.Losses++
		}
	}
	if s := w.Strategies[op]; s != nil {
		for n := battleWins45(req); n > 0; n-- {
			applySiegeVictory40(s, uint32(binary.LittleEndian.Uint16(req[0xcc:])), req[0xa4])
		}
	}
}

// Persist the actual AI company roster of each participating nation. This
// keeps an ended operation's distribution stable across polls, renegotiated
// AI contracts, restarts and subsequent campaigns.
type RankPopulation45 struct {
	Companies [2][]uint32      `json:"companies"`
	Frozen    *[2][3][8]uint32 `json:"frozen,omitempty"`
}

func (w *War) ensureRankPopulation45(id uint32, s *Strategy) bool {
	if s.RankPopulation45 != nil {
		return false
	}
	p := &RankPopulation45{}
	if w.World == nil {
		s.RankPopulation45 = p
		return true
	}
	op := w.World.Operations[id]
	ranks := []Rank{}
	for _, r := range w.World.Ranks {
		ranks = append(ranks, *r)
	}
	if op.Campaign != w.ID {
		for _, history := range w.World.History {
			if history.ID == op.Campaign {
				ranks = history.Ranks
				break
			}
		}
	}
	for side, country := range []byte{op.Attacker, op.Defender} {
		for _, r := range ranks {
			if r.AI && r.Country == country {
				p.Companies[side] = append(p.Companies[side], r.ID)
			}
		}
		sort.Slice(p.Companies[side], func(i, j int) bool { return p.Companies[side][i] < p.Companies[side][j] })
	}
	s.RankPopulation45 = p
	return true
}
func (w *War) rankPopulation45(id uint32, s *Strategy, now time.Time) [2][3][8]uint32 {
	w.ensureRankPopulation45(id, s)
	p := s.RankPopulation45
	if p.Frozen != nil {
		return *p.Frozen
	}
	var counts [2][3][8]uint32
	elapsed := now.Sub(s.Began)
	if f := s.Finish37; f != nil && f.Completed {
		elapsed = f.End.Sub(s.Began)
	}
	tick := max(int64(0), min(int64(120), int64(elapsed/aiStep)))
	for side := 0; side < 2; side++ {
		for _, company := range p.Companies[side] {
			for metric := 0; metric < 3; metric++ {
				rate := uint32(1 + (uint64(id)+uint64(company)*5+uint64(metric)*3)%16)
				score := uint32(tick) * rate
				counts[side][metric][scoreRank45(score)]++
			}
		}
	}
	if s.Votes != nil {
		for _, player := range s.Votes.Policy {
			for metric, score := range player.Points {
				counts[player.Side][metric][scoreRank45(score)]++
			}
		}
	}
	if s.Finish37 != nil && s.Finish37.Completed {
		p.Frozen = &counts
	}
	return counts
}

// Status reads do not mutate operation state.
func (w *War) rankPopulationView45(id uint32, s *Strategy, now time.Time) [2][3][8]uint32 {
	clone := *s
	if s.RankPopulation45 != nil {
		p := *s.RankPopulation45
		clone.RankPopulation45 = &p
	}
	return w.rankPopulation45(id, &clone, now)
}
