package main

import (
	"bytes"
	"encoding/binary"
	"os"
	"path/filepath"
	"testing"
)

func TestRivals46AllNationsAndLevels(t *testing.T) {
	w := campaignWar(t)
	for nation := byte(0); nation < 4; nation++ {
		for _, level := range []byte{1, 5, 30, 99} {
			_, req := request16(t, 37)
			req[0x9c], req[0x9e] = nation, level
			d := make([]byte, 39260)
			if !w.rivals46(d, req) {
				t.Fatal("valid rivals rejected")
			}
			repeat := make([]byte, len(d))
			w.rivals46(repeat, req)
			if !bytes.Equal(d, repeat) {
				t.Fatal("retry changed rival roster")
			}
			ai, npc := 0, 0
			styles := map[string]bool{}
			for i := 0; i < 30; i++ {
				o := 0x8c + i*rivalRow46
				id := binary.LittleEndian.Uint32(d[o:])
				if id == 0 {
					npc++
					continue
				}
				ai++
				if r := w.World.Ranks[id]; r == nil || !r.AI || r.Country != nation {
					t.Fatal("uncontracted AI appeared", nation, id)
				}
				troop := d[o+0x18 : o+0x18+troopSize]
				if binary.LittleEndian.Uint32(troop) != 8 || d[o+0x15] >= 6 {
					t.Fatal("invalid native troop header")
				}
				if binary.LittleEndian.Uint16(troop[0xdc:]) > 20 || troop[0xde] > 79 {
					t.Fatal("unknown piece or flag")
				}
				styles[string(troop[0xdc:0xe1])] = true
				for j := 0; j < 4; j++ {
					u := troop[276+j*202:]
					if u[0x28] < 1 || u[0x28] > 99 || u[2] > 4 || u[3] > 3 {
						t.Fatal("invalid level or appearance")
					}
				}
			}
			if ai != 20 || npc != 10 || len(styles) < 12 {
				t.Fatal("missing mixed/varied opponents", ai, npc, len(styles))
			}
			if out := os.Getenv("GK_RIVAL46_FIXTURES"); out != "" && level == 5 {
				if err := os.MkdirAll(out, 0700); err != nil {
					t.Fatal(err)
				}
				if err := os.WriteFile(filepath.Join(out, "nation"+jsonNumber(int(nation))+".plain"), d, 0600); err != nil {
					t.Fatal(err)
				}
			}
		}
	}
	_, bad := request16(t, 37)
	bad[0x9c] = 4
	if w.rivals46(make([]byte, 39260), bad) || w.rivals46(make([]byte, 100), bad) {
		t.Fatal("invalid response accepted")
	}
}

func TestRivals46NoContractedAIUsesNPC(t *testing.T) {
	w := campaignWar(t)
	for _, r := range w.World.Ranks {
		r.Country = 1
	}
	_, req := request16(t, 37)
	req[0x9c] = 0
	d := make([]byte, 39260)
	if !w.rivals46(d, req) || !bytes.Equal(d, make([]byte, len(d))) {
		t.Fatal("NPC fallback changed")
	}
}

func TestRivals46ProtocolFrame(t *testing.T) {
	p := testProtocol(t)
	w := campaignWar(t)
	b := &Backend{p: p, war: w}
	for nation := byte(0); nation < 4; nation++ {
		ep, req := request16(t, 37)
		req[0x9c], req[0x9e] = nation, 5
		frame, status, err := b.response(ep, req)
		if err != nil || status != "OK" || len(frame) != ep.ResponseFrame {
			t.Fatal("rival frame", nation, status, len(frame), err)
		}
		plain, err := p.decode(frame, true)
		if err != nil || len(plain) < ep.ResponseLogical || string(plain[:4]) != "@suc" {
			t.Fatal("rival decode", nation, err)
		}
		want := make([]byte, len(plain))
		copy(want, "@suc")
		if !w.rivals46(want, req) || !bytes.Equal(plain[0x8c:], want[0x8c:]) {
			t.Fatal("serialized AI roster changed in protocol", nation)
		}
	}
}
