package main

import (
	"encoding/json"
	"fmt"
)

var worldLayouts22, worldLayoutsError22 = parseCatalog22(worldLayoutData)

func parseCatalog22(data []byte) (map[string]Layout, error) {
	var catalog map[string]Layout
	if err := json.Unmarshal(data, &catalog); err != nil {
		return nil, err
	}
	if len(catalog) != 112 {
		return nil, fmt.Errorf("world catalog requires all 16 regions x 7 bases")
	}
	for region := 0; region < 16; region++ {
		for base := 0; base < 7; base++ {
			key := fmt.Sprintf("%d:%d", region, base)
			l, found := catalog[key]
			if !found {
				return nil, fmt.Errorf("missing world layout %s", key)
			}
			for side := 0; side < 2; side++ {
				if len(l.Spawns[side]) != 10 || len(l.Objects[side]) != 9 {
					return nil, fmt.Errorf("incomplete layout %s side %d", key, side)
				}
				if combatRegion(byte(region)) && l.Spawns[side][0] == [2]byte{} {
					return nil, fmt.Errorf("missing player spawn %s side %d", key, side)
				}
				for _, p := range l.Spawns[side] {
					if p != [2]byte{} && (p[0] == 0 || p[1] == 0 || p[0] > 50 || p[1] > 50) {
						return nil, fmt.Errorf("invalid spawn %s", key)
					}
				}
				for _, p := range l.Objects[side] {
					if p[0] > 3 || ((p[1] != 0 || p[2] != 0) && (p[1] == 0 || p[2] == 0 || p[1] > 50 || p[2] > 50)) {
						return nil, fmt.Errorf("invalid field object %s", key)
					}
				}
			}
		}
	}
	return catalog, nil
}
