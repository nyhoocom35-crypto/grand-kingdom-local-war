package main

import (
	"encoding/binary"
	"os"
	"testing"
)

// Replay the actual native RegisterScore payload's three cumulative totals.
// The native patch already triples gains; the server must credit the exact
// delta once, with no extra multiplier or duplicate credit on retries.
func TestNativeMerit38ForwardedExactlyOnce(t *testing.T) {
	path := os.Getenv("GK38_NATIVE_SCORE")
	if path == "" {
		t.Skip("native private fixture not requested")
	}
	native, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(native) < 0xc0 {
		t.Fatal("short native fixture")
	}
	w := campaignWar(t)
	id, _, _, _ := orderMap36(t, w, 0, 0)
	w.Contracts[123] = 0
	req := campaignReq(w, 123, 34)
	u32(req, 0xa0, id)
	dst := make([]byte, 1712)
	for i := 0; i < 3; i++ {
		u32(req, 0xb4+i*4, uint32(100*(i+1)))
	}
	if err := w.campaignRequest(34, dst, req); err != nil {
		t.Fatal(err)
	}
	copy(req[0xa8:0xc0], native[0xa8:0xc0])
	for retry := 0; retry < 2; retry++ {
		if err := w.campaignRequest(34, dst, req); err != nil {
			t.Fatal(err)
		}
		for i := 0; i < 3; i++ {
			if got := w.World.Ranks[123].Scores[i]; got != binary.LittleEndian.Uint32(native[0xb4+i*4:]) {
				t.Fatal("native merit altered or credited twice", i, got)
			}
		}
	}
}
