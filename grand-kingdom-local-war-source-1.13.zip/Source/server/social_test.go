package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestEmptyLocalSocialDirectoryAndActualFailedRequest(t *testing.T) {
	p := testProtocol(t)
	w, e := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p, war: w}
	before, e := os.ReadFile(w.path)
	if e != nil {
		t.Fatal(e)
	}
	raw, e := os.ReadFile("testdata/40.request.bin")
	if e != nil {
		t.Fatal(e)
	}
	check := func(raw []byte) []byte {
		t.Helper()
		req, e := p.decode(raw, false)
		if e != nil {
			t.Fatal(e)
		}
		frame, status, e := b.response(eps[40], req)
		if e != nil || status != "OK" {
			t.Fatal(status, e)
		}
		d, e := p.decode(frame, true)
		if e != nil || string(d[:4]) != "@suc" || len(frame) != eps[40].ResponseFrame {
			t.Fatal("social framing", e)
		}
		if !bytes.Equal(d[0x8c:0x3ac], make([]byte, 800)) {
			t.Fatal("nonempty social IDs")
		}
		return frame
	}
	frame := check(raw)
	if e = os.WriteFile("testdata/40.response.bin", frame, 0600); e != nil {
		t.Fatal(e)
	}
	if root := os.Getenv("GK_OPERATION_CAPTURE_DIR"); root != "" {
		entries, e := os.ReadDir(root)
		if e != nil {
			t.Fatal(e)
		}
		seen := 0
		for _, f := range entries {
			if strings.HasSuffix(f.Name(), "_40.request.bin") {
				raw, e := os.ReadFile(filepath.Join(root, f.Name()))
				if e != nil {
					t.Fatal(e)
				}
				check(raw)
				seen++
			}
		}
		if seen == 0 {
			t.Fatal("actual failing social request missing")
		}
	}
	after, e := os.ReadFile(w.path)
	if e != nil || !bytes.Equal(before, after) {
		t.Fatal("read-only directory changed war state", e)
	}
}
