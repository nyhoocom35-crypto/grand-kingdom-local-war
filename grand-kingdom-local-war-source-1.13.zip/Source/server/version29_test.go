package main

import (
	"encoding/json"
	"net/http/httptest"
	"testing"
)

func TestServer29StatusVersion(t *testing.T) {
	b := &Backend{war: campaignWar(t)}
	rw := httptest.NewRecorder()
	if !b.statusHTTP(rw, httptest.NewRequest("GET", "/status.json", nil)) || rw.Code != 200 {
		t.Fatal("status unavailable")
	}
	var data map[string]any
	if err := json.Unmarshal(rw.Body.Bytes(), &data); err != nil {
		t.Fatal(err)
	}
	if data["server_version"] != float64(29) || data["snapshot_protocol"] != float64(22) {
		t.Fatal("wrong server version")
	}
}
