package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func orderMap36(t *testing.T, w *War, region, base byte) (uint32, *Strategy, Layout, []byte) {
	t.Helper()
	w.OperationGeneration++
	id := w.operationID(0)
	w.World.Operations[id] = Operation{region, base, 0, 1, w.ID}
	req := campaignReq(w, 123, 23)
	u32(req, 0xa0, id)
	if ok, err := w.enter(make([]byte, 1600), req); !ok || err != nil {
		t.Fatal(region, base, err)
	}
	l, ok := w.layout(id)
	if !ok {
		t.Fatal("missing map")
	}
	s := w.Strategies[id]
	s.Began = time.Now().UTC().Add(time.Minute)
	w.ensureVotes25(id, s, l)
	return id, s, l, req
}

func commandSum36(v [2][6]byte) int {
	n := 0
	for _, side := range v {
		for _, x := range side {
			n += int(x)
		}
	}
	return n
}

func TestOrders36All84MapsTimeRestartAndNewCampaign(t *testing.T) {
	w := campaignWar(t)
	seen := [6]bool{}
	maps := 0
	for region := byte(0); region < 16; region++ {
		if !combatRegion(region) {
			continue
		}
		for base := byte(0); base < 7; base++ {
			id, s, l, _ := orderMap36(t, w, region, base)
			start := s.Began
			for _, sec := range []int{0, 59, 60, 61, 179, 180, 181, 1800, 86400} {
				w.updateVotes25(id, s, l, start.Add(time.Duration(sec)*time.Second))
				got := s.Votes.commandCounts25()
				want := 0
				if sec >= 60 {
					want = 1
				}
				if sec >= 180 {
					want = 2
				}
				if commandSum36(got) != want || s.Votes.orderTotal36(0) > 1 || s.Votes.orderTotal36(1) > 1 {
					t.Fatal(region, base, sec, got)
				}
				before, _ := json.Marshal(s)
				w.updateVotes25(id, s, l, start.Add(time.Duration(sec)*time.Second))
				after, _ := json.Marshal(s)
				if !bytes.Equal(before, after) {
					t.Fatal("same poll changed orders")
				}
				if err := w.save(); err != nil {
					t.Fatal(err)
				}
				loaded, err := loadWar(w.path)
				if err != nil {
					t.Fatal(err)
				}
				w = loaded
				s = w.Strategies[id]
				if commandSum36(s.Votes.commandCounts25()) != want {
					t.Fatal("restart reset activation allowance")
				}
			}
			for _, side := range s.Votes.commandCounts25() {
				for kind, n := range side {
					if n > 0 {
						seen[kind] = true
					}
				}
			}
			maps++
		}
	}
	if maps != 84 {
		t.Fatal(maps)
	}
	for kind, yes := range seen {
		if !yes {
			t.Fatal("AI order kind missing across maps", kind)
		}
	}
	// A new campaign/operation gets its own allowance; the old one stays spent.
	if err := w.advance(w.End.Add(time.Second)); err != nil {
		t.Fatal(err)
	}
	id, s, l, _ := orderMap36(t, w, 0, 0)
	if commandSum36(s.Votes.commandCounts25()) != 0 {
		t.Fatal("new campaign inherited spent orders")
	}
	w.updateVotes25(id, s, l, s.Began.Add(30*time.Minute))
	if commandSum36(s.Votes.commandCounts25()) != 2 {
		t.Fatal("new campaign order budget")
	}
}

func TestOrders36PlayerAndAIShareLimitAllSixKindsAndRetries(t *testing.T) {
	for kind := 0; kind < 6; kind++ {
		w := campaignWar(t)
		id, s, l, req := orderMap36(t, w, 0, 0)
		req[0xae+kind] = 255
		d := make([]byte, 160)
		for retry := 0; retry < 4; retry++ {
			if ok, err := w.registerOrder25(d, req); !ok || err != nil {
				t.Fatal(err)
			}
			if d[0x8c+kind] != 1 || commandSum36(s.Votes.commandCounts25()) != 1 {
				t.Fatal("accepted player order", kind, d[0x8c:0x92])
			}
		}
		// Another player/another kind cannot spend the same army's allowance.
		u32(req, 0x24, 124)
		clear(req[0xae:0xb4])
		req[0xae+(kind+1)%6] = 1
		if ok, err := w.registerOrder25(d, req); !ok || err != nil {
			t.Fatal(err)
		}
		if commandSum36(s.Votes.commandCounts25()) != 1 {
			t.Fatal("second player bypassed limit")
		}
		// The original player switching sides retains its old receipt/army.
		u32(req, 0x24, 123)
		req[0xa4] = 1
		if ok, err := w.registerOrder25(d, req); !ok || err != nil {
			t.Fatal(err)
		}
		if s.Votes.Commands[123].Side != 0 || commandSum36(s.Votes.commandCounts25()) != 1 {
			t.Fatal("switching sides refunded order")
		}
		w.updateVotes25(id, s, l, s.Began.Add(time.Hour))
		if commandSum36(s.Votes.commandCounts25()) != 2 || s.Votes.AICommands[0] != [6]byte{} {
			t.Fatal("AI duplicated player's order")
		}
	}
}

func TestOrders36LegacyMigrationPreservesBattleAndVotes(t *testing.T) {
	w := campaignWar(t)
	id, s, l, _ := orderMap36(t, w, 0, 0)
	w.updateVotes25(id, s, l, s.Began)
	s.Votes.OrderRevision36 = 0
	s.Votes.AITick = 120
	s.Votes.AICommands = [2][6]byte{{20, 20, 20, 20, 20, 20}, {20, 20, 20, 20, 20, 20}}
	s.Votes.Commands[123] = CommandReceipt25{Side: 0, Counts: [6]byte{7, 7, 7, 7, 7, 7}}
	beforeObjects, _ := json.Marshal(s.Objects)
	beforePolicy := s.Votes.policyCounts25()
	beforePlacement := s.Votes.placementCounts25()
	start := s.Began
	if err := w.save(); err != nil {
		t.Fatal(err)
	}
	w, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	s = w.Strategies[id]
	if !w.updateVotes25(id, s, l, start.Add(time.Hour)) {
		t.Fatal("old orders not migrated")
	}
	afterObjects, _ := json.Marshal(s.Objects)
	if !bytes.Equal(beforeObjects, afterObjects) || beforePolicy != s.Votes.policyCounts25() || beforePlacement != s.Votes.placementCounts25() {
		t.Fatal("migration changed battlefield or votes")
	}
	if commandSum36(s.Votes.commandCounts25()) != 2 || s.Votes.orderTotal36(0) != 1 || s.Votes.orderTotal36(1) != 1 {
		t.Fatal("legacy backlog still excessive")
	}
	if w.updateVotes25(id, s, l, start.Add(2*time.Hour)) {
		t.Fatal("legacy operation resumed spending")
	}
	if err := w.save(); err != nil {
		t.Fatal(err)
	}
	if _, err := loadWar(w.path); err != nil {
		t.Fatal(err)
	}
}

func TestOrders36WriteFailureRollsBackPlayerBudget(t *testing.T) {
	w := campaignWar(t)
	_, s, _, req := orderMap36(t, w, 0, 0)
	req[0xae] = 1
	before, _ := json.Marshal(w)
	w.path = filepath.Join(t.TempDir(), "absent", "state.json")
	if ok, err := w.registerOrder25(make([]byte, 160), req); ok || err == nil {
		t.Fatal("save failure accepted order")
	}
	after, _ := json.Marshal(w)
	if !bytes.Equal(before, after) {
		t.Fatal("write failure spent order")
	}
	_ = s
}

func TestOrders36NativeCommandFrames(t *testing.T) {
	root := os.Getenv("GK36_NATIVE_CAPTURE")
	if root == "" {
		t.Skip("private native frame output not requested")
	}
	p := testProtocol(t)
	for kind := 0; kind < 6; kind++ {
		w := campaignWar(t)
		id, s, l, req := orderMap36(t, w, 0, 0)
		b := &Backend{p: p, war: w}
		meta, _ := json.Marshal(map[string]any{"id": id, "wire": w.wireID(), "region": 0, "base": 0, "side": 0})
		if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("%d_meta.json", kind)), meta, 0600); err != nil {
			t.Fatal(err)
		}
		emit := func(label string, api int) {
			ep, r := request16(t, api)
			copy(r[0x9c:], req[0x9c:])
			frame, status, err := b.response(ep, r)
			if err != nil || status != "OK" {
				t.Fatal(status, err)
			}
			if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("%d_%s_%02d.response.bin", kind, label, api)), frame, 0600); err != nil {
				t.Fatal(err)
			}
		}
		emit("enter", 23)
		req[0xae+kind] = 255
		emit("accepted", 31)
		emit("retry", 31)
		clear(req[0xae:0xb4])
		req[0xae+(kind+1)%6] = 255
		emit("limited", 31)
		w.updateVotes25(id, s, l, s.Began.Add(30*time.Minute))
		emit("limited", 24)
	}
}
