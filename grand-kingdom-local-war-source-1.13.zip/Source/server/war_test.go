package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

func TestWarInformationHTTPAndContracts(t *testing.T) {
	p := testProtocol(t)
	dir := t.TempDir()
	war, e := loadWar(filepath.Join(dir, "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	var eps []Endpoint
	if e = json.Unmarshal(schemaData, &eps); e != nil {
		t.Fatal(e)
	}
	b := &Backend{p: p, war: war, endpoints: map[string]Endpoint{}, log: log.New(io.Discard, "", 0), captureDir: dir}
	for _, ep := range eps {
		b.endpoints[ep.Path] = ep
	}
	for _, n := range []int{12, 13, 14, 20, 21, 22, 23} {
		f, e := os.ReadFile(filepath.Join("testdata", fmt.Sprintf("%02d.request.bin", n)))
		if e != nil {
			t.Fatal(e)
		}
		r := httptest.NewRequest("POST", eps[n].Path, bytes.NewReader(f))
		w := httptest.NewRecorder()
		b.ServeHTTP(w, r)
		if w.Code != 200 {
			t.Fatal(n, w.Code, w.Body.String())
		}
		plain, e := p.decode(w.Body.Bytes(), true)
		if e != nil {
			t.Fatal(e)
		}
		if len(w.Body.Bytes()) != eps[n].ResponseFrame+map[int]int{21: 496, 24: 1648}[n] {
			t.Fatal(n, "wrong frame size")
		}
		if string(plain[:4]) != "@suc" {
			t.Fatal(n, "war information failed")
		}
		if n == 20 {
			if binary.LittleEndian.Uint32(plain[0x1c0:]) != war.ID || plain[0x1dc] != 1 {
				t.Fatal("inactive campaign")
			}
			for i := 0; i < 4; i++ {
				if plain[0x158+16*i] != regions[i] {
					t.Fatal("missing front")
				}
			}
		}
		if n == 21 {
			if binary.LittleEndian.Uint32(plain[0x44c:]) != war.ID || plain[0x451] != 1 {
				t.Fatal("campaign mismatch")
			}
		}

		if n == 21 {
			ids := map[uint32]bool{}
			for front := 0; front < 4; front++ {
				for op := 0; op < 3; op++ {
					item := 0x8c + front*0xf0 + 8 + op*0x44
					id := binary.LittleEndian.Uint32(plain[item+0x30:])
					if id == 0 || ids[id] || plain[item+0x34] != byte(3+op) || binary.LittleEndian.Uint32(plain[item+0x40:]) != 100 {
						t.Fatal("missing or conflicting operation goal", front, op)
					}
					ids[id] = true
					if bytes.Equal(plain[item:item+12], plain[item+24:item+36]) {
						t.Fatal("battle end still equals preparation end")
					}
				}
			}
		}
		if e = os.WriteFile(filepath.Join("testdata", fmt.Sprintf("%02d.response.bin", n)), w.Body.Bytes(), 0600); e != nil {
			t.Fatal(e)
		}
	}
	if e = war.rememberContract(123456, 2); e != nil {
		t.Fatal(e)
	}
	loaded, e := loadWar(war.path)
	if e != nil || loaded.Contracts[123456] != 2 || !loaded.Start.Equal(war.Start) {
		t.Fatal("contract/campaign persistence failed", e)
	}
	if e = war.rememberContract(123456, 5); e == nil {
		t.Fatal("invalid country accepted")
	}
	buf := make([]byte, 656)
	war.contractStatus(buf)
	if binary.LittleEndian.Uint32(buf[0x98:]) != 1 {
		t.Fatal("wrong local contract count")
	}
}
