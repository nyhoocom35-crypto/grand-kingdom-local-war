package main

import (
	"encoding/binary"
	"errors"
	"fmt"
	"time"
	"unicode/utf8"
)

// Original serialized troop version 8: four unit records; no license/DLC flags.
const troopSize = 1084

// The native publication, polling and return counters are unsigned bytes.
// Keep the original one-battle-per-minute cadence, through the full wire range.
const dispatchLimit = 255
const dispatchStep = time.Minute

type Company struct {
	Name        string `json:"name"`
	Motto       string `json:"motto"`
	Description string `json:"description"`
	Username    string `json:"username"`
	Portrait    byte   `json:"portrait"`
	Flag        byte   `json:"flag"`
	Troop       []byte `json:"troop,omitempty"`
}
type Dispatch struct {
	Troop      []byte    `json:"troop"`
	Country    byte      `json:"country"`
	Started    time.Time `json:"started"`
	Last       time.Time `json:"last"`
	Battles    byte      `json:"battles"`
	Wins       byte      `json:"wins"`
	Returned   bool      `json:"returned"`
	ReturnData []byte    `json:"return_data,omitempty"`
}

var companyNames = [24]string{"Iron Oath", "White Falcon", "Dawn Watch", "Stone Shield", "Red Compass", "Silent Spear", "Azure Guard", "Storm Rider", "Silver Tide", "North Lantern", "Frost Banner", "Cloud Sentinel", "Amber Crown", "Wild Thorn", "Green Arrow", "Oak Vanguard", "Golden Trail", "Sun Patrol", "Crimson Wolf", "Black Raven", "Ash Brigade", "Night Sword", "Fire March", "Moon Scout"}
var companyRoles = [6]string{"Hold the line", "Strike swiftly", "Protect allies", "Break the siege", "Secure supplies", "Scout the border"}

func cstring(b []byte) string {
	for i, v := range b {
		if v == 0 {
			return string(b[:i])
		}
	}
	return string(b)
}
func putText(dst []byte, s string) {
	clear(dst)
	n := 0
	for _, r := range s {
		k := utf8.RuneLen(r)
		if n+k >= len(dst) {
			break
		}
		n += utf8.EncodeRune(dst[n:], r)
	}
}
func aiCompany(id uint32) (Company, bool) {
	if id < 0xf0000000 {
		return Company{}, false
	}
	n := id - 0xf0000000
	country, member := n/100, n%100
	if country >= 4 || member >= 6 {
		return Company{}, false
	}
	i := int(country*6 + member)
	return Company{Name: companyNames[i], Motto: companyRoles[member], Description: fmt.Sprintf("%s guards nation %d. %s.", companyNames[i], country+1, companyRoles[member]), Username: fmt.Sprintf("AI_%d_%02d", country+1, member+1)}, true
}
func generatedTroop(c Company, id uint32) []byte {
	seed := id % 6
	if id >= 0xf0000000 {
		seed = (id - 0xf0000000) % 100
	}
	d := make([]byte, troopSize)
	u32(d, 0, 8)
	putText(d[4:28], c.Name)
	putText(d[28:52], c.Motto)
	putText(d[52:76], "Campaign company")
	putText(d[76:148], c.Description)
	putText(d[148:220], fmt.Sprintf("%s: %s. Company %02d.", c.Name, c.Motto, seed+1))
	// Use base-game appearance and no optional equipment/skills. Level/attributes vary.
	for _, o := range []int{244, 246, 248, 250, 268, 270, 272, 274} {
		u16(d, o, 0xffff)
	}
	for i := 0; i < 4; i++ {
		u := d[276+i*202 : 276+(i+1)*202]
		u16(u, 0, uint16((seed+uint32(i))%4))
		putText(u[4:28], fmt.Sprintf("%s %d", c.Name, i+1))
		u16(u, 0x24, 0xffff)
		u16(u, 0x26, 0xffff)
		u[0x28] = byte(8 + (seed)*3 + uint32(i))
		u[0x29] = 0
		for j := 0x2a; j <= 0x32; j++ {
			u[j] = byte(8 + (seed+uint32(i)+uint32(j))%9)
		}
		for j := 0x5c; j < 0x96; j++ {
			u[j] = 0xff
		}
		for j := 0; j < 4; j++ {
			u16(u, 0x9a+j*12, 0xffff)
			for k := 0; k < 8; k++ {
				u[0x9e+j*12+k] = 0xff
			}
		}
	}
	return d
}
func (w *War) company(id uint32) (Company, bool) {
	if c, ok := aiCompany(id); ok {
		if w.World != nil {
			if r := w.World.Ranks[id]; r != nil {
				c.Description = fmt.Sprintf("%s contracted to nation %d. %s.", c.Name, r.Country+1, c.Motto)
			}
		}
		return c, true
	}
	c, ok := w.Companies[id]
	return c, ok
}
func (w *War) companyTroop(id uint32, c Company) []byte {
	if len(c.Troop) == troopSize {
		return c.Troop
	}
	return generatedTroop(c, id)
}
func (w *War) companyRequest(api int, d, req []byte, now time.Time) error {
	id := binary.LittleEndian.Uint32(req[0x24:])
	w.mu.Lock()
	defer w.mu.Unlock()
	if api == 42 {
		target := binary.LittleEndian.Uint32(req[0x9c:])
		c, ok := w.company(target)
		if !ok {
			return errors.New("unknown company; no profile submitted")
		}
		putText(d[0x8c:0x9d], c.Username)
		copy(d[0xa0:0x5a0], w.companyTroop(target, c))
		for nation := 0; nation < 4; nation++ {
			off := 0x5a0 + nation*16
			u16(d, off, 0)
			if w.World != nil {
				if r := w.World.Ranks[target]; r != nil && r.Country == byte(nation) {
					u16(d, off, uint16(min(r.Wins+r.Losses, uint32(65535))))
					u16(d, off+2, uint16(min(r.Wins, uint32(65535))))
				}
			}
			putDate(d[off+4:], w.Start)
		}
		return nil
	}
	if id == 0 && api == 38 {
		return nil
	}
	if id == 0 {
		return errors.New("missing player ID")
	}
	switch api {
	case 7:
		return w.change(func() error {
			if w.Companies == nil {
				w.Companies = map[uint32]Company{}
			}
			c := w.Companies[id]
			c.Username = cstring(req[0x10:0x21])
			c.Name = cstring(req[0x9c:0xb4])
			c.Motto = cstring(req[0xb4:0xcc])
			c.Description = cstring(req[0xcc:0xe4])
			c.Portrait = req[0xe4]
			c.Flag = req[0xe5]
			if c.Name == "" {
				c.Name = c.Username
			}
			w.Companies[id] = c
			return nil
		})
	case 35:
		slot := req[0x9c]
		if slot >= 6 || req[0xa4] > 4 {
			return errors.New("invalid dispatch slot or country")
		}
		raw := append([]byte(nil), req[0xa8:0xa8+troopSize]...)
		if binary.LittleEndian.Uint32(raw) != 8 {
			return errors.New("unsupported submitted troop version")
		}
		return w.change(func() error {
			if w.Companies == nil {
				w.Companies = map[uint32]Company{}
			}
			if w.Dispatches == nil {
				w.Dispatches = map[uint32]map[byte]*Dispatch{}
			}
			c := w.Companies[id]
			c.Username = cstring(req[0x10:0x21])
			c.Troop = raw
			c.Name = cstring(raw[4:28])
			c.Motto = cstring(raw[28:52])
			c.Description = cstring(raw[76:148])
			w.Companies[id] = c
			if w.Dispatches[id] == nil {
				w.Dispatches[id] = map[byte]*Dispatch{}
			}
			t := w.Dispatches[id][slot]
			// Replayed publication never resets an active deployment or awards results.
			if (t == nil || t.Returned) && req[0x9d] == 1 {
				t = &Dispatch{Troop: raw, Country: req[0xa4], Started: now.UTC(), Last: now.UTC()}
				w.Dispatches[id][slot] = t
			}
			d[0x8c] = 1
			d[0x8d] = dispatchLimit
			return nil
		})
	case 38:
		return w.change(func() error {
			w.advanceDispatches(now)
			for slot, t := range w.Dispatches[id] {
				if !t.Returned {
					d[0x8c+int(slot)] = t.Battles
				}
			}
			return nil
		})
	case 36:
		slot := req[0x9c]
		if slot >= 6 {
			return errors.New("invalid return slot")
		}
		return w.change(func() error {
			w.advanceDispatches(now)
			t := w.Dispatches[id][slot]
			if t == nil {
				return nil
			}
			if t.Returned {
				copy(d[0x8c:], t.ReturnData)
				return nil
			}
			d[0x8c] = t.Wins
			d[0x8d] = t.Battles
			// Six original affinity bytes inform client-side reconciliation for missed battles.
			for i := 0; i < 6; i++ {
				d[0x8e+i] = 50
			}
			if t.Battles > 0 {
				country := t.Country
				if country >= 4 {
					country = 0
				}
				opponent := uint32(0xf0000000 + int((country+1)%4)*100 + int(t.Battles)%6)
				c, _ := aiCompany(opponent)
				u32(d, 0x94, opponent)
				putText(d[0x98:0xa9], c.Username)
				copy(d[0xb0:], generatedTroop(c, opponent))
				d[0xa9] = 1
				d[0xaa] = 1
				d[0xab] = 1
				u16(d, 0xac, 100)
				u16(d, 0xae, uint16(t.Battles))
			}
			t.ReturnData = append([]byte(nil), d[0x8c:0x5b0]...)
			t.Returned = true
			return nil
		})
	}
	return errors.New("unsupported company operation")
}
func (w *War) advanceDispatches(now time.Time) {
	for id, slots := range w.Dispatches {
		for _, t := range slots {
			if t.Returned || now.Before(t.Started) {
				continue
			}
			n := min(int(now.Sub(t.Started)/dispatchStep), dispatchLimit)
			for int(t.Battles) < n {
				t.Battles++
				won := (int(id%97)+int(t.Battles)*7+int(t.Country))%5 < 3
				if won {
					t.Wins++
				}
				// Deployed troop contributes to its contracted nation's current front.
				if w.World != nil && t.Country < 4 {
					for i := range w.World.Fronts {
						f := &w.World.Fronts[i]
						side := -1
						if f.Attacker == t.Country {
							side = 0
						} else if f.Defender == t.Country {
							side = 1
						}
						if side >= 0 {
							gain := uint32(4)
							if won {
								gain = 12
							}
							f.Influence[side] = saturate(f.Influence[side], gain)
							break
						}
					}
				}
			}
			t.Last = now.UTC()
		}
	}
}
func (w *War) validateCompanies() error {
	for id, c := range w.Companies {
		if id == 0 || len(c.Troop) != 0 && len(c.Troop) != troopSize || !utf8.ValidString(c.Name) || !utf8.ValidString(c.Description) {
			return errors.New("invalid saved company; keep backups")
		}
	}
	for id, slots := range w.Dispatches {
		if id == 0 || len(slots) > 6 {
			return errors.New("invalid saved dispatch owner")
		}
		for slot, t := range slots {
			if slot >= 6 || t == nil || len(t.Troop) != troopSize || t.Country > 4 || t.Started.IsZero() || t.Last.Before(t.Started) || t.Battles > dispatchLimit || t.Wins > t.Battles || (t.Returned && len(t.ReturnData) != 0x5b0-0x8c) {
				return errors.New("invalid saved dispatch state; keep backups")
			}
		}
	}
	return nil
}
