package main

import (
	"path/filepath"
	"testing"
	"time"
)

func TestVoteDeadlineFreezesAtEntryAndSurvivesRestart(t *testing.T) {
	w, err := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if err != nil {
		t.Fatal(err)
	}
	frame := make([]byte, 1424)
	before := time.Now().UTC()
	w.now(frame)
	deadline := w.VoteDeadlines44[1000]
	if deadline.Sub(before) < 59*time.Second || deadline.Sub(before) > 60*time.Second {
		t.Fatal("not a 60-second voting window", deadline)
	}
	want := make([]byte, 12)
	putDate(want, deadline)
	for _, off := range []int{12, 24} {
		for i := range want {
			if frame[0x8c+8+off+i] != want[i] {
				t.Fatal("wrong advertised vote date")
			}
		}
	}
	req := make([]byte, 192)
	u32(req, 0x9c, w.ID)
	u32(req, 0xa0, 1000)
	req[0xa4] = 1
	if ok, err := w.enter(make([]byte, 1568), req); !ok || err != nil {
		t.Fatal("entry", err)
	}
	loaded, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	if !loaded.Strategies[1000].Began.Equal(deadline) {
		t.Fatal("deadline changed at entry/restart")
	}
	loaded.now(frame)
	for _, off := range []int{12, 24} {
		for i := range want {
			if frame[0x8c+8+off+i] != want[i] {
				t.Fatal("poll reset deadline")
			}
		}
	}
	// An elapsed joined deadline must stay elapsed, allowing transition to battle.
	loaded.Strategies[1000].Began = before.Add(-time.Minute)
	loaded.now(frame)
	if !loaded.voteDeadline(1000).Before(before) {
		t.Fatal("elapsed timer restarted")
	}
}
