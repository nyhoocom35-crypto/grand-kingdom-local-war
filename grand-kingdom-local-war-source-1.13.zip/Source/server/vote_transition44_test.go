package main

import (
	"bytes"
	"fmt"
	"testing"
	"time"
)

func TestVote44AdvertisementSurvivesRoundAndRestart(t *testing.T) {
	w := campaignWar(t)
	frame := make([]byte, 1648)
	if err := w.snapshot22(frame); err != nil {
		t.Fatal(err)
	}
	id := w.operationID(0)
	deadline := w.VoteDeadlines44[id]
	oldWire := w.wireID()
	if err := w.advance(w.Start.Add(5 * time.Minute)); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	if !loaded.VoteDeadlines44[id].Equal(deadline) {
		t.Fatal("advertised deadline lost at round/restart")
	}
	req := make([]byte, 192)
	u32(req, 0x9c, oldWire)
	u32(req, 0xa0, id)
	req[0xa4] = 1
	if ok, err := loaded.enter(make([]byte, 1568), req); !ok || err != nil {
		t.Fatal(ok, err)
	}
	reply := make([]byte, 160)
	if ok, err := loaded.beginStrategy(reply, req); !ok || err != nil {
		t.Fatal(ok, err)
	}
	want := make([]byte, 12)
	putDate(want, deadline)
	if !bytes.Equal(reply[0x8c:0x98], want) {
		t.Fatal("CheckBegin extended deadline")
	}
}

func TestVote44All84MapsRetainDeadlineAndResolve(t *testing.T) {
	checked := 0
	for key := range worldLayouts22 {
		w := campaignWar(t)
		var region, base int
		if _, err := fmt.Sscanf(key, "%d:%d", &region, &base); err != nil {
			t.Fatal(err)
		}
		if !combatRegion(byte(region)) {
			continue
		}
		id := uint32(100000 + checked)
		w.World.Operations[id] = Operation{byte(region), byte(base), 0, 1, w.ID}
		deadline := time.Now().UTC().Add(23 * time.Second).Truncate(time.Second)
		w.VoteDeadlines44 = map[uint32]time.Time{id: deadline}
		w.OperationGeneration++
		w.selectFronts()
		if err := w.save(); err != nil {
			t.Fatal(err)
		}
		loaded, err := loadWar(w.path)
		if err != nil {
			t.Fatal(err)
		}
		req := make([]byte, 192)
		u32(req, 0x9c, loaded.wireID())
		u32(req, 0xa0, id)
		req[0xa4] = 1
		if ok, err := loaded.enter(make([]byte, 1568), req); !ok || err != nil {
			t.Fatal(key, ok, err)
		}
		s := loaded.Strategies[id]
		if !s.Began.Equal(deadline) {
			t.Fatal(key, "extra wait introduced")
		}
		layout, ok := loaded.layout(id)
		if !ok {
			t.Fatal(key, "map changed")
		}
		loaded.updateVotes25(id, s, layout, deadline)
		if !s.Votes.Resolved {
			t.Fatal(key, "vote not resolved at advertised deadline")
		}
		checked++
	}
	if checked != 84 {
		t.Fatal("map coverage", checked)
	}
}

func TestVote44SnapshotWriteFailureRollsBackDeadline(t *testing.T) {
	w := campaignWar(t)
	id := w.operationID(0)
	old := time.Now().UTC().Add(-time.Hour)
	w.VoteDeadlines44 = map[uint32]time.Time{id: old}
	w.path = t.TempDir() // Cannot atomically replace a directory with the state file.
	if err := w.snapshot22(make([]byte, 1648)); err == nil {
		t.Fatal("write failure hidden")
	}
	if len(w.VoteDeadlines44) != 1 || !w.VoteDeadlines44[id].Equal(old) {
		t.Fatal("failed snapshot changed advertised state")
	}
}
