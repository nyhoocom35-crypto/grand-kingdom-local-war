package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// Optional authorized native replay fixture export; never part of the release.
func TestResearchSiege40ReplayFixtures(t *testing.T) {
	dir := os.Getenv("GK_RESEARCH40_FIXTURE_DIR")
	if dir == "" {
		t.Skip("native fixture export not requested")
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		t.Fatal(err)
	}
	w := campaignWar(t)
	write := func(name string, b []byte) {
		if err := os.WriteFile(filepath.Join(dir, name), b, 0600); err != nil {
			t.Fatal(err)
		}
	}
	for _, minute := range []int{0, 5} {
		if err := w.advance(w.Start.Add(time.Duration(minute) * time.Minute)); err != nil {
			t.Fatal(err)
		}
		fixed := make([]byte, 480)
		w.fixed(fixed)
		write(map[int]string{0: "fixed_initial.bin", 5: "fixed_after.bin"}[minute], fixed)
		for n := 0; n < 4; n++ {
			b := make([]byte, 4972)
			w.barrackCountry(b, n)
			write(map[int]string{0: "barrack_initial_", 5: "barrack_after_"}[minute]+string(rune('0'+n))+".bin", b)
		}
	}
	state, _ := json.MarshalIndent(w.World.Barrack39, "", "  ")
	write("research.json", state)
	req := campaignReq(w, 123, 33)
	u32(req, 0xa0, w.operationID(0))
	if ok, err := w.enter(make([]byte, 17000), req); err != nil || !ok {
		t.Fatal(ok, err)
	}
	s := w.Strategies[w.operationID(0)]
	// Exercise the native map parser's destruction branch for every fixture.
	for j := range s.Objects {
		if s.Objects[j].Type != 10 {
			s.Objects[j].HP = 0
			s.Objects[j].SiegeWins40 = 5
		}
	}
	b := make([]byte, 1696)
	if ok, err := w.strategyData(b, req); err != nil || !ok {
		t.Fatal(ok, err)
	}
	write("strategy_destroyed.bin", b)
}
