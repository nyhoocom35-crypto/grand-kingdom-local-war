package main

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

func (w *War) operationID(index int) uint32 {
	return 1000 + w.OperationGeneration*12 + uint32(index)
}
func (w *War) operationStart() time.Time {
	if !w.OperationStart.IsZero() {
		return w.OperationStart
	}
	return w.Start
}
func (w *War) renewOperations() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.OperationGeneration >= 357913856 {
		return errors.New("operation generation limit reached")
	}
	if !w.fightingEnd().After(time.Now().UTC()) {
		return errors.New("campaign is no longer active; operation renewal rejected")
	}
	oldGeneration, oldStart := w.OperationGeneration, w.OperationStart
	w.OperationGeneration++
	w.OperationStart = time.Now().UTC().Add(-time.Minute)
	if e := w.save(); e != nil {
		w.OperationGeneration = oldGeneration
		w.OperationStart = oldStart
		return e
	}
	return nil
}
func renewOperation(root string) error {
	path := filepath.Join(root, "war-state.json")
	if info, e := os.Stat(path); e != nil || !info.Mode().IsRegular() {
		return errors.New("existing war-state.json is required; use the installed server folder")
	}
	w, e := loadWar(path)
	if e != nil {
		return e
	}
	if e = w.renewOperations(); e != nil {
		return e
	}
	fmt.Printf("OPERATION RENEWAL OK: campaign %d retained; new operations %d..%d\n", w.ID, w.operationID(0), w.operationID(11))
	return nil
}
