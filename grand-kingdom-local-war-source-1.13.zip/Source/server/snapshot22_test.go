package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"
)

func TestSnapshot22RoundCampaignAndAllMaps(t *testing.T) {
	p := testProtocol(t)
	var endpoints []Endpoint
	if err := json.Unmarshal(schemaData, &endpoints); err != nil {
		t.Fatal(err)
	}
	w := campaignWar(t)
	b := &Backend{p: p, war: w}
	out := "testdata/snapshot22"
	if err := os.MkdirAll(out, 0700); err != nil {
		t.Fatal(err)
	}
	emit := func(name string, api int, req []byte) []byte {
		valid := make([]byte, endpoints[api].RequestPadded)
		copy(valid, req)
		u32(valid, 4, 0x3130786b)
		u32(valid, 8, endpoints[api].OperationCode)
		u32(valid, 12, uint32(endpoints[api].ResponseLogical))
		frame, status, err := b.response(endpoints[api], valid)
		if err != nil || status != "OK" {
			t.Fatal(name, api, status, err)
		}
		plain, err := p.decode(frame, true)
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(out, name), frame, 0600); err != nil {
			t.Fatal(err)
		}
		return plain
	}
	start := w.Start
	for step := 0; step < 20; step++ {
		if err := w.advance(start.Add(time.Duration(step+1) * 5 * time.Minute)); err != nil {
			t.Fatal(err)
		}
		r := campaignReq(w, 123, 21)
		q := emit(fmt.Sprintf("round_%02d_21.response.bin", step), 21, r)
		if len(q) != 1648 || binary.LittleEndian.Uint32(q[0x44c:]) != binary.LittleEndian.Uint32(q[1152+0x1c0:]) {
			t.Fatal("mixed snapshot")
		}
		for i := 0; i < 4; i++ {
			if q[0x8c+0xf0*i+0xed] != q[1152+0x14c+16*i+12] {
				t.Fatal("mixed front")
			}
		}
	}
	count := 0
	for region := byte(0); region < 16; region++ {
		if !combatRegion(region) {
			continue
		}
		for base := byte(0); base < 7; base++ {
			w.OperationGeneration++
			id := w.operationID(0)
			used := map[byte]bool{region: true}
			fronts := [4]byte{region}
			next := 1
			for r := byte(0); r < 16 && next < 4; r++ {
				if combatRegion(r) && !used[r] {
					fronts[next] = r
					used[r] = true
					next++
				}
			}
			for i, r := range fronts {
				def := w.World.Owners[r]
				att := (def + 1) % 4
				bases := [3]byte{base, (base + 1) % 7, (base + 2) % 7}
				w.World.Fronts[i] = Front{r, att, def, bases, [2]uint32{1000, 1000}}
				for j := 0; j < 7; j++ {
					w.World.BaseOwners[r][j] = def
				}
				for j, b := range bases {
					w.World.Operations[w.operationID(i*3+j)] = Operation{r, b, att, def, w.ID}
				}
			}
			emit(fmt.Sprintf("map_%02d_%d_21.response.bin", region, base), 21, campaignReq(w, 123, 21))
			for side := byte(0); side < 2; side++ {
				req := campaignReq(w, 123, 23)
				u32(req, 0xa0, id)
				req[0xa4] = side
				label := fmt.Sprintf("map_%02d_%d_%d", region, base, side)
				q := emit(label+"_23.response.bin", 23, req)
				l, ok := w.layout(id)
				if !ok {
					t.Fatal(region, base)
				}
				if q[0x5a8+int(side)*20] != l.Spawns[side][0][0] || q[0x5a8+int(side)*20+10] != l.Spawns[side][0][1] {
					t.Fatal("incorrect map spawn")
				}
				emit(label+"_24.response.bin", 24, req)
			}
			count++
		}
	}
	if count != 84 {
		t.Fatal(count)
	}
	req := campaignReq(w, 123, 24)
	u32(req, 0xa0, w.operationID(0))
	req[0xa4] = 1
	if err := w.advance(w.Start.Add(time.Duration(w.World.Round+1) * 5 * time.Minute)); err != nil {
		t.Fatal(err)
	}
	emit("field_rollover_24.response.bin", 24, req)
}

func TestSnapshot22ConcurrentRollover(t *testing.T) {
	w := campaignWar(t)
	start := w.Start
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for i := 1; i <= 240; i++ {
			if err := w.advance(start.Add(time.Duration(i) * aiStep)); err != nil {
				t.Error(err)
				return
			}
		}
	}()
	for i := 0; i < 1000; i++ {
		q := make([]byte, 1648)
		w.snapshot22(q)
		if binary.LittleEndian.Uint32(q[0x44c:]) != binary.LittleEndian.Uint32(q[1152+0x1c0:]) {
			t.Fatal("concurrent revision mismatch")
		}
		for j := 0; j < 4; j++ {
			if q[0x8c+0xf0*j+0xed] != q[1152+0x14c+16*j+12] {
				t.Fatal("concurrent map mismatch")
			}
		}
	}
	wg.Wait()
}

func TestSnapshot22StaleSelectionAndUnknownIDs(t *testing.T) {
	w := campaignWar(t)
	req := campaignReq(w, 123, 23)
	id := w.operationID(9)
	u32(req, 0xa0, id)
	l, _ := w.layout(id)
	if err := w.advance(w.Start.Add(5 * time.Minute)); err != nil {
		t.Fatal(err)
	}
	dst := make([]byte, 2000)
	if ok, err := w.enter(dst, req); !ok || err != nil {
		t.Fatal("round-transition selection rejected", ok, err)
	}
	if dst[0x5a8] != l.Spawns[0][0][0] {
		t.Fatal("historical operation remapped")
	}
	unknown := bytes.Clone(req)
	u32(unknown, 0xa0, 900001)
	if ok, _ := w.enter(dst, unknown); ok {
		t.Fatal("unknown ID accepted")
	}
	wrong := bytes.Clone(req)
	u32(wrong, 0x9c, w.wireID()+8)
	if ok, _ := w.enter(dst, wrong); ok {
		t.Fatal("cross-campaign ID accepted")
	}
	if err := w.advance(w.Start.Add(30 * time.Minute)); err != nil {
		t.Fatal(err)
	}
	if ok, err := w.strategyData(dst, req); !ok || err != nil {
		t.Fatal("entered battle lost after campaign", ok, err)
	}
}

func TestSnapshot22CapturedRegistration(t *testing.T) {
	dir := os.Getenv("GK_CAPTURE22")
	if dir == "" {
		t.Skip("set GK_CAPTURE22 to the reported incident")
	}
	p := testProtocol(t)
	matches, _ := filepath.Glob(filepath.Join(dir, "*20261005_093346*_23.request.bin"))
	if len(matches) != 1 {
		t.Fatal(matches)
	}
	frame, err := os.ReadFile(matches[0])
	if err != nil {
		t.Fatal(err)
	}
	req, err := p.decode(frame, false)
	if err != nil {
		t.Fatal(err)
	}
	if binary.LittleEndian.Uint32(req[0x9c:]) != 0x4000007b || binary.LittleEndian.Uint32(req[0xa0:]) != 2065 {
		t.Fatal("unexpected incident")
	}
	w := campaignWar(t)
	w.ID = 15
	w.OperationGeneration = 89
	w.World.Operations[2065] = Operation{5, 3, 0, 3, 15}
	old, _ := filepath.Glob(filepath.Join(dir, "*20261005_093229*_21.response.bin"))
	if len(old) != 1 {
		t.Fatal(old)
	}
	f, _ := os.ReadFile(old[0])
	q, err := p.decode(f, true)
	if err != nil {
		t.Fatal(err)
	}
	// Resolve geometry from the actual operation record, rather than a modulo fallback.
	found := false
	for i := 0; i < 4; i++ {
		for j := 0; j < 3; j++ {
			at := 0x8c + 0xf0*i + 8 + 0x44*j
			if binary.LittleEndian.Uint32(q[at+0x30:]) == 2065 {
				op := w.World.Operations[2065]
				op.Region = q[0x8c+0xf0*i+0xed]
				op.Base = q[at+0x34]
				w.World.Operations[2065] = op
				found = true
			}
		}
	}
	if !found {
		t.Fatal("operation absent from reported snapshot")
	}
	if ok, err := w.enter(make([]byte, 2000), req); !ok || err != nil {
		t.Fatal("actual reported request still rejected", ok, err)
	}
}
