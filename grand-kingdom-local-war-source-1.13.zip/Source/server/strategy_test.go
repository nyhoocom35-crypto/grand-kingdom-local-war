package main

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

func TestStrategyFramesAndPersistence(t *testing.T) {
	p := testProtocol(t)
	w, e := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p, war: w}
	for _, n := range []int{23, 24, 25, 26, 28, 29, 37, 38} {
		raw, e := os.ReadFile(fmt.Sprintf("testdata/%02d.request.bin", n))
		if e != nil {
			t.Fatal(e)
		}
		req, e := p.decode(raw, false)
		if e != nil {
			t.Fatal(e)
		}
		// Legacy request fixture predates online identity registration.
		u32(req, 0x24, 123)
		if n == 28 {
			for j := 0; j < 10; j++ {
				req[0xa8+j] = 11
			}
			for j := 0; j < 6; j++ {
				req[0xa8+j] = 6
			}
		}
		frame, status, e := b.response(eps[n], req)
		if e != nil || status != "OK" {
			t.Fatal(n, status, e)
		}
		decoded, e := p.decode(frame, true)
		if e != nil || string(decoded[:4]) != "@suc" || len(frame) != eps[n].ResponseFrame+map[int]int{24: 1648}[n] {
			t.Fatal(n, "invalid response", e)
		}
		if n == 24 {
			forts := [2]int{}
			armies := [2]int{}
			players := 0
			for i := 0; i < 36; i++ {
				o := decoded[0x230+i*0x1c:]
				if binary.LittleEndian.Uint32(o) == 0 {
					continue
				}
				switch o[8] {
				case 0:
					forts[o[9]]++
				case 5:
					armies[o[9]]++
				case 10:
					players++
				}
			}
			if forts != [2]int{1, 1} || armies != [2]int{6, 5} || players != 1 {
				t.Fatal("missing forts, rival NPC fields or player", forts, armies, players)
			}
		}
		if e = os.WriteFile(fmt.Sprintf("testdata/%02d.response.bin", n), frame, 0600); e != nil {
			t.Fatal(e)
		}
	}
	req := make([]byte, 192)
	u32(req, 0x9c, 1)
	u32(req, 0xa0, 1000)
	req[0xa4] = 1
	u32(req, 0xac, 30002)
	u16(req, 0xb2, 2)
	req[0xb5] = 10
	req[0xb7] = 10
	if ok, e := w.move(req); !ok || e != nil {
		t.Fatal("move failed", e)
	}
	loaded, e := loadWar(w.path)
	if e != nil {
		t.Fatal(e)
	}
	found := false
	for _, o := range loaded.Strategies[1000].Objects {
		if o.ID == 30002 {
			found = o.X == 10 && o.Y == 10 && o.Slot == 2
		}
	}
	if !found {
		t.Fatal("move not persisted")
	}
	req[0xb5] = 0
	if ok, _ := w.move(req); ok {
		t.Fatal("illegal move accepted")
	}
	buf := make([]byte, 1712)
	if ok, e := w.strategyData(buf, req); !ok || e != nil {
		t.Fatal(e)
	}
	u32(req, 0x9c, 99)
	if ok, _ := w.enter(make([]byte, 1568), req); ok {
		t.Fatal("wrong campaign admitted")
	}
	u32(req, 0x9c, 1)
	u32(req, 0xa0, 9999)
	if ok, _ := w.enter(make([]byte, 1568), req); ok {
		t.Fatal("unknown operation admitted")
	}
}

func TestActualCapturedEntryRequests(t *testing.T) {
	root := os.Getenv("GK_ENTRY_CAPTURE_DIR")
	if root == "" {
		t.Skip("private capture replay not requested")
	}
	p := testProtocol(t)
	w, e := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p, war: w}
	files, e := os.ReadDir(root)
	if e != nil {
		t.Fatal(e)
	}
	seen := 0
	for _, f := range files {
		if len(f.Name()) < 15 || f.Name()[len(f.Name())-15:] != "_23.request.bin" {
			continue
		}
		raw, e := os.ReadFile(filepath.Join(root, f.Name()))
		if e != nil {
			t.Fatal(e)
		}
		req, e := p.decode(raw, false)
		if e != nil {
			t.Fatal(e)
		}
		frame, status, e := b.response(eps[23], req)
		if e != nil || status != "OK" {
			t.Fatal(status, e)
		}
		dec, e := p.decode(frame, true)
		if e != nil || string(dec[:4]) != "@suc" {
			t.Fatal(e)
		}
		seen++
	}
	if seen != 4 {
		t.Fatal("expected four real entry requests", seen)
	}
}

func TestAllOperationLayouts(t *testing.T) {
	w, e := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	req := make([]byte, 192)
	u32(req, 0x9c, w.ID)
	for id := uint32(1000); id <= 1011; id++ {
		u32(req, 0xa0, id)
		for side := byte(0); side < 2; side++ {
			req[0xa4] = side
			if ok, e := w.enter(make([]byte, 1568), req); !ok || e != nil {
				t.Fatal(id, side, e)
			}
			dst := make([]byte, 1712)
			if ok, e := w.strategyData(dst, req); !ok || e != nil {
				t.Fatal(id, side, e)
			}
			if e := w.validateStrategies(); e != nil {
				t.Fatal(id, side, e)
			}
			pos := map[[3]byte]bool{}
			for _, o := range w.Strategies[id].Objects {
				if o.Type != 5 && o.Type != 10 {
					continue
				}
				key := [3]byte{o.Side, o.X, o.Y}
				if pos[key] {
					t.Fatal(id, "army/player tile overlap", key)
				}
				pos[key] = true
			}
		}
	}
}
