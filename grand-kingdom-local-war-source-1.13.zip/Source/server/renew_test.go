package main

import (
	"encoding/binary"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestRenewRetainsCampaignContractsAndHistory(t *testing.T) {
	p := testProtocol(t)
	w, e := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	if e = w.rememberContract(123456, 2); e != nil {
		t.Fatal(e)
	}
	req := make([]byte, 192)
	u32(req, 0x9c, w.ID)
	u32(req, 0xa0, 1000)
	req[0xa4] = 1
	if ok, e := w.enter(make([]byte, 1568), req); !ok || e != nil {
		t.Fatal(e)
	}
	oldStart, oldEnd, oldID := w.Start, w.End, w.ID
	history := w.Strategies[1000]
	if e = w.renewOperations(); e != nil {
		t.Fatal(e)
	}
	loaded, e := loadWar(w.path)
	if e != nil {
		t.Fatal(e)
	}
	if loaded.ID != oldID || !loaded.Start.Equal(oldStart) || !loaded.End.Equal(oldEnd) || loaded.Contracts[123456] != 2 || loaded.Strategies[1000] == nil || !loaded.Strategies[1000].Began.Equal(history.Began) {
		t.Fatal("renewal changed campaign, contract or archived operation")
	}
	if ok, _ := loaded.enter(make([]byte, 1568), req); ok {
		t.Fatal("retired operation admitted")
	}
	u32(req, 0xa0, loaded.operationID(0))
	if ok, e := loaded.enter(make([]byte, 1568), req); !ok || e != nil {
		t.Fatal("new operation admission failed", e)
	}
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p, war: loaded}
	raw, e := os.ReadFile("testdata/21.request.bin")
	if e != nil {
		t.Fatal(e)
	}
	request, e := p.decode(raw, false)
	if e != nil {
		t.Fatal(e)
	}
	frame, status, e := b.response(eps[21], request)
	if e != nil || status != "OK" {
		t.Fatal(status, e)
	}
	decoded, e := p.decode(frame, true)
	if e != nil {
		t.Fatal(e)
	}
	for front := 0; front < 4; front++ {
		for op := 0; op < 3; op++ {
			off := 0x8c + front*0xf0 + 8 + op*0x44 + 0x30
			if binary.LittleEndian.Uint32(decoded[off:]) != uint32(1012+front*3+op) {
				t.Fatal("old operation still advertised")
			}
		}
	}
	if e = os.WriteFile("testdata/21.renewed.response.bin", frame, 0600); e != nil {
		t.Fatal(e)
	}
	if e = loaded.renewOperations(); e != nil {
		t.Fatal(e)
	}
	reloaded, e := loadWar(w.path)
	if e != nil || reloaded.operationID(0) != 1024 {
		t.Fatal("renewal did not persist", e)
	}
}
