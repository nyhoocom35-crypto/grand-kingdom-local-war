package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

// Optional replay of authorized, private captures. No capture or player state is
// embedded in the executable or included in the distribution archive.
func TestCapturedWarRequests(t *testing.T) {
	root := os.Getenv("GK_CAPTURE_DIR")
	if root == "" {
		t.Skip("private capture replay not requested")
	}
	p := testProtocol(t)
	war, e := loadWar(filepath.Join(t.TempDir(), "war.json"))
	if e != nil {
		t.Fatal(e)
	}
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p, war: war}
	entries, e := os.ReadDir(root)
	if e != nil {
		t.Fatal(e)
	}
	seen := map[int]int{}
	for _, f := range entries {
		name := f.Name()
		if !strings.HasSuffix(name, ".request.bin") {
			continue
		}
		parts := strings.Split(name, "_")
		n, e := strconv.Atoi(strings.Split(parts[len(parts)-1], ".")[0])
		if e != nil {
			t.Fatal(e)
		}
		if n != 12 && n != 13 && n != 14 && n != 20 && n != 21 && n != 22 {
			continue
		}
		raw, e := os.ReadFile(filepath.Join(root, name))
		if e != nil {
			t.Fatal(e)
		}
		req, e := p.decode(raw, false)
		if e != nil {
			t.Fatal(e)
		}
		result, status, e := b.response(eps[n], req)
		if e != nil || status != "OK" {
			t.Fatal(n, status, e)
		}
		if len(result) != eps[n].ResponseFrame {
			t.Fatal(n, "wrong captured response frame length")
		}
		decoded, e := p.decode(result, true)
		if e != nil || string(decoded[:4]) != "@suc" {
			t.Fatal(n, "invalid captured response", e)
		}
		seen[n]++
	}
	for _, n := range []int{12, 13, 14, 20, 21, 22} {
		if seen[n] == 0 {
			t.Fatal("expected private capture missing", n)
		}
	}
}
