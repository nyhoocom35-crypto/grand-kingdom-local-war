package main

import (
	"encoding/binary"
	"encoding/json"
	"testing"
	"time"
)

func TestResearch39OneTimeResetAndRestart(t *testing.T) {
	w := campaignWar(t)
	w.Contracts[123] = 2
	w.World.Ranks[123] = &Rank{ID: 123, Country: 2, Wins: 9}
	w.World.Barrack39 = nil
	for n := 0; n < 4; n++ {
		for k := 0; k < 2; k++ {
			w.World.Research[n][k] = Research{Level: 9, Progress: 90, Gold: 9999, Resources: 100}
		}
	}
	if err := w.save(); err != nil {
		t.Fatal(err)
	}
	w2, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	if err = w2.enableCampaign(w.Start); err != nil {
		t.Fatal(err)
	}
	for n := 0; n < 4; n++ {
		for k := 0; k < 2; k++ {
			r := w2.World.Research[n][k]
			if r.Level != 0 || r.Progress != 0 || r.Gold != 0 || r.Resources != 0 {
				t.Fatal("legacy reset incomplete")
			}
			for _, v := range w2.World.Barrack39.Categories[n][k] {
				if v != (ResearchCategory39{}) {
					t.Fatal("category not reset")
				}
			}
		}
	}
	if w2.Contracts[123] != 2 || w2.World.Ranks[123].Wins != 9 || w2.Start != w.Start || w2.ID != w.ID {
		t.Fatal("reset affected unrelated progress")
	}
	if err = w2.advance(w2.Start.Add(5 * time.Minute)); err != nil {
		t.Fatal(err)
	}
	before, _ := json.Marshal(w2.World.Barrack39)
	w3, err := loadWar(w2.path)
	if err != nil {
		t.Fatal(err)
	}
	if err = w3.enableCampaign(w3.Start); err != nil {
		t.Fatal(err)
	}
	after, _ := json.Marshal(w3.World.Barrack39)
	if string(before) != string(after) {
		t.Fatal("research reset again on restart")
	}
}

func TestResearch39NativeCountsTimerAndShopSynchronization(t *testing.T) {
	w := campaignWar(t)
	if err := w.advance(w.Start.Add(5 * time.Minute)); err != nil {
		t.Fatal(err)
	}
	fixed := make([]byte, 480)
	w.fixed(fixed)
	seen := map[[4]byte]bool{}
	for n := 0; n < 4; n++ {
		counts := w.researchCounts39(n, 1)
		if seen[counts] {
			t.Fatal("nations have identical equipment research", counts)
		}
		seen[counts] = true
		barrack := make([]byte, 4972)
		w.barrackCountry(barrack, n)
		for k := 0; k < 2; k++ {
			for j := 0; j < 4; j++ {
				r := w.World.Barrack39.Categories[n][k][j]
				o := 0x8c + k*48 + j*12
				secs := binary.LittleEndian.Uint32(barrack[o:]) / 1000
				if secs > 25*60 || binary.LittleEndian.Uint32(barrack[o+4:])/1000 != secs || barrack[o+10] != 0 || barrack[o+9] != r.Completed {
					t.Fatal("invalid native research timer")
				}
				if barrack[0x10c+k*16+n*4+j] != r.Completed {
					t.Fatal("wrong country completion table")
				}
				if k == 1 && fixed[0x8c+n*48+0x24+j] != r.Completed {
					t.Fatal("shop uses stale completion count")
				}
			}
		}
	}
}

func TestResearch39ContributionTargetsNativeCategoryAndCountry(t *testing.T) {
	w := campaignWar(t)
	req := campaignReq(w, 123, 11)
	req[0xc4], req[0xc5], req[0xc6] = 1, 3, 2
	u32(req, 0xa0, 999999) // previous total MUST NOT become a new donation.
	u32(req, 0xa4, 4000)
	u32(req, 0xa8, 60)
	dst := make([]byte, 152)
	if err := w.campaignRequest(11, dst, req); err != nil {
		t.Fatal(err)
	}
	if r := w.World.Barrack39.Categories[2][1][3]; r.Completed != 1 || r.Progress != 0 || r.Gold != 4000 || r.Resources != 60 {
		t.Fatal("wrong donation", r)
	}
	for n := 0; n < 4; n++ {
		for k := 0; k < 2; k++ {
			for j := 0; j < 4; j++ {
				if n == 2 && k == 1 && j == 3 {
					continue
				}
				if w.World.Barrack39.Categories[n][k][j] != (ResearchCategory39{}) {
					t.Fatal("donation leaked")
				}
			}
		}
	}
	if err := w.campaignRequest(11, dst, req); err != nil {
		t.Fatal(err)
	}
	if w.World.Barrack39.Categories[2][1][3].Completed != 1 || binary.LittleEndian.Uint32(dst[0x90:]) != 0 {
		t.Fatal("retry credited twice")
	}
	progressResearch39(&w.World.Barrack39.Categories[2][1][3], ^uint32(0))
	if w.World.Barrack39.Categories[2][1][3].Completed != 46 || w.World.Barrack39.Categories[2][1][3].Progress != 0 {
		t.Fatal("native count overflow")
	}
}

func TestResearch39ResetRollbackOnWriteFailure(t *testing.T) {
	w := campaignWar(t)
	w.World.Barrack39 = nil
	w.World.Research[3][1].Level = 7
	w.path = "/missing/research39-state.json"
	if w.enableCampaign(w.Start) == nil {
		t.Fatal("expected failed write")
	}
	if w.World.Barrack39 != nil || w.World.Research[3][1].Level != 7 {
		t.Fatal("failed reset did not roll back")
	}
}
