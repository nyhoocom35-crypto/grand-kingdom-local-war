package main

// Damage is persistent per operation and target, shared by all attackers. The
// caller records the native result receipt before invoking this function, so a
// transport retry cannot damage the same target twice. Zero-HP records remain
// in the strategy snapshot to let the native client observe their destruction.
func applySiegeVictory40(s *Strategy, target uint32, attacker byte) {
	for i := range s.Objects {
		o := &s.Objects[i]
		if o.ID != target || o.Side == attacker || o.HP == 0 {
			continue
		}
		if o.Type == 5 {
			// Preserve the existing one-win defeat rule for a roaming NPC army.
			s.Objects = append(s.Objects[:i], s.Objects[i+1:]...)
			return
		}
		// Original static map fixtures are 0..4; deployed siege weapons and
		// installations are 6..9. Type 10 is a real mercenary company.
		if o.Type == 10 {
			return
		}
		o.SiegeWins40 = min(byte(5), o.SiegeWins40+1)
		o.HP = min(o.HP, uint32(uint64(o.MaxHP)*uint64(5-o.SiegeWins40)/5))
		return
	}
}
