package main

import "time"

// Population zero enters the native operation completion/settlement path.
type OperationFinish37 struct {
	End       time.Time `json:"end"`
	Completed bool      `json:"completed"`
	Winner    byte      `json:"winner"`
	Delivered bool      `json:"delivered"`
}

func (w *War) updateFinish37(id uint32, s *Strategy, now time.Time) bool {
	if w.World == nil {
		return false
	}
	op, ok := w.World.Operations[id]
	if !ok {
		return false
	}
	changed := false
	if s.Finish37 == nil {
		end := w.fightingEnd()
		if op.Campaign < w.ID {
			end = end.Add(-time.Duration(w.ID-op.Campaign) * campaignLength)
			for _, h := range w.World.History {
				if h.ID == op.Campaign {
					end = h.End.Add(-30 * time.Second)
					break
				}
			}
		}
		s.Finish37 = &OperationFinish37{End: end}
		changed = true
	}
	f := s.Finish37
	if f.Completed || now.Before(f.End) {
		return changed
	}
	fronts, owners := w.World.Fronts, w.World.BaseOwners
	for _, h := range w.World.History {
		if h.ID == op.Campaign {
			fronts, owners = h.Fronts, h.BaseOwners
			break
		}
	}
	winner := byte(1)
	if owners[op.Region][op.Base] == op.Attacker {
		winner = 0
	}
	for _, front := range fronts {
		if front.Region != op.Region || front.Attacker != op.Attacker || front.Defender != op.Defender {
			continue
		}
		for _, base := range front.Bases {
			if base == op.Base {
				winner = 1
				if front.Influence[0] > front.Influence[1] {
					winner = 0
				}
				break
			}
		}
	}
	f.Completed, f.Winner = true, winner
	return true
}

func (w *War) finishEntered37(now time.Time) {
	for id, s := range w.Strategies {
		w.updateFinish37(id, s, now)
	}
}
