package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestFinish37All84MapsDeadlineRolloverRestart(t *testing.T) {
	count := 0
	for region := byte(0); region < 16; region++ {
		if !combatRegion(region) {
			continue
		}
		for base := byte(0); base < 7; base++ {
			w := campaignWar(t)
			id, s, _, req := orderMap36(t, w, region, base)
			deadline := s.Finish37.End
			w.updateFinish37(id, s, deadline.Add(-time.Second))
			if s.Finish37.Completed {
				t.Fatal("early finish")
			}
			w.updateFinish37(id, s, deadline)
			if !s.Finish37.Completed {
				t.Fatal("missing terminal signal")
			}
			winner := s.Finish37.Winner
			w.World.BaseOwners[region][base] = (w.World.Operations[id].Attacker + 2) % 4
			if w.updateFinish37(id, s, deadline.Add(time.Hour)) || s.Finish37.Winner != winner {
				t.Fatal("winner changed")
			}
			// Former server36 deletes the entered map at campaign+2. Keep it until
			// its terminal reply is delivered, even across a long offline interval.
			start := w.Start
			if err := w.advance(start.Add(5 * campaignLength)); err != nil {
				t.Fatal(err)
			}
			if _, ok := w.layout(id); !ok {
				t.Fatal("unfinished result pruned", region, base)
			}
			if err := w.save(); err != nil {
				t.Fatal(err)
			}
			loaded, err := loadWar(w.path)
			if err != nil {
				t.Fatal(err)
			}
			w = loaded
			s = w.Strategies[id]
			if !s.Finish37.End.Equal(deadline) || s.Finish37.Winner != winner {
				t.Fatal("restart changed result")
			}
			d := make([]byte, 1712)
			if ok, err := w.strategyData(d, req); !ok || err != nil {
				t.Fatal("late field reply", err)
			}
			for side := byte(0); side < 2; side++ {
				n := binary.LittleEndian.Uint32(d[0x98+int(side)*0xb4:])
				if (n == 0) != (side != winner) {
					t.Fatal("native terminal population", side, n, winner)
				}
			}
			before, _ := json.Marshal(s)
			if ok, err := w.strategyData(d, req); !ok || err != nil {
				t.Fatal(err)
			}
			after, _ := json.Marshal(s)
			if !bytes.Equal(before, after) {
				t.Fatal("terminal retry changed state")
			}
			if err := w.advance(start.Add(10 * campaignLength)); err != nil {
				t.Fatal(err)
			}
			if _, ok := w.layout(id); ok {
				t.Fatal("acknowledged stale result not pruned")
			}
			count++
		}
	}
	if count != 84 {
		t.Fatal(count)
	}
}

func TestFinish37LegacyMigrationAndSaveRollback(t *testing.T) {
	w := campaignWar(t)
	id, s, _, req := orderMap36(t, w, 0, 0)
	s.Finish37 = nil
	if err := w.advance(w.Start.Add(2 * campaignLength)); err != nil {
		t.Fatal(err)
	}
	s = w.Strategies[id]
	if s == nil || s.Finish37 == nil || !s.Finish37.Completed {
		t.Fatal("legacy ongoing map lost")
	}
	s.Finish37.Delivered = false
	before, _ := json.Marshal(s)
	w.path = filepath.Join(t.TempDir(), "absent", "war.json")
	if ok, err := w.strategyData(make([]byte, 1712), req); ok || err == nil {
		t.Fatal("save failure accepted")
	}
	after, _ := json.Marshal(s)
	if !bytes.Equal(before, after) {
		t.Fatal("save failure consumed terminal reply")
	}
}

// Replay the actual campaign55->57 rejection with the player's exact request
// and original front snapshot. No captured files are shipped in the package.
func TestFinish37CapturedFailureAndNativeFrames(t *testing.T) {
	root := os.Getenv("GK37_NATIVE_CAPTURE")
	if root == "" {
		t.Skip("private replay not requested")
	}
	p := testProtocol(t)
	read := func(name string, response bool) []byte {
		b, err := os.ReadFile(filepath.Join("../user/captures", name))
		if err != nil {
			t.Fatal(err)
		}
		d, err := p.decode(b, response)
		if err != nil {
			t.Fatal(err)
		}
		return d
	}
	bad := read("20261006_061300.113642200_24.response.bin", true)
	if string(bad[:4]) != "@err" {
		t.Fatal("actual rejection absent")
	}
	r := read("20261006_061300.113642200_24.request.bin", false)
	q21 := read("20261006_053329.773950100_21.response.bin", true)
	id := binary.LittleEndian.Uint32(r[0xa0:])
	wire := binary.LittleEndian.Uint32(r[0x9c:])
	campaign := campaignNumber(wire)
	var op Operation
	found := false
	for front := 0; front < 4; front++ {
		for j := 0; j < 3; j++ {
			at := 0x8c + front*0xf0 + 8 + j*0x44
			if binary.LittleEndian.Uint32(q21[at+0x30:]) == id {
				region := q21[0x8c+front*0xf0+0xed]
				attacker := q21[1152+0x14c+front*16+13]
				owner := q21[0x8c+front*0xf0+0xe4+int(q21[at+0x34])]
				if owner == attacker {
					owner = q21[1152+0x1cc+int(region)]
				}
				if owner == attacker {
					owner = (attacker + 1) % 4
				}
				op = Operation{region, q21[at+0x34], attacker, owner, campaign}
				found = true
			}
		}
	}
	if !found {
		t.Fatal("original operation not found")
	}
	w := campaignWar(t)
	w.ID = campaign
	w.Start = time.Now().UTC().Add(-time.Minute)
	w.End = w.Start.Add(campaignLength)
	w.OperationGeneration = (id - 1000) / 12
	w.World.Operations[id] = op
	entry := append([]byte(nil), r...)
	entry[0xa4] = 0
	if ok, err := w.enter(make([]byte, 1600), entry); !ok || err != nil {
		t.Fatal(err)
	}
	if err := w.advance(w.Start.Add(2 * campaignLength)); err != nil {
		t.Fatal(err)
	}
	if w.ID != campaign+2 {
		t.Fatal("wrong boundary")
	}
	b := &Backend{p: p, war: w}
	ep, _ := request16(t, 24)
	frame, status, err := b.response(ep, r)
	if status != "OK" || err != nil {
		t.Fatal("captured request still rejected", status, err)
	}
	if err := os.WriteFile(filepath.Join(root, "captured_repaired_24.response.bin"), frame, 0600); err != nil {
		t.Fatal(err)
	}
	meta, _ := json.Marshal(map[string]any{"id": id, "wire": wire, "region": op.Region, "base": op.Base, "campaign": campaign, "winner": w.Strategies[id].Finish37.Winner})
	os.WriteFile(filepath.Join(root, "captured_meta.json"), meta, 0600)
	// Generate both terminal winners on every map for native validator, live/UI
	// stats and original completion/settlement detection tests.
	for region := byte(0); region < 16; region++ {
		if !combatRegion(region) {
			continue
		}
		for base := byte(0); base < 7; base++ {
			for winner := byte(0); winner < 2; winner++ {
				w := campaignWar(t)
				w.OperationGeneration++
				id := w.operationID(0)
				w.World.Owners[region] = 1
				w.World.BaseOwners[region] = [7]byte{1, 1, 1, 1, 1, 1, 1}
				w.World.Fronts[0] = Front{region, 0, 1, [3]byte{base, (base + 1) % 7, (base + 2) % 7}, [2]uint32{1000, 1000}}
				for i := 1; i < 4; i++ {
					if w.World.Fronts[i].Region == region {
						for x := byte(0); x < 16; x++ {
							if combatRegion(x) && x != region {
								w.World.Fronts[i].Region = x
								break
							}
						}
					}
				}
				w.World.Operations[id] = Operation{region, base, 0, 1, w.ID}
				req := campaignReq(w, 123, 23)
				u32(req, 0xa0, id)
				b := &Backend{p: p, war: w}
				emit := func(api int) {
					ep, r := request16(t, api)
					copy(r[0x9c:], req[0x9c:])
					frame, status, err := b.response(ep, r)
					if err != nil || status != "OK" {
						t.Fatal(status, err)
					}
					if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("map_%02d_%d_%d_%02d.response.bin", region, base, winner, api)), frame, 0600); err != nil {
						t.Fatal(err)
					}
				}
				emit(21)
				emit(23)
				s := w.Strategies[id]
				s.Finish37.Completed = true
				s.Finish37.Winner = winner
				emit(24)
			}
		}
	}
}
