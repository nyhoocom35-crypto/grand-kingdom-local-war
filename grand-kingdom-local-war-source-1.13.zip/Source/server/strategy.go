package main

import (
	_ "embed"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"time"
)

// Coordinates for the twelve selected operations, from the client's matching
// strategy parameter rows. No game executable, troop, name or license is embedded.
//
//go:embed layouts.json
var layoutData []byte

type Layout struct {
	Spawns  [2][][2]byte `json:"spawns"`
	Objects [2][][3]byte `json:"objects"`
}

func (w *War) move(req []byte) (bool, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	id, _, ok := w.strategyLocked(req)
	if !ok || req[0xa4] > 1 {
		return false, nil
	}
	s := w.Strategies[id]
	if s == nil {
		return false, nil
	}
	before := append([]FieldObject(nil), s.Objects...)
	for side := 0; side < 2; side++ {
		objid := binary.LittleEndian.Uint32(req[0xa8+side*4:])
		if objid == 0 {
			continue
		}
		x, y := req[0xb4+side], req[0xb6+side]
		if x == 0 || y == 0 || x > 50 || y > 50 {
			s.Objects = before
			return false, nil
		}
		found := false
		for j := range s.Objects {
			o := &s.Objects[j]
			if o.ID == objid && int(o.Side) == side && o.Type == 10 {
				o.X = x
				o.Y = y
				o.Slot = binary.LittleEndian.Uint16(req[0xb0+side*2:])
				found = true
				break
			}
		}
		if !found {
			s.Objects = before
			return false, nil
		}
	}
	if e := w.save(); e != nil {
		s.Objects = before
		return false, e
	}
	return true, nil
}
func (w *War) place(req []byte) (bool, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	id, l, ok := w.strategyLocked(req)
	if !ok || req[0xa4] > 1 {
		return false, nil
	}
	s := w.Strategies[id]
	if s == nil {
		return false, nil
	}
	side := req[0xa4]
	player := binary.LittleEndian.Uint32(req[0x24:])
	if player == 0 {
		return false, nil
	}
	ballot := PlacementBallot25{Side: side}
	for slot := range ballot.Choices {
		choice := req[0xa8+slot]
		if !validDeployment25(choice) {
			return false, nil
		}
		if choice != 11 {
			allowed := false
			for _, candidate := range deploymentCandidates25(l, int(side), slot) {
				if choice == candidate {
					allowed = true
				}
			}
			if !allowed {
				choice = 11
			}
		}
		if !usableSpawn25(l.Spawns[side][slot]) {
			choice = 11
		}
		ballot.Choices[slot] = choice
	}
	err := w.change(func() error {
		w.updateVotes25(id, s, l, time.Now().UTC())
		// A delayed/retried ballot is acknowledged without reopening voting.
		if s.Votes.Resolved {
			return nil
		}
		delete(s.Votes.Placements, 0xfffffff0+uint32(side))
		s.Votes.Placements[player] = ballot
		s.Placements[side] = ballot.Choices
		return nil
	})
	return err == nil, err
}

func (w *War) validateStrategies() error {
	for id, s := range w.Strategies {
		if _, ok := w.layout(id); !ok || s == nil || s.Began.IsZero() || len(s.Objects) > 36 {
			return errors.New("invalid saved strategy state")
		}
		seen := map[uint32]bool{}
		for _, o := range s.Objects {
			if o.ID == 0 || seen[o.ID] || o.Side > 1 || o.Type > 10 || o.X == 0 || o.Y == 0 || o.X > 50 || o.Y > 50 || o.HP > o.MaxHP || o.MaxHP == 0 || o.SiegeWins40 > 5 {
				return errors.New("invalid saved strategy object")
			}
			seen[o.ID] = true
		}
		if err := validateVotes25(s.Votes); err != nil {
			return err
		}
		if f := s.Finish37; f != nil && (f.End.IsZero() || f.Winner > 1 || f.Delivered && !f.Completed) {
			return errors.New("invalid saved operation finish")
		}
	}
	return nil
}

type FieldObject struct {
	ID          uint32 `json:"id"`
	Slot        uint16 `json:"slot"`
	Type        byte   `json:"type"`
	Side        byte   `json:"side"`
	X           byte   `json:"x"`
	Y           byte   `json:"y"`
	HP          uint32 `json:"hp"`
	MaxHP       uint32 `json:"max_hp"`
	SiegeWins40 byte   `json:"siege_wins40,omitempty"`
}
type Strategy struct {
	BattleReceipts45 map[string]bool    `json:"battle_receipts45,omitempty"`
	RankPopulation45 *RankPopulation45  `json:"rank_population45,omitempty"`
	Finish37         *OperationFinish37 `json:"finish37,omitempty"`
	Began            time.Time          `json:"began"`
	Placements       [2][10]byte        `json:"placements"`
	Objects          []FieldObject      `json:"objects"`
	Votes            *StrategyVotes25   `json:"votes25,omitempty"`
}

func layoutFor(id uint32) (Layout, bool) {
	var ls map[string]Layout
	if json.Unmarshal(layoutData, &ls) != nil {
		return Layout{}, false
	}
	if id < 1000 {
		return Layout{}, false
	}
	l, ok := ls[fmt.Sprint(1000+(id-1000)%12)]
	return l, ok
}
func (w *War) strategy(req []byte) (uint32, Layout, bool) {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.strategyLocked(req)
}
func (w *War) strategyLocked(req []byte) (uint32, Layout, bool) {
	id := binary.LittleEndian.Uint32(req[0xa0:])
	l, ok := w.layout(id)
	campaign := campaignNumber(binary.LittleEndian.Uint32(req[0x9c:]))
	if w.World != nil {
		op, known := w.World.Operations[id]
		return id, l, ok && known && campaign == op.Campaign && (campaign == w.ID || w.Strategies[id] != nil)
	}
	current := id >= w.operationID(0) && id <= w.operationID(11)
	return id, l, ok && campaign == w.ID && (current || w.Strategies[id] != nil)
}
func (w *War) enter(dst, req []byte) (bool, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	id, l, ok := w.strategyLocked(req)
	if !ok || req[0xa4] > 1 {
		return false, nil
	}
	if w.World == nil && (id < w.operationID(0) || id > w.operationID(11)) {
		return false, nil
	}
	if w.Strategies == nil {
		w.Strategies = map[uint32]*Strategy{}
	}
	if w.Strategies[id] == nil {
		deadline := w.VoteDeadlines44[id]
		if deadline.IsZero() {
			deadline = time.Now().UTC().Add(60 * time.Second).Truncate(time.Second)
		}
		s := &Strategy{Began: deadline}
		w.updateFinish37(id, s, time.Now().UTC())
		for side := 0; side < 2; side++ {
			for j, obj := range l.Objects[side] {
				if obj[1] == 0 || obj[2] == 0 {
					continue
				}
				s.Objects = append(s.Objects, FieldObject{ID: uint32(1 + side*9 + j), Type: obj[0], Side: byte(side), X: obj[1], Y: obj[2], HP: 1000, MaxHP: 1000})
			}
		}
		// Field armies reference the original rival-party slots. Empty online
		// player IDs in GetRivalTroop invoke the client's built-in NPC generator.
		for side := 0; side < 2; side++ {
			for j, p := range l.Spawns[side] {
				if j >= 6 || p[0] == 0 || p[1] == 0 || (side == int(req[0xa4]) && j == 0) {
					continue
				}
				s.Objects = append(s.Objects, FieldObject{ID: uint32(100 + side*30 + j), Slot: uint16(side*6 + j), Type: 5, Side: byte(side), X: p[0], Y: p[1], HP: 1000, MaxHP: 1000})
			}
		}
		w.Strategies[id] = s
		if e := w.save(); e != nil {
			delete(w.Strategies, id)
			return false, e
		}
	}
	// The current user's field token is separate from the rival NPC armies.
	player := uint32(30001 + uint32(req[0xa4]))
	found := false
	for _, o := range w.Strategies[id].Objects {
		if o.ID == player {
			found = true
		}
	}
	if !found {
		side := req[0xa4]
		// Remove the NPC token at this side's first deployment tile when a
		// second local side joins later, so it cannot overlap the player.
		beforeObjects := append([]FieldObject(nil), w.Strategies[id].Objects...)
		for j, o := range w.Strategies[id].Objects {
			if o.ID == uint32(100+30*uint32(side)) {
				w.Strategies[id].Objects = append(w.Strategies[id].Objects[:j], w.Strategies[id].Objects[j+1:]...)
				break
			}
		}
		p := l.Spawns[side][0]
		w.Strategies[id].Objects = append(w.Strategies[id].Objects, FieldObject{ID: player, Type: 10, Side: side, X: p[0], Y: p[1], HP: 1000, MaxHP: 1000})
		if e := w.save(); e != nil {
			w.Strategies[id].Objects = beforeObjects
			return false, e
		}
	}
	u16(dst, 0x8c, 1000)
	u16(dst, 0x8e, 1000)
	for side := 0; side < 2; side++ {
		for j, p := range l.Spawns[side] {
			dst[0x5a8+side*20+j] = p[0]
			dst[0x5a8+side*20+j+10] = p[1]
		}
		for j, o := range l.Objects[side] {
			at := 0x5d0 + (side*9+j)*4
			copy(dst[at:], o[:])
		}
	}
	return true, nil
}
func (w *War) strategyData(dst, req []byte) (bool, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	id, l, ok := w.strategyLocked(req)
	if !ok {
		return false, nil
	}
	s := w.Strategies[id]
	if s == nil {
		return false, nil
	}
	before, err := json.Marshal(s)
	if err != nil {
		return false, err
	}
	now := time.Now().UTC()
	changed := w.updateVotes25(id, s, l, now)
	if w.updateFinish37(id, s, now) {
		changed = true
	}
	if s.Finish37 != nil && s.Finish37.Completed && !s.Finish37.Delivered {
		s.Finish37.Delivered = true
		changed = true
	}
	rankWasFrozen := s.RankPopulation45 != nil && s.RankPopulation45.Frozen != nil
	rankCounts := w.rankPopulation45(id, s, now)
	if !rankWasFrozen && s.RankPopulation45.Frozen != nil {
		changed = true
	}
	if changed {
		if e := w.save(); e != nil {
			*s = Strategy{}
			_ = json.Unmarshal(before, s)
			return false, e
		}
	}
	putDate(dst[0x8c:], s.Began)
	policy := s.Votes.policyCounts25()
	commands := s.Votes.commandCounts25()
	for side := 0; side < 2; side++ {
		o := 0x98 + side*0xb4
		// The unit population and maxima must satisfy the original side validator.
		u32(dst, o, 6)
		if s.Finish37 != nil && s.Finish37.Completed && byte(side) != s.Finish37.Winner {
			u32(dst, o, 0)
		}
		dst[o+0x3a] = 1
		dst[o+0x3b] = 1
		for j := 0; j < 6; j++ {
			weight := uint32(0)
			for kind := 0; kind < 3; kind++ {
				weight = saturate(weight, policy[side][kind][j])
			}
			u32(dst, o+4+4*j, max(uint32(1), weight))
			u32(dst, o+0x1c+4*j, 1000)
			u32(dst, o+0x3c+4*j, 1000)
			dst[o+0x34+j] = commands[side][j]
		}
		for kind := 0; kind < 3; kind++ {
			for candidate := 0; candidate < 8; candidate++ {
				u32(dst, o+0x54+kind*32+candidate*4, rankCounts[side][kind][candidate])
			}
		}
	}
	for i, o := range s.Objects {
		at := 0x230 + i*0x1c
		u32(dst, at, o.ID)
		u16(dst, at+4, o.Slot)
		dst[at+8] = o.Type
		dst[at+9] = o.Side
		dst[at+10] = o.X
		dst[at+11] = o.Y
		u32(dst, at+0xc, o.HP)
		u32(dst, at+0x14, o.MaxHP)
		if o.HP == 0 {
			dst[at+0x18] = 1
		}
	}
	return true, nil
}
func (w *War) beginStrategy(dst, req []byte) (bool, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	id, _, ok := w.strategyLocked(req)
	if !ok {
		return false, nil
	}
	s := w.Strategies[id]
	if s == nil {
		return false, nil
	}
	putDate(dst[0x8c:], s.Began)
	return true, nil
}
