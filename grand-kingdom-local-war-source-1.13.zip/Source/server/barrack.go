package main

// Legacy snapshot retained for pre-campaign fixtures; version 15 adds persistent
// automatically resolved research through barrackCountry.
func (w *War) barrack(dst []byte) {
	for j := 0; j < 10; j++ {
		u16(dst, 0xec+2*j, 100)
	}
	for j := 0; j < 8; j++ {
		dst[0x100+j] = 1
	}
	dst[0x108] = 50
}

// No local campaign has finished and no ranked participants exist yet. The
// original client explicitly accepts FF region sentinels and zero player IDs.
// This avoids fabricating battle results/rewards when it asks for old rankings.
func (w *War) emptyResults(dst []byte) {
	w.mu.Lock()
	defer w.mu.Unlock()
	for i := 0; i < 4; i++ {
		dst[0x8c+0x24*i+0x22] = 0xff
	}
	for i := 0; i < 16; i++ {
		dst[0x500+i] = byte(i / 4)
		if w.World != nil {
			dst[0x500+i] = w.World.Owners[i]
			if n := len(w.World.History); n > 0 {
				dst[0x500+i] = w.World.History[n-1].Owners[i]
			}
		}
	}
}
