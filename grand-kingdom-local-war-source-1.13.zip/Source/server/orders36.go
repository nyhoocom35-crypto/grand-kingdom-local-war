package main

import "sort"

// One shared activation per army per operation, across all six order kinds.
// AI and player registrations spend the same allowance. Polls never spend it.
const orderLimitPerSide36 = 1

func (v *StrategyVotes25) orderPlayers36() []uint32 {
	players := make([]uint32, 0, len(v.Commands))
	for id := range v.Commands {
		players = append(players, id)
	}
	sort.Slice(players, func(i, j int) bool { return players[i] < players[j] })
	return players
}

func (v *StrategyVotes25) orderTotal36(side int) int {
	total := 0
	for _, n := range v.AICommands[side] {
		total += int(n)
	}
	for _, r := range v.Commands {
		if int(r.Side) == side {
			for _, n := range r.Counts {
				total += int(n)
			}
		}
	}
	return total
}

// Old server saves can contain dozens of commands. Normalize only the order
// counters once, keeping the same operation ID, map, votes, objects and troops.
func (v *StrategyVotes25) normalizeOrders36() bool {
	if v.OrderRevision36 == 36 {
		return false
	}
	left := [2]int{orderLimitPerSide36, orderLimitPerSide36}
	for side := 0; side < 2; side++ {
		for kind, n := range v.AICommands[side] {
			accepted := min(int(n), left[side])
			v.AICommands[side][kind] = byte(accepted)
			left[side] -= accepted
		}
	}
	for _, id := range v.orderPlayers36() {
		r := v.Commands[id]
		for kind, n := range r.Counts {
			accepted := min(int(n), left[r.Side])
			r.Counts[kind] = byte(accepted)
			left[r.Side] -= accepted
		}
		v.Commands[id] = r
	}
	v.OrderRevision36 = 36
	return true
}
