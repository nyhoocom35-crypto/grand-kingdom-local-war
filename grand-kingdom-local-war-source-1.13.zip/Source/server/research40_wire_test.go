package main

import (
	"encoding/json"
	"testing"
)

func TestResearch40EncryptedNativeFrames(t *testing.T) {
	p := testProtocol(t)
	w := campaignWar(t)
	w.Contracts[123] = 0
	b := &Backend{war: w, p: p}
	var endpoints []Endpoint
	if err := json.Unmarshal(schemaData, &endpoints); err != nil {
		t.Fatal(err)
	}
	op := w.operationID(0)
	entry := campaignReq(w, 123, 23)
	u32(entry, 0xa0, op)
	if ok, err := w.enter(make([]byte, 17000), entry); err != nil || !ok {
		t.Fatal(ok, err)
	}
	for _, api := range []int{11, 12, 20, 21, 24, 33} {
		ep := endpoints[api]
		req := make([]byte, ep.RequestPadded)
		u32(req, 4, 0x3130786b)
		u32(req, 8, ep.OperationCode)
		u32(req, 12, uint32(ep.ResponseLogical))
		u32(req, 0x24, 123)
		u32(req, 0x9c, w.wireID())
		if api == 12 {
			u32(req, 0x9c, 2)
		}
		if api == 11 {
			req[0xc4], req[0xc5], req[0xc6] = 1, 2, 3
			u32(req, 0xa4, 10000)
		}
		if api == 24 || api == 33 {
			u32(req, 0xa0, op)
		}
		if api == 33 {
			req[0xa5] = 1
			u16(req, 0xcc, 10)
		}
		frame, status, err := b.response(ep, req)
		if err != nil || status != "OK" {
			t.Fatal(api, status, err)
		}
		decoded, err := p.decode(frame, true)
		if err != nil || string(decoded[:4]) != "@suc" {
			t.Fatal(api, "native encrypted framing rejected", err)
		}
	}
}
