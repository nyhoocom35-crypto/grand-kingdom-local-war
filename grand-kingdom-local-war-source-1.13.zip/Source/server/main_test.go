package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"io"
	"log"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

func testProtocol(t *testing.T) *Protocol {
	t.Helper()
	s := os.Getenv("GK_TEST_SELF")
	if s == "" {
		t.Skip("set GK_TEST_SELF to the authorized decrypted SELF")
	}
	b, e := os.ReadFile(s)
	if e != nil {
		t.Fatal(e)
	}
	data := []byte{}
	for _, v := range []int{0x8146bb80, 0x8146bcc0, 0x8146be00, 0x8146bf40} {
		o := v - 0x81000000 + 0x10e0
		data = append(data, b[o:o+320]...)
	}
	return &Protocol{tables: data}
}
func TestFramesGeneratedByGame(t *testing.T) {
	p := testProtocol(t)
	for _, n := range []int{0, 1, 2} {
		f, e := os.ReadFile(filepath.Join("testdata", string([]byte{'0' + byte(n/10), '0' + byte(n%10)})+".request.bin"))
		if e != nil {
			t.Fatal(e)
		}
		q, e := p.decode(f, false)
		if e != nil {
			t.Fatal(n, e)
		}
		if binary.LittleEndian.Uint32(q[4:]) != 0x3130786b {
			t.Fatal("wrong decoded game header")
		}
		f[3] ^= 1
		if _, e = p.decode(f, false); e == nil {
			t.Fatal("tampered frame accepted")
		}
	}
}
func TestLoginHTTPAndPersistence(t *testing.T) {
	p := testProtocol(t)
	dir := t.TempDir()
	users, e := loadUsers(filepath.Join(dir, "users.json"))
	if e != nil {
		t.Fatal(e)
	}
	var eps []Endpoint
	if e = json.Unmarshal(schemaData, &eps); e != nil {
		t.Fatal(e)
	}
	b := &Backend{p: p, users: users, endpoints: map[string]Endpoint{}, log: log.New(io.Discard, "", 0), captureDir: dir}
	for _, ep := range eps {
		b.endpoints[ep.Path] = ep
	}
	for _, n := range []int{0, 1, 2} {
		f, e := os.ReadFile(filepath.Join("testdata", string([]byte{'0' + byte(n/10), '0' + byte(n%10)})+".request.bin"))
		if e != nil {
			t.Fatal(e)
		}
		r := httptest.NewRequest("POST", eps[n].Path, bytes.NewReader(f))
		w := httptest.NewRecorder()
		b.ServeHTTP(w, r)
		if w.Code != 200 {
			t.Fatal(n, w.Code, w.Body.String())
		}
		body := w.Body.Bytes()
		if len(body) != eps[n].ResponseFrame {
			t.Fatal(n, "wrong response length")
		}
		plain, e := p.decode(body, true)
		if e != nil {
			t.Fatal(e)
		}
		if n == 20 {
			if string(plain[:4]) != "@err" || binary.LittleEndian.Uint32(plain[4:]) != 60000 {
				t.Fatal("unsupported war must return explicit error")
			}
		} else if string(plain[:4]) != "@suc" {
			t.Fatal(n, "failed login response")
		}
		if n == 1 {
			uid := binary.LittleEndian.Uint32(plain[0x8c:])
			if uid == 0 {
				t.Fatal("zero user ID")
			}
			inner, e := p.crypt(plain[0x94:0xc4], true, false, plain[12], plain[13])
			if e != nil || string(inner[:40]) != token("identity", uid) {
				t.Fatal("wrong signup identity token")
			}
		}
		if e = os.WriteFile(filepath.Join("testdata", string([]byte{'0' + byte(n/10), '0' + byte(n%10)})+".response.bin"), body, 0600); e != nil {
			t.Fatal(e)
		}
	}
	loaded, e := loadUsers(users.path)
	if e != nil || len(loaded.Data) != 1 {
		t.Fatal("user state did not persist", e)
	}
	for name, v := range loaded.Data {
		if _, e = loaded.ensure(name, v.ID+1, v.Revision); e == nil {
			t.Fatal("ID conflict accepted")
		}
	}
}
func TestPrepareOnlyChangesHost(t *testing.T) {
	s := os.Getenv("GK_TEST_SELF")
	if s == "" {
		t.Skip()
	}
	dir := t.TempDir()
	target := filepath.Join(dir, "patched.bin")
	if e := prepare(s, target, dir); e != nil {
		t.Fatal(e)
	}
	old, e := os.ReadFile(s)
	if e != nil {
		t.Fatal(e)
	}
	next, e := os.ReadFile(target)
	if e != nil {
		t.Fatal(e)
	}
	if len(old) != len(next) {
		t.Fatal("length changed")
	}
	for i := range old {
		if old[i] != next[i] && (i < 0x46d180 || i >= 0x46d180+len(originalHost)) {
			t.Fatal("non-host byte changed")
		}
	}
	if string(bytes.SplitN(next[0x46d180:0x46d1b0], []byte{0}, 2)[0]) != "127.0.0.1" {
		t.Fatal("wrong host")
	}
	if e = prepare(target, filepath.Join(dir, "second.bin"), dir); e == nil {
		t.Fatal("unknown binary accepted")
	}
}
