package main

import (
	"encoding/binary"
	"testing"
)

// Coverage includes successive campaigns, every appearance variant and all
// classes, not just the one map/roster reported by the player.
func TestRival47SkillsAllClassesAndCampaignVariants(t *testing.T) {
	c, ok := aiCompany(0xf0000000)
	if !ok {
		t.Fatal("missing AI company")
	}
	seen := map[uint16]bool{}
	for variant := 0; variant < 59*30; variant++ {
		d := variedRival46(c, 0xf0000000, variant, 5)
		for j := 0; j < 4; j++ {
			u := d[276+j*202:]
			class := binary.LittleEndian.Uint16(u)
			seen[class] = true
			active := 0
			for _, id := range u[0x84:0x8c] {
				if id != 255 {
					active++
				}
				if id >= 100 && id != 106 && id != 255 {
					t.Fatal("unknown shared skill", class, id)
				}
			}
			if active == 0 {
				t.Fatal("AI has no actions", class, variant)
			}
			if u[0x8a] != 255 || u[0x8b] != 255 {
				t.Fatal("reserved active slots altered")
			}
		}
	}
	if len(seen) != len(rivalClasses46) {
		t.Fatal("class coverage", len(seen))
	}
}
