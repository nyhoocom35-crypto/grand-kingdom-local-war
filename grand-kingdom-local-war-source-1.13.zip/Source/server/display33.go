package main

import (
	_ "embed"
	"encoding/json"
	"fmt"
	"regexp"
	"strconv"
)

// Selected localized STATIONED.MES entries. Numeric wire IDs stay unchanged.
// Native getters: country 100+id, region 30000+id, base 31000+region*10+base.
//
//go:embed display-names33.json
var displayNameData33 []byte

type DisplayNames33 struct {
	Countries []string   `json:"country_names"`
	Regions   []string   `json:"region_names"`
	Bases     [][]string `json:"base_names"`
}

var displayNames33 = func() DisplayNames33 {
	var names DisplayNames33
	if err := json.Unmarshal(displayNameData33, &names); err != nil {
		panic(err)
	}
	if len(names.Countries) != 4 || len(names.Regions) != 17 || len(names.Bases) != 17 {
		panic("invalid name catalog")
	}
	for _, row := range names.Bases {
		if len(row) != 7 {
			panic("invalid base names")
		}
	}
	return names
}()

func countryName33(id int) string {
	if id == 4 {
		return "길드"
	}
	if id >= 0 && id < len(displayNames33.Countries) {
		return displayNames33.Countries[id]
	}
	return "알 수 없는 국가"
}
func regionName33(id int) string {
	if id >= 0 && id < len(displayNames33.Regions) {
		return displayNames33.Regions[id]
	}
	return "알 수 없는 지역"
}
func baseName33(region, base int) string {
	if base == 23 {
		return "지역 전체"
	}
	if region >= 0 && region < len(displayNames33.Bases) && base >= 0 && base < len(displayNames33.Bases[region]) {
		return displayNames33.Bases[region][base]
	}
	return "알 수 없는 거점"
}

var eventRules33 = []struct {
	pattern *regexp.Regexp
	render  func([]string) string
}{
	{regexp.MustCompile(`^Round (\d+): country (\d+) vote selected region (\d+) base (\d+) \((\d+) votes\)$`), func(m []string) string {
		return fmt.Sprintf("%s라운드: %s 침공 투표 — %s / %s (%s표)", m[1], countryName33(number33(m[2])), regionName33(number33(m[3])), baseName33(number33(m[3]), number33(m[4])), m[5])
	}},
	{regexp.MustCompile(`^Round (\d+): country (\d+) defeats country (\d+) at region (\d+), influence (\d+):(\d+)$`), func(m []string) string {
		return fmt.Sprintf("%s라운드: %s에서 %s 승리, %s 패배 (공격·방어 영향력 %s:%s)", m[1], regionName33(number33(m[4])), countryName33(number33(m[2])), countryName33(number33(m[3])), m[5], m[6])
	}},
	{regexp.MustCompile(`^Territory (\d+) captured: country (\d+) -> (\d+)$`), func(m []string) string {
		return fmt.Sprintf("%s 영토 소유권: %s → %s", regionName33(number33(m[1])), countryName33(number33(m[2])), countryName33(number33(m[3])))
	}},
	{regexp.MustCompile(`^Country (\d+) player ballot: region (\d+) base (\d+) weight (\d+)$`), func(m []string) string {
		return fmt.Sprintf("%s 플레이어 침공 투표: %s / %s (%s표)", countryName33(number33(m[1])), regionName33(number33(m[2])), baseName33(number33(m[2]), number33(m[3])), m[4])
	}},
	{regexp.MustCompile(`^Country (\d+) barrack (\d+) automatically selected item (\d+), level (\d+)$`), func(m []string) string {
		kind := "병기"
		if m[2] == "1" {
			kind = "지원"
		}
		return fmt.Sprintf("%s 병영 %s 연구 자동 결정: 항목 %s, 레벨 %s", countryName33(number33(m[1])), kind, m[3], m[4])
	}},
	{regexp.MustCompile(`^Campaign (\d+) finished$`), func(m []string) string { return "캠페인 " + m[1] + " 종료" }},
}

func number33(s string) int { v, _ := strconv.Atoi(s); return v }

// Translate a presentation copy; do not rewrite persistent campaign history.
func displayEvents33(events []string) []string {
	out := make([]string, len(events))
	for i, event := range events {
		out[i] = event
		for _, rule := range eventRules33 {
			if m := rule.pattern.FindStringSubmatch(event); m != nil {
				out[i] = rule.render(m)
				break
			}
		}
	}
	return out
}
