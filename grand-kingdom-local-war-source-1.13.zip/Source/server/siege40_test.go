package main

import (
	"encoding/binary"
	"fmt"
	"testing"
	"time"
)

func TestSiege40FiveWinsAllLayoutsAndStructures(t *testing.T) {
	if len(worldLayouts22) != 112 {
		t.Fatal("unexpected map catalog")
	}
	tested := 0
	for name, layout := range worldLayouts22 {
		var region, base int
		if _, err := fmt.Sscanf(name, "%d:%d", &region, &base); err != nil {
			t.Fatal(err)
		}
		if !combatRegion(byte(region)) {
			continue
		}
		tested++
		for side := byte(0); side < 2; side++ {
			for _, kind := range []byte{0, 1, 2, 3, 4, 6, 7, 8, 9} {
				p := layout.Spawns[side][0]
				s := &Strategy{Objects: []FieldObject{{ID: 1, Side: side, Type: kind, X: p[0], Y: p[1], HP: 1000, MaxHP: 1000}}}
				for win := 1; win <= 5; win++ {
					applySiegeVictory40(s, 1, 1-side)
					if s.Objects[0].HP != uint32(1000-win*200) || s.Objects[0].SiegeWins40 != byte(win) {
						t.Fatal(name, side, kind, win, s.Objects[0])
					}
				}
				applySiegeVictory40(s, 1, 1-side)
				if s.Objects[0].HP != 0 || s.Objects[0].SiegeWins40 != 5 {
					t.Fatal("destroyed target revived")
				}
			}
		}
	}
	if tested != 84 {
		t.Fatal("not all 84 battle maps tested", tested)
	}
}

func TestSiege40BattleReceiptLossPersistenceAndWireDestruction(t *testing.T) {
	w := campaignWar(t)
	op := w.operationID(0)
	req := campaignReq(w, 123, 33)
	u32(req, 0xa0, op)
	req[0xa4] = 0
	entry := make([]byte, 17000)
	if ok, err := w.enter(entry, req); err != nil || !ok {
		t.Fatal(ok, err)
	}
	s := w.Strategies[op]
	var target uint32
	for _, o := range s.Objects {
		if o.Side == 1 && o.Type == 0 {
			target = o.ID
			break
		}
	}
	if target == 0 {
		t.Fatal("missing headquarters")
	}
	u16(req, 0xcc, uint16(target))
	get := func() FieldObject {
		for _, o := range w.Strategies[op].Objects {
			if o.ID == target {
				return o
			}
		}
		t.Fatal("required HQ record removed")
		return FieldObject{}
	}
	dst := make([]byte, 144)
	for win := 1; win <= 5; win++ {
		req[0xa5] = 0
		u32(req, 0xac, uint32(win*10))
		if err := w.campaignRequest(33, dst, req); err != nil {
			t.Fatal(err)
		}
		if get().HP != uint32(1200-win*200) {
			t.Fatal("loss damaged building")
		}
		req[0xa5] = 1
		if err := w.campaignRequest(33, dst, req); err != nil {
			t.Fatal(err)
		}
		if err := w.campaignRequest(33, dst, req); err != nil {
			t.Fatal(err)
		}
		if get().HP != uint32(1000-win*200) {
			t.Fatal("retry or victory HP mismatch", win, get())
		}
		reloaded, err := loadWar(w.path)
		if err != nil {
			t.Fatal(err)
		}
		w = reloaded
	}
	if w.World.Ranks[123].Wins != 5 || w.World.Ranks[123].Losses != 5 {
		t.Fatal("battle receipts incorrect")
	}
	frame := make([]byte, 1696)
	if ok, err := w.strategyData(frame, req); err != nil || !ok {
		t.Fatal(ok, err)
	}
	found := false
	for j := 0; j < 36; j++ {
		at := 0x230 + j*28
		if binary.LittleEndian.Uint32(frame[at:]) == target {
			found = true
			if binary.LittleEndian.Uint32(frame[at+12:]) != 0 || frame[at+24] != 1 {
				t.Fatal("native destruction fields missing")
			}
		}
	}
	if !found {
		t.Fatal("zero-HP HQ omitted; native validator requires both headquarters")
	}
	if err := w.validateStrategies(); err != nil {
		t.Fatal(err)
	}
	if err := w.advance(w.End.Add(time.Minute)); err != nil {
		t.Fatal(err)
	}
	if get().HP != 0 {
		t.Fatal("rollover resurrected old operation")
	}
}

func TestSiege40FriendlyCompanyAndNPCBehavior(t *testing.T) {
	for _, kind := range []byte{0, 6, 10} {
		s := &Strategy{Objects: []FieldObject{{ID: 1, Side: 0, Type: kind, HP: 1000, MaxHP: 1000}}}
		applySiegeVictory40(s, 1, 0)
		if s.Objects[0].HP != 1000 {
			t.Fatal("friendly damaged")
		}
		if kind == 10 {
			applySiegeVictory40(s, 1, 1)
			if s.Objects[0].HP != 1000 {
				t.Fatal("real player damaged as building")
			}
		}
	}
	s := &Strategy{Objects: []FieldObject{{ID: 1, Side: 1, Type: 5, HP: 1000, MaxHP: 1000}}}
	applySiegeVictory40(s, 1, 0)
	if len(s.Objects) != 0 {
		t.Fatal("NPC defeat behavior changed")
	}
	s = &Strategy{Objects: []FieldObject{{ID: 1, Side: 1, Type: 6, HP: 101, MaxHP: 101}}}
	for j := 0; j < 5; j++ {
		applySiegeVictory40(s, 1, 0)
	}
	if s.Objects[0].HP != 0 {
		t.Fatal("rounding prevented final destruction")
	}
}
