package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

func TestEmptyVoteReconnect29(t *testing.T) {
	for _, contract := range []int{-1, 0, 1, 2, 3, 4} {
		for _, weight := range []uint16{0, 10, 20, 9999} {
			w := campaignWar(t)
			if contract >= 0 {
				w.Contracts[123] = byte(contract)
			}
			previous := Ballot{5, 23, 0, 12}
			w.World.Votes[123] = previous
			if err := w.save(); err != nil {
				t.Fatal(err)
			}
			before, _ := json.Marshal(w)
			disk, _ := os.ReadFile(w.path)
			req := campaignReq(w, 123, 10)
			req[0xa2] = 255
			req[0xa3] = 23
			u16(req, 0xa0, weight)
			for repeat := 0; repeat < 3; repeat++ {
				if err := w.campaignRequest(10, make([]byte, 160), req); err != nil {
					t.Fatal(contract, weight, err)
				}
			}
			after, _ := json.Marshal(w)
			afterdisk, _ := os.ReadFile(w.path)
			if !bytes.Equal(before, after) || !bytes.Equal(disk, afterdisk) || w.World.Votes[123] != previous {
				t.Fatal("empty sync altered vote/state")
			}
		}
	}
}

func TestBallotValidation29(t *testing.T) {
	w := campaignWar(t)
	w.Contracts[123] = 0
	for region := byte(0); region < 16; region++ {
		for _, base := range []byte{0, 1, 2, 3, 4, 5, 6, 23} {
			req := campaignReq(w, 123, 10)
			req[0xa2] = region
			req[0xa3] = base
			u16(req, 0xa0, 20)
			if err := w.campaignRequest(10, make([]byte, 160), req); err != nil {
				t.Fatal(region, base, err)
			}
			if w.World.Votes[123] != (Ballot{region, base, 0, 20}) {
				t.Fatal("real ballot not recorded")
			}
		}
	}
	for _, invalid := range [][3]uint16{{255, 23, 10000}, {255, 0, 20}, {16, 23, 20}, {0, 7, 20}, {0, 255, 20}, {0, 0, 10000}} {
		req := campaignReq(w, 123, 10)
		req[0xa2] = byte(invalid[0])
		req[0xa3] = byte(invalid[1])
		u16(req, 0xa0, invalid[2])
		before, _ := json.Marshal(w)
		if err := w.campaignRequest(10, make([]byte, 160), req); err == nil {
			t.Fatal("malformed accepted", invalid)
		}
		after, _ := json.Marshal(w)
		if !bytes.Equal(before, after) {
			t.Fatal("malformed changed state")
		}
	}
}

func TestCapturedReconnect29(t *testing.T) {
	root := os.Getenv("GK_RECONNECT29_CAPTURE_DIR")
	if root == "" {
		t.Skip("private reconnect captures not requested")
	}
	p := testProtocol(t)
	files, err := filepath.Glob(filepath.Join(root, "*20261005_14*_10.request.bin"))
	if err != nil || len(files) != 13 {
		t.Fatal(files, err)
	}
	w := campaignWar(t)
	users, err := loadUsers(filepath.Join(t.TempDir(), "users.json"))
	if err != nil {
		t.Fatal(err)
	}
	var eps []Endpoint
	if err = json.Unmarshal(schemaData, &eps); err != nil {
		t.Fatal(err)
	}
	out := "testdata/reconnect29"
	if err = os.MkdirAll(out, 0700); err != nil {
		t.Fatal(err)
	}
	b := &Backend{war: w, p: p, users: users, endpoints: map[string]Endpoint{}, log: log.New(io.Discard, "", 0), captureDir: out}
	for _, ep := range eps {
		b.endpoints[ep.Path] = ep
	}
	for _, path := range files {
		frame, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		req, err := p.decode(frame, false)
		if err != nil {
			t.Fatal(err)
		}
		if req[0xa2] != 255 || req[0xa3] != 23 {
			t.Fatal("captured sentinel changed")
		}
		// Replay against the same campaign, where server26 rejected the sentinel.
		w.ID = campaignNumber(binary.LittleEndian.Uint32(req[0x9c:]))
		w.Contracts[binary.LittleEndian.Uint32(req[0x24:])] = 0
		before, _ := json.Marshal(w)
		rw := httptest.NewRecorder()
		b.ServeHTTP(rw, httptest.NewRequest("POST", eps[10].Path, bytes.NewReader(frame)))
		if rw.Code != 200 {
			t.Fatal(filepath.Base(path), rw.Code, rw.Body.String())
		}
		plain, err := p.decode(rw.Body.Bytes(), true)
		if err != nil || string(plain[:4]) != "@suc" {
			t.Fatal(err)
		}
		if len(rw.Body.Bytes()) != eps[10].ResponseFrame {
			t.Fatal("native frame length")
		}
		after, _ := json.Marshal(w)
		if !bytes.Equal(before, after) {
			t.Fatal("sync mutated campaign")
		}
		if err = os.WriteFile(filepath.Join(out, filepath.Base(path)+".reply"), rw.Body.Bytes(), 0600); err != nil {
			t.Fatal(err)
		}
	}
	// Replay the actual failed login chain, including the captured Being,
	// UserSignIn and UpdateTroop requests before the rejected ballot.
	chain, err := filepath.Glob(filepath.Join(root, "*20261005_143235*.request.bin"))
	if err != nil || len(chain) != 6 {
		t.Fatal(chain, err)
	}
	for _, path := range chain {
		var api int
		fmt.Sscanf(filepath.Base(path)[len("20261005_143235.000000000_"):], "%d.request.bin", &api)
		frame, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		rw := httptest.NewRecorder()
		b.ServeHTTP(rw, httptest.NewRequest("POST", eps[api].Path, bytes.NewReader(frame)))
		if rw.Code != 200 {
			t.Fatal("reconnect chain", api, rw.Code, rw.Body.String())
		}
		plain, err := p.decode(rw.Body.Bytes(), true)
		if err != nil || string(plain[:4]) != "@suc" {
			t.Fatal("chain response", api, err)
		}
	}
	t.Log("13 captured empty ballots and 6-request login chain: HTTP200, native success frame, no fake ballots")
}
