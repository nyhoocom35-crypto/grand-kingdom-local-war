package main

import (
	"encoding/binary"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestRegionProposal17(t *testing.T) {
	w := campaignWar(t)
	w.Contracts[123] = 0
	r := campaignReq(w, 123, 10)
	r[0xa2] = 5
	r[0xa3] = 23
	if err := w.campaignRequest(10, make([]byte, 160), r); err != nil {
		t.Fatal(err)
	}
	b := w.World.Votes[123]
	if b.Region != 5 || b.Base != 23 || b.Weight != 1 {
		t.Fatal(b)
	}
	if err := w.campaignRequest(10, make([]byte, 160), r); err != nil {
		t.Fatal(err)
	}
	if len(w.World.Votes) != 1 {
		t.Fatal("retry duplicated ballot")
	}
	loaded, err := loadWar(w.path)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.World.Votes[123] != b {
		t.Fatal("proposal not preserved")
	}
	if root := os.Getenv("GK_REFRESH_CAPTURE_DIR"); root != "" {
		p := testProtocol(t)
		files, err := filepath.Glob(filepath.Join(root, "*20261005_03*_10.request.bin"))
		if err != nil || len(files) != 2 {
			t.Fatal(files, err)
		}
		for _, f := range files {
			frame, err := os.ReadFile(f)
			if err != nil {
				t.Fatal(err)
			}
			req, err := p.decode(frame, false)
			if err != nil {
				t.Fatal(err)
			}
			id := binary.LittleEndian.Uint32(req[0x24:])
			w.Contracts[id] = 0
			u32(req, 0x9c, w.wireID())
			if err := w.campaignRequest(10, make([]byte, 160), req); err != nil {
				t.Fatal(err)
			}
			if w.World.Votes[id].Base != 23 || w.World.Votes[id].Weight != 1 {
				t.Fatal("actual proposal discarded")
			}
		}
	}
}
func TestRoundRefresh17(t *testing.T) {
	w := campaignWar(t)
	r := campaignReq(w, 123, 10)
	w.Contracts[123] = 0
	p := testProtocol(t)
	out := filepath.Join("testdata", "refresh17")
	if err := os.MkdirAll(out, 0700); err != nil {
		t.Fatal(err)
	}
	write := func(label string) {
		for _, n := range []int{20, 21} {
			frame, err := os.ReadFile(filepath.Join("testdata", "campaign", fmt.Sprintf("%02d.response.bin", n)))
			if err != nil {
				t.Fatal(err)
			}
			plain, err := p.decode(frame, true)
			if err != nil {
				t.Fatal(err)
			}
			if n == 20 {
				w.fixed(plain)
			} else {
				w.now(plain)
			}
			frame, err = p.encode(plain)
			if err != nil {
				t.Fatal(err)
			}
			if err = os.WriteFile(filepath.Join(out, fmt.Sprintf("%s_%02d.response.bin", label, n)), frame, 0600); err != nil {
				t.Fatal(err)
			}
		}
	}
	write("initial")
	first := w.wireID()
	for _, delta := range []time.Duration{5 * time.Minute, 10 * time.Minute, 30 * time.Minute} {
		if err := w.advance(w.Start.Add(delta)); err != nil {
			t.Fatal(err)
		}
		now := w.wireID()
		if now == first || campaignNumber(now) != w.ID {
			t.Fatal("revision did not change")
		}
		fixed, dynamic := make([]byte, 496), make([]byte, 1152)
		w.fixed(fixed)
		w.now(dynamic)
		if binary.LittleEndian.Uint32(fixed[0x1c0:]) != now || binary.LittleEndian.Uint32(dynamic[0x44c:]) != now {
			t.Fatal("snapshot IDs differ")
		}
		for i := 0; i < 4; i++ {
			if fixed[0x14c+i*16+12] != dynamic[0x8c+i*0xf0+0xed] {
				t.Fatal("front regions differ")
			}
		}
		write(fmt.Sprintf("stage%d", delta/time.Minute))
		first = now
	}
	// A prior-campaign ballot must not pollute the new campaign.
	r[0xa2] = 5
	r[0xa3] = 23
	if err := w.campaignRequest(10, make([]byte, 160), r); err != nil {
		t.Fatal(err)
	}
	if len(w.World.Votes) != 0 {
		t.Fatal("expired campaign ballot accepted")
	}
}
