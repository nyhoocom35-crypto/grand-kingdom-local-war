package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	_ "embed"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"hash/crc32"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"
)

//go:embed schema.json
var schemaData []byte

const sourceHash = "c42a82599d4e82073175a3d20bf56f0546e3186dd3cdf1e1d4be9e747873093f"
const originalHost = "kx01-prd-9bnapb338aimcuzl.elasticbeanstalk.com"

type Endpoint struct {
	ID              int    `json:"id"`
	Name            string `json:"name"`
	Path            string `json:"path"`
	RequestFrame    int    `json:"request_frame"`
	ResponseFrame   int    `json:"response_frame"`
	RequestPadded   int    `json:"request_padded"`
	OperationCode   uint32 `json:"operation_code"`
	ResponseLogical int    `json:"response_logical"`
}
type Protocol struct{ tables []byte }

func (p *Protocol) params(response bool, i, k byte) ([]byte, []byte, error) {
	if len(p.tables) != 1280 || i >= 20 || k >= 20 {
		return nil, nil, errors.New("invalid cipher selectors")
	}
	off, ix, kx := 0, byte(0x3d), byte(0x92)
	if response {
		off, ix, kx = 640, 0x73, 0x1e
	}
	iv, key := make([]byte, 16), make([]byte, 16)
	for n := 0; n < 16; n++ {
		iv[n] = p.tables[off+int(i)*16+n] ^ ix
		key[n] = p.tables[off+320+int(k)*16+n] ^ kx
	}
	return key, iv, nil
}
func (p *Protocol) crypt(data []byte, response, encrypt bool, i, k byte) ([]byte, error) {
	if len(data) == 0 || len(data)%16 != 0 {
		return nil, errors.New("invalid AES block length")
	}
	key, iv, e := p.params(response, i, k)
	if e != nil {
		return nil, e
	}
	block, e := aes.NewCipher(key)
	if e != nil {
		return nil, e
	}
	out := make([]byte, len(data))
	if encrypt {
		cipher.NewCBCEncrypter(block, iv).CryptBlocks(out, data)
	} else {
		cipher.NewCBCDecrypter(block, iv).CryptBlocks(out, data)
	}
	return out, nil
}
func (p *Protocol) decode(frame []byte, response bool) ([]byte, error) {
	tail := 1236
	if response {
		tail = 900
	}
	n := len(frame) - tail
	if n <= 0 || n%16 != 0 {
		return nil, errors.New("invalid frame length")
	}
	t := frame[n:]
	if crc32.ChecksumIEEE(frame[:n+4]) != binary.LittleEndian.Uint32(t[4:]) || crc32.ChecksumIEEE(t[12:]) != binary.LittleEndian.Uint32(t[8:]) {
		return nil, errors.New("CRC mismatch")
	}
	return p.crypt(frame[:n], response, false, t[0], t[1])
}
func (p *Protocol) encode(data []byte) ([]byte, error) {
	body, e := p.crypt(data, true, true, 0, 0)
	if e != nil {
		return nil, e
	}
	frame := make([]byte, len(body)+900)
	copy(frame, body)
	n := len(body)
	binary.LittleEndian.PutUint32(frame[n+4:], crc32.ChecksumIEEE(frame[:n+4]))
	binary.LittleEndian.PutUint32(frame[n+8:], crc32.ChecksumIEEE(frame[n+12:]))
	return frame, nil
}
func atomicWrite(path string, data []byte) error {
	f, e := os.CreateTemp(filepath.Dir(path), ".gk-write-")
	if e != nil {
		return e
	}
	name := f.Name()
	defer os.Remove(name)
	if e = f.Chmod(0600); e == nil {
		_, e = f.Write(data)
	}
	if e == nil {
		e = f.Sync()
	}
	c := f.Close()
	if e == nil {
		e = c
	}
	if e != nil {
		return e
	}
	return os.Rename(name, path)
}
func prepare(source, target, root string) error {
	b, e := os.ReadFile(source)
	if e != nil {
		return e
	}
	digest := sha256.Sum256(b)
	if hex.EncodeToString(digest[:]) != sourceHash {
		return errors.New("decrypted SELF does not match analyzed Japanese 1.06 version")
	}
	if string(b[0x46d180:0x46d180+len(originalHost)]) != originalHost {
		return errors.New("host offset does not match")
	}
	tables := make([]byte, 0, 1280)
	for _, va := range []int{0x8146bb80, 0x8146bcc0, 0x8146be00, 0x8146bf40} {
		off := va - 0x81000000 + 0x10e0
		tables = append(tables, b[off:off+320]...)
	}
	for n := 0; n < len(originalHost); n++ {
		b[0x46d180+n] = 0
	}
	copy(b[0x46d180:], "127.0.0.1")
	if e = atomicWrite(filepath.Join(root, "protocol.dat"), tables); e != nil {
		return e
	}
	return atomicWrite(target, b)
}

type User struct {
	ID       uint32 `json:"id"`
	Revision byte   `json:"revision"`
	Token    string `json:"token"`
	Session  string `json:"session"`
}
type Users struct {
	mu   sync.Mutex
	path string
	Data map[string]User
}

func loadUsers(path string) (*Users, error) {
	u := &Users{path: path, Data: map[string]User{}}
	b, e := os.ReadFile(path)
	if os.IsNotExist(e) {
		return u, nil
	}
	if e != nil {
		return nil, e
	}
	e = json.Unmarshal(b, &u.Data)
	return u, e
}
func token(label string, id uint32) string {
	d := sha256.Sum256([]byte(fmt.Sprintf("GK-LOCAL-04:%s:%d", label, id)))
	return hex.EncodeToString(d[:])[:40]
}
func (u *Users) ensure(name string, requested uint32, revision byte) (User, error) {
	u.mu.Lock()
	defer u.mu.Unlock()
	if v, ok := u.Data[name]; ok {
		if requested != 0 && v.ID != requested {
			return User{}, errors.New("local player ID differs; preserve state and investigate")
		}
		return v, nil
	}
	id := requested
	if id == 0 {
		h := sha256.Sum256([]byte(name))
		id = 1000000 + binary.LittleEndian.Uint32(h[:4])%1000000000
	}
	for n, v := range u.Data {
		if v.ID == id && n != name {
			return User{}, errors.New("player ID collision")
		}
	}
	v := User{ID: id, Revision: revision, Token: token("identity", id), Session: token("session", id)}
	u.Data[name] = v
	b, e := json.MarshalIndent(u.Data, "", "  ")
	if e == nil {
		e = atomicWrite(u.path, b)
	}
	if e != nil {
		delete(u.Data, name)
	}
	return v, e
}

type Backend struct {
	p          *Protocol
	users      *Users
	endpoints  map[string]Endpoint
	log        *log.Logger
	captureDir string
	war        *War
}

func (b *Backend) response(ep Endpoint, req []byte) ([]byte, string, error) {
	if len(req) != ep.RequestPadded || binary.LittleEndian.Uint32(req[4:]) != 0x3130786b || binary.LittleEndian.Uint32(req[8:]) != ep.OperationCode || int(binary.LittleEndian.Uint32(req[12:])) != ep.ResponseLogical {
		return nil, "", errors.New("request schema mismatch")
	}
	plain := make([]byte, ep.ResponseFrame-900)
	copy(plain, "@suc")
	status := "OK"
	switch ep.ID {
	case 0: // Empty optional redirect is explicitly permitted by Being validator.
	case 5, 6: // Original fill generates 1024 random bytes; apply is a no-op and validator always succeeds.
		// These are stateless auxiliary probes, including the probe before weapon-placement voting.
	case 1, 2:
		name := string(bytes.SplitN(req[0x10:0x21], []byte{0}, 2)[0])
		if name == "" {
			return nil, "", errors.New("empty local player name")
		}
		v, e := b.users.ensure(name, binary.LittleEndian.Uint32(req[0x24:]), req[0x23])
		if e != nil {
			return nil, "", e
		}
		inner := func(text string) ([]byte, error) {
			payload := bytes.Repeat([]byte{'-'}, 48)
			copy(payload, text)
			return b.p.crypt(payload, true, true, 0, 0)
		}
		session, e := inner(v.Session)
		if e != nil {
			return nil, "", e
		}
		if ep.ID == 1 {
			binary.LittleEndian.PutUint32(plain[0x8c:], v.ID)
			plain[0x90] = v.Revision
			identity, e := inner(v.Token)
			if e != nil {
				return nil, "", e
			}
			copy(plain[0x94:], identity)
			copy(plain[0xc4:], session)
			putDate(plain[0xfc:], time.Now().UTC())
		} else {
			plain[0x8c] = 0
			copy(plain[0x90:], session)
		}
	case 7, 35, 36, 38, 42:
		if b.war == nil {
			return nil, "", errors.New("war unavailable")
		}
		if e := b.war.companyRequest(ep.ID, plain, req, time.Now().UTC()); e != nil {
			return nil, "", e
		}
	case 9: // Rank colors are client-maintained cosmetic values; no server XP award.
	case 10, 11, 33, 34:
		if b.war == nil {
			return nil, "", errors.New("war unavailable")
		}
		if e := b.war.campaignRequest(ep.ID, plain, req); e != nil {
			return nil, "", e
		}
	case 43, 44:
		if b.war == nil {
			return nil, "", errors.New("war unavailable")
		}
		b.war.ranking(plain, req, ep.ID)
	case 12:
		if b.war == nil {
			return nil, "", errors.New("war state unavailable")
		}
		if req[0x9c] > 3 {
			return nil, "", errors.New("invalid barrack country")
		}
		b.war.barrackCountry(plain, int(req[0x9c]))
	case 22:
		if b.war == nil {
			return nil, "", errors.New("war state unavailable")
		}
		b.war.results(plain, req)
	case 13:
		if b.war == nil {
			return nil, "", errors.New("war state unavailable")
		}
		country := req[0x9c]
		if e := b.war.rememberContract(binary.LittleEndian.Uint32(req[0x24:]), country); e != nil {
			return nil, "", e
		}
		if country < 4 {
			b.war.mu.Lock()
			binary.LittleEndian.PutUint32(plain[0x8c:], 0x40000000|((b.war.ID+max(uint32(1), uint32(req[0x9d])))<<3))
			b.war.mu.Unlock()
		}
	case 14:
		if b.war == nil {
			return nil, "", errors.New("war state unavailable")
		}
		b.war.contractStatus(plain)
	case 20:
		if b.war == nil {
			return nil, "", errors.New("war state unavailable")
		}
		b.war.fixed(plain)
	case 21:
		if b.war == nil {
			return nil, "", errors.New("war state unavailable")
		}
		plain = append(plain, make([]byte, 496)...)
		copy(plain[1152:], "@suc")
		if err := b.war.snapshot22(plain); err != nil {
			return nil, "", err
		}
	case 23, 24, 25, 28, 29, 31:
		if b.war == nil {
			return nil, "", errors.New("war state unavailable")
		}
		var ok bool
		var err error
		switch ep.ID {
		case 23:
			ok, err = b.war.enter(plain, req)
		case 24:
			ok, err = b.war.strategyData(plain, req)
		case 25:
			ok, err = b.war.move(req)
		case 28:
			ok, err = b.war.place(req)
		case 29:
			ok, err = b.war.beginStrategy(plain, req)
		case 31:
			ok, err = b.war.registerOrder25(plain, req)
		}
		if err != nil {
			return nil, "", err
		}
		if !ok {
			copy(plain, "@err")
			u32(plain, 4, 60000)
			status = "INVALID_STRATEGY"
		} else if ep.ID == 24 {
			plain = append(plain, make([]byte, 1648)...)
			copy(plain[1712:], "@suc")
			copy(plain[1712+1152:], "@suc")
			if err := b.war.snapshot22(plain[1712:]); err != nil {
				return nil, "", err
			}
		}
	case 26: // No other local online allies; original response permits empty slots.
	case 37:
		if b.war == nil || !b.war.rivals46(plain, req) {
			return nil, "", errors.New("invalid rival nation or response")
		}

	case 40: // Local social directory: 100 following IDs and 100 follower IDs, all absent.
		// Original apply explicitly marks zero IDs as resolved empty slots.
		// This read-only response does not create votes, allies or enemy troops.

	default:
		copy(plain, "@err")
		binary.LittleEndian.PutUint32(plain[4:], 60000)
		status = "NOT_IMPLEMENTED"
	}
	frame, e := b.p.encode(plain)
	return frame, status, e
}
func putDate(dst []byte, t time.Time) {
	for n, v := range []int{t.Year(), int(t.Month()), t.Day(), t.Hour(), t.Minute(), t.Second()} {
		binary.LittleEndian.PutUint16(dst[n*2:], uint16(v))
	}
}
func (b *Backend) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if b.statusHTTP(w, r) {
		return
	}
	if r.Method != "POST" {
		http.Error(w, "POST required", 405)
		return
	}
	ep, ok := b.endpoints[r.URL.Path]
	if !ok {
		http.NotFound(w, r)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, 128*1024)
	body, e := io.ReadAll(r.Body)
	if e != nil {
		http.Error(w, "Invalid body", 400)
		return
	}
	if len(body) != ep.RequestFrame {
		b.log.Printf("%s INVALID_LENGTH got=%d expected=%d", ep.Name, len(body), ep.RequestFrame)
		http.Error(w, "Invalid length", 400)
		return
	}
	plain, e := b.p.decode(body, false)
	if e != nil {
		b.log.Printf("%s INVALID_FRAME %v", ep.Name, e)
		http.Error(w, "Invalid frame", 400)
		return
	}
	if b.war != nil && (ep.ID == 14 || ep.ID == 20 || ep.ID == 21 || ep.ID == 24) {
		if e = b.war.advance(time.Now().UTC()); e != nil {
			b.log.Printf("CURRENT CAMPAIGN ERROR %v", e)
			http.Error(w, "Current war state unavailable", 500)
			return
		}
	}
	stamp := fmt.Sprintf("%s_%02d", time.Now().Format("20060102_150405.000000000"), ep.ID)
	if e = atomicWrite(filepath.Join(b.captureDir, stamp+".request.bin"), body); e != nil {
		b.log.Printf("capture failed: %v", e)
	}
	frame, status, e := b.response(ep, plain)
	if e != nil {
		b.log.Printf("%s ERROR %v", ep.Name, e)
		http.Error(w, "Local response unavailable", 500)
		return
	}
	if e = atomicWrite(filepath.Join(b.captureDir, stamp+".response.bin"), frame); e != nil {
		b.log.Printf("capture failed: %v", e)
	}
	b.log.Printf("%s %s request=%d response=%d", ep.Name, status, len(body), len(frame))
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Connection", "close")
	w.Header().Set("Content-Length", fmt.Sprint(len(frame)))
	w.WriteHeader(200)
	_, _ = w.Write(frame)
}
func run(root string, port int) error {
	data, e := os.ReadFile(filepath.Join(root, "protocol.dat"))
	if e != nil {
		return errors.New("put GK_Server_29.exe inside the existing installed GK_Local_Login_Test_04 folder (protocol.dat missing)")
	}
	if len(data) != 1280 {
		return errors.New("invalid protocol.dat")
	}
	users, e := loadUsers(filepath.Join(root, "local-users.json"))
	if e != nil {
		return e
	}
	capture := filepath.Join(root, "captures")
	if e = os.MkdirAll(capture, 0700); e != nil {
		return e
	}
	f, e := os.OpenFile(filepath.Join(root, "server.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	logger := log.New(io.MultiWriter(os.Stdout, f), "", log.LstdFlags)
	var eps []Endpoint
	if e = json.Unmarshal(schemaData, &eps); e != nil {
		return e
	}
	ln, e := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", port))
	if e != nil {
		return fmt.Errorf("cannot listen on 127.0.0.1:80; another program may use port 80: %w", e)
	}
	defer ln.Close()
	war, e := loadWar(filepath.Join(root, "war-state.json"))
	if e != nil {
		return e
	}
	if e = war.enableCampaign(time.Now().UTC()); e != nil {
		return e
	}
	if e = war.enableContracts26(); e != nil {
		return e
	}
	if e = war.advance(time.Now().UTC()); e != nil {
		return e
	}
	stop := make(chan struct{})
	defer close(stop)
	go func() {
		ticker := time.NewTicker(15 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case now := <-ticker.C:
				if err := war.advance(now.UTC()); err != nil {
					logger.Printf("CAMPAIGN SAVE ERROR %v", err)
				} else {
					war.mu.Lock()
					logger.Printf("CAMPAIGN id=%d round=%d/6 remaining=%ds owners=%v", war.ID, war.World.Round+1, int(time.Until(war.End).Seconds()), war.World.Owners)
					war.mu.Unlock()
				}
			case <-stop:
				return
			}
		}
	}()
	b := &Backend{war: war, p: &Protocol{tables: data}, users: users, endpoints: map[string]Endpoint{}, log: logger, captureDir: capture}
	for _, ep := range eps {
		b.endpoints[ep.Path] = ep
	}

	logger.Println("Grand Kingdom campaign server 29; client 28; empty-vote reconnect fix; all-map AI ballots enabled")
	logger.Printf("Dispatch 35: one battle per minute, up to %d battles per deployment", dispatchLimit)
	logger.Println("Orders 36: one strategy-order activation per side, maximum two per battlefield")
	logger.Println("Finish 37: normal operation completion before campaign rollover; delayed settlement retained")
	logger.Println("Research 39 / Siege 40: one-time four-country research reset; category research and national shop synchronized; structures destroyed after five victories")
	logger.Println("Vote transition 44: advertised deadlines retained across rounds and saved with campaign state")
	logger.Println("Shop 43: snapshot-hook relocation corrected; writable shop state; client47 required; existing category research preserved")
	logger.Println("Rivals 47: mixed AI/NPC enemy pools; original NPC active skills for all 17 classes; varied flags/pieces; original cosmetic drop rules")
	logger.Println("HUD 47 / Secret 46: frame-updated alive structure count and HP gauge; secret reward IDs populated; ordinary battle rewards unchanged")
	logger.Println("Battle / Rank / Contract 45: stage wins damage structures; actual rank populations and grades; campaign-count contracts")
	logger.Printf("READY 127.0.0.1:%d - keep this window open, then start Vita3K", port)
	logger.Println("AI campaign simulation, native votes and rankings enabled. Ctrl+C stops the server.")
	s := &http.Server{Handler: b, ReadHeaderTimeout: 10 * time.Second, ReadTimeout: 20 * time.Second, WriteTimeout: 20 * time.Second, MaxHeaderBytes: 16 * 1024}
	return s.Serve(ln)
}
func selfTest() error {
	k, _ := hex.DecodeString("2b7e151628aed2a6abf7158809cf4f3c")
	iv, _ := hex.DecodeString("000102030405060708090a0b0c0d0e0f")
	in, _ := hex.DecodeString("6bc1bee22e409f96e93d7e117393172a")
	want, _ := hex.DecodeString("7649abac8119b246cee98e9b12e9197d")
	block, e := aes.NewCipher(k)
	if e != nil {
		return e
	}
	out := make([]byte, 16)
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(out, in)
	if !bytes.Equal(out, want) {
		return errors.New("AES self-test failed")
	}
	if crc32.ChecksumIEEE([]byte("123456789")) != 0xcbf43926 {
		return errors.New("CRC self-test failed")
	}
	fmt.Println("SELFTEST OK")
	return nil
}
func main() {
	exe, e := os.Executable()
	if e != nil {
		fmt.Println(e)
		os.Exit(1)
	}
	root := filepath.Dir(exe)
	if len(os.Args) == 4 && os.Args[1] == "--prepare" {
		e = prepare(os.Args[2], os.Args[3], root)
	} else if len(os.Args) == 2 && os.Args[1] == "--selftest" {
		e = selfTest()
	} else if len(os.Args) == 2 && os.Args[1] == "--enable-campaign" {
		var w *War
		w, e = loadWar(filepath.Join(root, "war-state.json"))
		if e == nil {
			e = w.enableCampaign(time.Now().UTC())
		}
		if e == nil {
			fmt.Println("CAMPAIGN 15 ENABLED: 30 minutes; existing contracts retained")
		}
	} else if len(os.Args) == 2 && os.Args[1] == "--renew-operation" {
		e = renewOperation(root)
	} else if len(os.Args) == 1 {
		e = run(root, 80)
	} else {
		e = errors.New("usage: GK_Server.exe [--prepare SOURCE TARGET | --selftest | --renew-operation]")
	}
	if e != nil {
		fmt.Println("ERROR:", e)
		os.Exit(1)
	}
}
