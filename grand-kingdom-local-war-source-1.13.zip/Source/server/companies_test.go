package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func request16(t *testing.T, api int) (Endpoint, []byte) {
	t.Helper()
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	ep := eps[api]
	r := make([]byte, ep.RequestPadded)
	u32(r, 4, 0x3130786b)
	u32(r, 8, ep.OperationCode)
	u32(r, 12, uint32(ep.ResponseLogical))
	u32(r, 0x24, 123)
	copy(r[0x10:], "LOCAL_PLAYER")
	return ep, r
}
func TestCompanyDispatchPersistenceAndRetry(t *testing.T) {
	w := campaignWar(t)
	now := w.Start
	_, req := request16(t, 35)
	req[0xa4] = 2
	req[0x9d] = 1
	c, _ := aiCompany(0xf0000000)
	copy(req[0xa8:], generatedTroop(c, 0xf0000000))
	d := make([]byte, 1456)
	if e := w.companyRequest(35, d, req, now); e != nil {
		t.Fatal(e)
	}
	if d[0x8c] != 1 || d[0x8d] != dispatchLimit {
		t.Fatal("native dispatch limits")
	}
	if e := w.companyRequest(35, d, req, now.Add(30*time.Second)); e != nil {
		t.Fatal(e)
	}
	if !w.Dispatches[123][0].Started.Equal(now) {
		t.Fatal("retry reset deployment")
	}
	_, counts := request16(t, 38)
	if e := w.companyRequest(38, d, counts, now.Add(4*time.Minute)); e != nil {
		t.Fatal(e)
	}
	if d[0x8c] != 4 {
		t.Fatal("missing elapsed battles", d[0x8c])
	}
	saved, e := loadWar(w.path)
	if e != nil {
		t.Fatal(e)
	}
	if saved.Dispatches[123][0].Battles != 4 {
		t.Fatal("dispatch persistence")
	}
	before := saved.World.Fronts
	if e := saved.companyRequest(38, d, counts, now.Add(4*time.Minute)); e != nil {
		t.Fatal(e)
	}
	if saved.World.Fronts != before {
		t.Fatal("same poll awarded influence twice")
	}
	_, ret := request16(t, 36)
	if e := saved.companyRequest(36, d, ret, now.Add(6*time.Minute)); e != nil {
		t.Fatal(e)
	}
	if d[0x8d] != 6 || binary.LittleEndian.Uint32(d[0x94:]) == 0 || !saved.Dispatches[123][0].Returned {
		t.Fatal("return payload")
	}
	returnedPayload := append([]byte(nil), d[0x8c:0x5b0]...)
	clear(d)
	if e := saved.companyRequest(36, d, ret, now.Add(6*time.Minute)); e != nil {
		t.Fatal(e)
	}
	if !bytes.Equal(returnedPayload, d[0x8c:0x5b0]) {
		t.Fatal("return retry changed payload")
	}
	before = saved.World.Fronts
	if e := saved.companyRequest(38, d, counts, now.Add(time.Hour)); e != nil {
		t.Fatal(e)
	}
	if before != saved.World.Fronts {
		t.Fatal("returned troop fought again")
	}
	if e := saved.companyRequest(35, d, req, now.Add(time.Hour)); e != nil {
		t.Fatal(e)
	}
	if !saved.Dispatches[123][0].Started.Equal(now.Add(time.Hour)) {
		t.Fatal("redispatch blocked")
	}
}
func TestCompaniesAllDifferentAndNumericVotes(t *testing.T) {
	w := campaignWar(t)
	names, comments := map[string]bool{}, map[string]bool{}
	for nation := 0; nation < 4; nation++ {
		for i := 0; i < 6; i++ {
			id := uint32(0xf0000000 + nation*100 + i)
			c, ok := w.company(id)
			if !ok || names[c.Name] || comments[c.Description] {
				t.Fatal("duplicate AI profile")
			}
			names[c.Name] = true
			comments[c.Description] = true
		}
	}
	votes := w.voteCounts()
	v := votes[0]
	w.World.Votes[123] = Ballot{v.Region, v.Base, v.Country, 17}
	rows := w.voteCounts()
	found := false
	for _, r := range rows {
		if r.Region == v.Region && r.Base == v.Base && r.Country == v.Country {
			found = true
			if r.Player != 17 || r.Total != r.AI+17 {
				t.Fatal("numeric tally does not match selection")
			}
		}
	}
	if !found {
		t.Fatal("missing voted candidate")
	}
	b := &Backend{war: w}
	r := httptest.NewRequest("GET", "/status.json", nil)
	rr := httptest.NewRecorder()
	b.ServeHTTP(rr, r)
	if rr.Code != 200 || !strings.Contains(rr.Body.String(), "\"player\":17") {
		t.Fatal("status tally", rr.Code)
	}
}
func TestRegression16ActualFailuresAndNativeFixtures(t *testing.T) {
	p := testProtocol(t)
	w := campaignWar(t)
	b := &Backend{p: p, war: w}
	fixture := func(api int, label string, req []byte) {
		t.Helper()
		ep, _ := request16(t, api)
		frame, status, e := b.response(ep, req)
		if e != nil || status != "OK" {
			t.Fatal(api, status, e)
		}
		if len(frame) != ep.ResponseFrame+map[int]int{21: 496, 24: 1648}[api] {
			t.Fatal("frame length", api)
		}
		if e = os.MkdirAll("testdata/company16", 0700); e != nil {
			t.Fatal(e)
		}
		if e = os.WriteFile(filepath.Join("testdata/company16", label+".response.bin"), frame, 0600); e != nil {
			t.Fatal(e)
		}
	}
	for _, api := range []int{7, 35, 38, 36, 42} {
		_, r := request16(t, api)
		switch api {
		case 7:
			copy(r[0x9c:], "Local Company")
			copy(r[0xb4:], "Local Motto")
			copy(r[0xcc:], "Local Details")
		case 35:
			r[0x9d] = 1
			c, _ := aiCompany(0xf0000000)
			copy(r[0xa8:], generatedTroop(c, 0xf0000000))
			r[0xa4] = 2
		case 36:
			w.Dispatches[123][0].Started = time.Now().Add(-4 * time.Minute)
			w.Dispatches[123][0].Last = w.Dispatches[123][0].Started
		case 42:
			u32(r, 0x9c, 0xf0000000)
		}
		fixture(api, jsonNumber(api), r)
	}
	for n := 0; n < 4; n++ {
		for i := 0; i < 6; i++ {
			_, r := request16(t, 42)
			u32(r, 0x9c, uint32(0xf0000000+n*100+i))
			fixture(42, "42_ai_"+jsonNumber(n*6+i), r)
		}
	}
	if e := w.advance(w.Start.Add(4 * time.Minute)); e != nil {
		t.Fatal(e)
	}
	_, r := request16(t, 21)
	fixture(21, "21_advanced", r)
	if root := os.Getenv("GK_COMPANY_CAPTURE_DIR"); root != "" {
		files, e := os.ReadDir(root)
		if e != nil {
			t.Fatal(e)
		}
		seen := map[int]int{}
		for _, f := range files {
			for _, api := range []int{35, 42, 21} {
				if !strings.HasSuffix(f.Name(), "_"+jsonNumber(api)+".request.bin") {
					continue
				}
				raw, e := os.ReadFile(filepath.Join(root, f.Name()))
				if e != nil {
					t.Fatal(e)
				}
				req, e := p.decode(raw, false)
				if e != nil {
					t.Fatal(e)
				}
				ep, _ := request16(t, api)
				frame, status, e := b.response(ep, req)
				if e != nil || status != "OK" || len(frame) != ep.ResponseFrame+map[int]int{21: 496, 24: 1648}[api] {
					t.Fatal("actual failed request", api, status, e)
				}
				seen[api]++
			}
		}
		for _, api := range []int{35, 42, 21} {
			if seen[api] == 0 {
				t.Fatal("actual request missing", api)
			}
		}
	}
}
func jsonNumber(n int) string { return fmt.Sprintf("%02d", n) }

func TestCompanyWriteFailureRollback(t *testing.T) {
	w := campaignWar(t)
	_, r := request16(t, 7)
	copy(r[0x9c:], "Changed")
	before, _ := json.Marshal(w)
	w.path = filepath.Join(t.TempDir(), "missing", "state.json")
	if w.companyRequest(7, make([]byte, 144), r, w.Start) == nil {
		t.Fatal("save failure hidden")
	}
	after, _ := json.Marshal(w)
	if !bytes.Equal(before, after) {
		t.Fatal("profile failure changed state")
	}
}
