package main

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestContracts26PopulationTerritoriesRestartAndRollover(t *testing.T) {
	w := campaignWar(t)
	if err := w.enableContracts26(); err != nil {
		t.Fatal(err)
	}
	start := w.Start
	// Three real companies: two renew/change country, one is not contracted.
	for _, v := range []struct {
		id      uint32
		country byte
	}{{111, 0}, {222, 2}, {333, 4}, {111, 3}, {111, 3}} {
		if err := w.rememberContract(v.id, v.country); err != nil {
			t.Fatal(err)
		}
	}
	changed := false
	var previous [4]uint32
	for _, minutes := range []int{0, 2, 5, 17, 29, 30, 35} {
		if err := w.advance(start.Add(time.Duration(minutes) * time.Minute)); err != nil {
			t.Fatal(err)
		}
		if err := w.validateContracts26(); err != nil {
			t.Fatal(minutes, err)
		}
		rows := w.contractNations26()
		var ai, player, territory, combat uint32
		var percent float64
		for country, r := range rows {
			ai += r.AI
			player += r.Player
			territory += r.Territories
			combat += r.CombatTerritories
			percent += r.Percent
			if r.AI < 2 || r.Total != r.AI+r.Player {
				t.Fatal("empty or artificial AI population", r)
			}
			if minutes > 0 && r.AI != previous[country] {
				changed = true
			}
			previous[country] = r.AI
		}
		if ai != 24 || player != 2 || territory != 16 || combat != 12 || percent < 99.9999 || percent > 100.0001 {
			t.Fatal("totals", rows)
		}
		fixed, status := make([]byte, 496), make([]byte, 656)
		w.fixed(fixed)
		w.contractStatus(status)
		for country, r := range rows {
			if binary.LittleEndian.Uint32(fixed[0x8c+country*0x30+0x2c:]) != r.Territories || binary.LittleEndian.Uint32(status[0x90+country*4:]) != r.Total {
				t.Fatal("contract screen differs from current world", country, r)
			}
		}
		for id, a := range w.AIContracts26 {
			c, ok := w.company(id)
			if !ok || c.Description != fmt.Sprintf("%s contracted to nation %d. %s.", c.Name, a.Country+1, c.Motto) {
				t.Fatal("company contract differs", id)
			}
		}
		before, _ := json.Marshal(w)
		loaded, err := loadWar(w.path)
		if err != nil {
			t.Fatal(err)
		}
		if err = loaded.enableContracts26(); err != nil {
			t.Fatal(err)
		}
		after, _ := json.Marshal(loaded)
		if string(before) != string(after) {
			t.Fatal("restart reassigns contracts")
		}
	}
	if !changed {
		t.Fatal("AI contract population never changes")
	}
}

func TestContracts26MigrationRollbackAndNativeFrames(t *testing.T) {
	w := campaignWar(t)
	if err := w.advance(w.Start.Add(4 * time.Minute)); err != nil {
		t.Fatal(err)
	}
	// Model a saved server25 state without the new contract metadata.
	w.AIContracts26 = nil
	if err := w.save(); err != nil {
		t.Fatal(err)
	}
	oldID, oldRound, oldOwners := w.ID, w.World.Round, w.World.Owners
	if err := w.enableContracts26(); err != nil {
		t.Fatal(err)
	}
	if w.ID != oldID || w.World.Round != oldRound || w.World.Owners != oldOwners {
		t.Fatal("migration resets campaign")
	}
	before, _ := json.Marshal(w)
	oldPath := w.path
	w.path = filepath.Join(t.TempDir(), "missing", "state.json")
	// atomicWrite creates directories; use an existing directory as a file.
	w.path = t.TempDir()
	if err := w.advance(w.Start.Add(5 * time.Minute)); err == nil {
		t.Fatal("failed save accepted")
	}
	w.path = oldPath
	after, _ := json.Marshal(w)
	if string(before) != string(after) {
		t.Fatal("failed save altered AI contracts")
	}
	p := testProtocol(t)
	var eps []Endpoint
	json.Unmarshal(schemaData, &eps)
	b := &Backend{p: p, war: w}
	out := "testdata/contracts26"
	os.MkdirAll(out, 0700)
	for sample := 0; sample < 8; sample++ {
		if err := w.advance(w.Start.Add(time.Duration(5+sample*3) * time.Minute)); err != nil {
			t.Fatal(err)
		}
		// Deliberate ownership changes ensure all screen counts follow the map,
		// rather than accidentally passing against the initial 4/4/4/4 state.
		for r := 0; r < 16; r++ {
			if combatRegion(byte(r)) {
				w.World.Owners[r] = byte((r + sample) % 4)
				for j := 0; j < 7; j++ {
					w.World.BaseOwners[r][j] = w.World.Owners[r]
				}
			}
		}
		for r := 0; r < sample%4; r++ {
			w.World.Owners[r] = 0
			for j := 0; j < 7; j++ {
				w.World.BaseOwners[r][j] = 0
			}
		}
		if err := w.rememberContract(123, byte(sample%4)); err != nil {
			t.Fatal(err)
		}
		for _, api := range []int{14, 20, 21} {
			req := make([]byte, eps[api].RequestPadded)
			u32(req, 4, 0x3130786b)
			u32(req, 8, eps[api].OperationCode)
			u32(req, 12, uint32(eps[api].ResponseLogical))
			frame, status, err := b.response(eps[api], req)
			if err != nil || status != "OK" {
				t.Fatal(api, status, err)
			}
			if err = os.WriteFile(filepath.Join(out, fmt.Sprintf("sample_%02d_%d.response.bin", sample, api)), frame, 0600); err != nil {
				t.Fatal(err)
			}
		}
		rows, _ := json.Marshal(w.contractNations26())
		os.WriteFile(filepath.Join(out, fmt.Sprintf("sample_%02d.json", sample)), rows, 0600)
	}
}
