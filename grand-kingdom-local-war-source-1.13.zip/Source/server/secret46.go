package main

// Original COUNTRYREWARDPARAMETER reward IDs for its thirteen weapon rewards.
// The native save still enforces WARBONUSPARAMETER's ten-repulsion threshold,
// metric requirements, contract nation, collection and inventory ownership.
// Supplying -1 in all three API20 reward slots made the scrolls empty forever.
var secretItems46 = [...]uint32{20032, 20130, 20315, 20426, 20520, 20620, 20727, 20829, 20928, 21121, 21332, 21420, 21527}

func (w *War) secretReward46(front, slot int) uint32 {
	region := regions[front]
	if w.World != nil {
		region = w.World.Fronts[front].Region
	}
	return secretItems46[(uint64(w.ID)+uint64(region)*3+uint64(slot))%uint64(len(secretItems46))]
}
