"""Replay the real native troop decoder and cosmetic loot builder.
Usage: verify_rivals47.py SELF CLIENT47_FIXTURES OWNER_PARAMETER_DIRECTORY
The byte-stream interface, heap and RNG are modeled. Skill, appearance, loot,
victory collection and cosmetic inventory writes execute natively. Inventory
ownership is modeled only for the RNG cases, not for the 78 save-award cases.
"""
import json,struct,sys
from pathlib import Path
from native_replay46 import *

binary=Path(sys.argv[1]).read_bytes();fixtures=Path(sys.argv[2]);params=Path(sys.argv[3])
u=machine(binary)
P=0x2900000;OBJ=0x2800000;OUT=0x2810000;PARTY=0x2820000;VT=0x2830000
def table(ptr, rows):
    u.mem_write(ptr,b''.join(rows));return len(rows)
items=(params/'ITEMPARAMETER.DAT').read_bytes()
special=[]
for item in list(range(70100,70180))+list(range(70300,70321)):
    at=items.find(struct.pack('<III',item,item,item));assert at>=0,item
    special.append(items[at:at+12]+bytes(8)+items[at+12:at+28])
put(u,MGR+8,P);put(u,P+0x50,P+0x1000);put(u,P+0x54,table(P+0x1000,special))
weapons=[]
for item in (20000,20500,21500,20400,20100,20300,20700,20800,20900,21100,20600):
    at=items.find(struct.pack('<III',item,item,item));assert at>=0,item
    weapons.append(items[at:at+12]+bytes(0x94-12))
put(u,P+0x18,P+0xb000);put(u,P+0x1c,table(P+0xb000,weapons))

for key,filename,width,offset in [(0xc,'PAWNPARAMETER.DAT',20,0x2000),(0x10,'FLAGPARAMETER.DAT',16,0x3000)]:
    raw=(params/filename).read_bytes();count=struct.unpack_from('<I',raw,32)[0]
    put(u,MGR+key,P+offset);put(u,P+offset,P+offset+0x100);put(u,P+offset+4,count)
    u.mem_write(P+offset+0x100,raw[36:36+count*width])
# UNITEDIT file rows are expanded by the original loader with reserved tail words.
edit=(params/'UNITEDIT.DAT').read_bytes();put(u,MGR+0x20,P+0x4000)
for field,countfield,at,n,inwidth,outwidth,target in [
    (8,0x84,176,612,8,8,0x5000),(0x88,0x8c,5076,9,8,12,0x7000),
    (0x90,0x94,5152,12,8,16,0x7100),(0x98,0x9c,5252,300,24,28,0x8000)]:
    rows=[edit[at+i*inwidth:at+(i+1)*inwidth]+bytes(outwidth-inwidth)for i in range(n)]
    if inwidth==24:rows=[r[:12]+bytes(4)+r[12:24]for r in rows]
    put(u,P+0x4000+field,P+target);put(u,P+0x4000+countfield,table(P+target,rows))
put(u,OBJ,VT)
methods={0x2f00000:1,0x2f00004:2,0x2f00008:4}
for field,addr in zip((0x40,0x44,0x48),methods):put(u,VT+field,addr|1)
random_value=0;owned=set();checks=0; native_ownership=False
def hook(u,pc):
    global checks
    if pc in methods:
        r0,r1=u.reg_read(UC_ARM_REG_R0),u.reg_read(UC_ARM_REG_R1)
        n=methods[pc];at=get(u,r0+0x18);src=get(u,r0+4)
        u.mem_write(r1,bytes(u.mem_read(src+at,n)));put(u,r0+0x18,at+n);returning(u,1)
    elif pc==0x810592f2:returning(u,0)
    elif pc==0x81073e04:returning(u)
    elif pc==0x810985ae:
        a,b,n=[u.reg_read(r)for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
        u.mem_write(a,bytes(u.mem_read(b,min(n,0x48)))+bytes(max(0,n-0x48)));returning(u,a)
    elif pc in (0x810472a4,0x810472ac,0x814124f0):
        a,b,n=[u.reg_read(r)for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
        u.mem_write(a,bytes(u.mem_read(b,n)));returning(u,a)
    elif pc==0x810472be:
        a,n=u.reg_read(UC_ARM_REG_R0),u.reg_read(UC_ARM_REG_R1);u.mem_write(a,bytes(n));returning(u,a)
    elif pc==0x8108dcfc and not native_ownership:returning(u,int(u.reg_read(UC_ARM_REG_R1)in owned))
    elif pc==0x81047cb6:returning(u,random_value)
skills=(params/'SKILLPARAMETER.DAT').read_bytes();skilln=struct.unpack_from('<I',skills,32)[0]
put(u,MGR+4,P+0xd000);put(u,P+0xd030,P+0xe000);put(u,P+0xd034,skilln)
u.mem_write(P+0xe000,skills[36:36+skilln*112])
skillids={struct.unpack_from('<I',skills,36+i*112)[0]for i in range(skilln)}
report=dict(native_troop_decodes=0,native_runtime_skill_slots=0,native_cosmetic_drops=0,actual_vita3k_verified=False)
for path in sorted(fixtures.glob('nation*.plain')):
    raw=path.read_bytes()
    for i in range(30):
        at=0x8c+i*0x518
        if not struct.unpack_from('<I',raw,at)[0]:continue
        troop=raw[at+24:at+24+1084];u.mem_write(INPUT,troop)
        put(u,OBJ+4,INPUT);put(u,OBJ+0x18,0)
        result=run(u,0x8106af22,[OBJ,OUT,4],hook)
        assert result==1,(path.name,i,hex(u.reg_read(UC_ARM_REG_PC)),get(u,OBJ+0x18))
        assert get(u,OBJ+0x18)==1084
        report['native_troop_decodes']+=1
        # Convert decoded troop, not hand-injected cosmetic runtime fields.
        run(u,0x8106c0ca,[OUT,0,PARTY],hook)
        flag=troop[0xde];piece=70300+struct.unpack_from('<H',troop,0xdc)[0]
        assert get(u,PARTY+0x114)==flag and get(u,PARTY+0x118)==piece
        for j in range(4):
            unit=troop[276+j*202:];cls=struct.unpack_from('<H',unit)[0]
            runtime=PARTY+0x128+j*0x388
            want=[0xffffffff if v==255 else cls*100+v if v<100 else 99800+v for v in unit[0x84:0x8c]]
            got=[get(u,runtime+0x148+k*16)for k in range(8)]
            assert got==want,(cls,got,want)
            assert any(v!=0xffffffff for v in got),(cls,'no actions')
            assert all(v==0xffffffff or v in skillids for v in got)
            report['native_runtime_skill_slots']+=sum(v!=0xffffffff for v in got)
        for random_value,want in [(0,2),(99,0)]:
            u.mem_write(PARTY+0x16d0,bytes(24));owned.clear()
            run(u,0x81062ae8,[WAR,0,PARTY],hook)
            drops=[get(u,PARTY+0x16d0+j*8)for j in range(3)if get(u,PARTY+0x16d4+j*8)]
            # Some original pawn types have zero drop rate; flags all selected
            # here have a nonzero original rate. Keep those original rates.
            assert set(drops)==({70100+flag,piece} if random_value==0 else set()),(path.name,i,flag,piece,drops)
            assert set(drops).issubset({70100+flag,piece})
            owned.update(drops);u.mem_write(PARTY+0x16d0,bytes(24))
            run(u,0x81062ae8,[WAR,0,PARTY],hook)
            assert not any(get(u,PARTY+0x16d4+j*8)for j in range(3))
            report['native_cosmetic_drops']+=1
# Original victory collector -> original inventory dispatcher -> actual
# native save bytes. Only presentation/context/clock and RNG are modeled.
native_ownership=True
CTX,INV,CATS,ROWS,BATTLE,PARENT=0x2a00000,0x2a01000,0x2a02000,0x2a10000,0x2a20000,0x2a30000
put(u,INV+4,CATS);put(u,CATS+0xc4,ROWS)
for i in range(540):put(u,ROWS+40*i+4,70000+i)
put(u,BATTLE,PARENT);put(u,BATTLE+0x20,1);
random_value=0
u.mem_write(SAVE+0x2208a,bytes(540));u.mem_write(PARTY+0x16d0,struct.pack('<II',0xffffffff,0)*9)
run(u,0x81062ae8,[WAR,0,PARTY],hook)
drops=[get(u,PARTY+0x16d0+j*8)for j in range(9)if get(u,PARTY+0x16d4+j*8)]
assert set(drops)=={70100+flag,piece}
u.mem_write(PARENT+0x1748,bytes(u.mem_read(PARTY,0x1738)))
run(u,0x812de7bc,[BATTLE],hook)
assert get(u,BATTLE+0x1714)==2
collected=[get(u,BATTLE+0x100c+i*8)for i in range(2)]
assert set(collected)==set(drops)
for item in collected:
    u.mem_write(STACK,struct.pack('<I',1))
    run(u,0x813b1a2c,[INV,item,1,0],hook)
    assert run(u,0x8108dcfc,[0,item],hook)==1,(item,'native inventory unchanged')
report['native_victory_collection_and_save_awards']=len(collected)
# Exercise inventory/save dispatch for every cosmetic identifier assigned.
import re
source=(Path(__file__).parent/'server/rival46.go').read_text()
flags=[int(x)for x in re.search(r'var rivalFlags46 = .*?\{([^}]+)',source).group(1).split(',')]
pieces=[int(x)for x in re.search(r'var rivalPieces46 = .*?\{([^}]+)',source).group(1).split(',')]
for item in [70100+x for x in flags]+[70300+x for x in pieces]:
    u.mem_write(STACK,struct.pack('<I',1));run(u,0x813b1a2c,[INV,item,1,0],hook)
    assert run(u,0x8108dcfc,[0,item],hook)==1,item
report['native_cosmetic_inventory_awards']=len(flags)+len(pieces)

report['cosmetic_save_ownership_stubbed']=False
# Independently confirm all advertised loadouts originate in original NPCs.
preset=(params/'PRESETPARAMETER.DAT').read_bytes()
sets={}
for i in range(929):
    row=struct.unpack_from('<19i',preset,268332+i*76)
    for cls in range(23):
        active=row[1:7]
        if any(cls*100<=x<cls*100+100 for x in active) and all(x==-1 or cls*100<=x<cls*100+100 or x>=99900 for x in active):
            sets.setdefault(cls,set()).add(tuple(active))
for path in sorted(fixtures.glob('nation*.plain')):
    raw=path.read_bytes()
    for i in range(30):
        at=0x8c+i*0x518
        if not struct.unpack_from('<I',raw,at)[0]:continue
        for j in range(4):
            unit=raw[at+24+276+j*202:];cls=struct.unpack_from('<H',unit)[0]
            active=tuple(-1 if v==255 else cls*100+v if v<100 else 99800+v for v in unit[0x84:0x8a])
            assert active in sets[cls],(cls,active,'not an original NPC loadout')
report['original_npc_skill_provenance_verified']=True
print(json.dumps(report,indent=2))
