@echo off
cd /d "%~dp0"
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start_Local_War.ps1"
if errorlevel 1 echo Command failed. See the message above.
pause
