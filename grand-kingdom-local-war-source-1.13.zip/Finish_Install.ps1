﻿function Complete-Release11 {
 try {
  $knownOld=@('cd87eef0bbd0bb1359759bdcff33d91bca4dc33634bcfad5faea468daeec1412','9343063d37d51f7cfeaf00c0c31e4bc3d712c3d9ddd7b1d1dda8fd4d89a7def4','b63313ed6f19512f21fcd1ef1939265f88fefd06a0ba23ae12f4a3a0e48a0df8','8c055957caa4ffd62cd4fe7357ff5ff06835736f7471bf277abab4def19218dc','cc76c75fd2fae4ce4457a61370cf83279c7d75c39b3f4b1ec7db390e1d22bb3a','7cb4b923a34a1c73326da4b8fdbb451c5e5e45836d1fa166f0ecae82d8909487','a33edcd9fbfc7587ea0295e0148e77a736a0924b9881a971807011e5d50ed23b','b41cde607a2b1df6540aac09e1694c2432a6bf6096caaedc734f15b9814f8e8e','326621610d8190002828601a1b051fee8bdea38c08651ef3089f6aa88aaf8b05','2bc7ff8eee9965c727e8d49cc821713329407bc034181e703dc74b919faa9f18','892ede75cd5b0b9c645b14a863227ff577e19276361d9cd8d75dd6d47f7b0f46','8c8698e5f55605d36b300b7f490f82ec3cbeacbf8fcf3717639cd9e70bb824ec');$newServer='75a83567b95eebc7e61f23f223744b0ae5064911c754df73587865423ba051bc'
  $repairBackup11=Join-Path $PSScriptRoot ('backups/launchers11_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N').Substring(0,6))
  $savedAny11=$false
  foreach($name11 in @('server29.json','server30.json','server31.json','server32.json','server30-compatible29.json','server31-compatible29.json')){
   $target11=Join-Path $PSScriptRoot $name11
   if(!(Test-Path -LiteralPath $target11 -PathType Leaf)){continue}
   $legacy11=Get-Content -LiteralPath $target11 -Raw -Encoding UTF8 | ConvertFrom-Json
   if($legacy11.server_sha256 -eq $newServer){continue}
   if($legacy11.server_sha256 -notin $knownOld){Write-Host ('사용자 변경된 시작 검증 파일 보존: '+$name11);continue}
   if(!$savedAny11){[void](New-Item -ItemType Directory -Path $repairBackup11);$savedAny11=$true}
   $originalHash11=Hash $target11
   Copy-Item -LiteralPath $target11 -Destination (Join-Path $repairBackup11 $name11)
   if((Hash (Join-Path $repairBackup11 $name11)) -ne $originalHash11){throw 'Legacy launcher backup verification failed.'}
   $legacy11.server_sha256=$newServer
   $stage11=Join-Path $PSScriptRoot ('gk-launchers11-'+[guid]::NewGuid().ToString('N')+'.json')
   try {
    [IO.File]::WriteAllText($stage11,(ConvertTo-Json -InputObject $legacy11 -Depth 100),(New-Object Text.UTF8Encoding($false)))
    $hash11=Hash $stage11
    if((Hash $target11) -ne $originalHash11){throw 'Legacy launcher record changed during update.'}
    Replace-VerifiedFile $stage11 $target11 $hash11
   } finally {if(Test-Path -LiteralPath $stage11){Remove-Item -LiteralPath $stage11}}
  }
  $oldButton11=Join-Path $PSScriptRoot '2_Start_Server.cmd'
  if((Test-Path -LiteralPath $oldButton11 -PathType Leaf) -and (Hash $oldButton11) -eq '56a38c705aba935d97b85608258c9e487675b834150725cc90e6dfd825b4d138'){
   if(!$savedAny11){[void](New-Item -ItemType Directory -Path $repairBackup11);$savedAny11=$true}
   Copy-Item -LiteralPath $oldButton11 -Destination (Join-Path $repairBackup11 '2_Start_Server.cmd')
   if((Hash (Join-Path $repairBackup11 '2_Start_Server.cmd')) -ne '56a38c705aba935d97b85608258c9e487675b834150725cc90e6dfd825b4d138'){throw 'Original LOGIN ONLY button backup failed.'}
   $buttonStage11=Join-Path $PSScriptRoot ('gk-start11-'+[guid]::NewGuid().ToString('N')+'.cmd')
   try {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot '2_Start_Local_War.cmd') -Destination $buttonStage11
    $buttonHash11=Hash $buttonStage11
    if((Hash $oldButton11) -ne '56a38c705aba935d97b85608258c9e487675b834150725cc90e6dfd825b4d138'){throw 'Original LOGIN ONLY button changed during update.'}
    Replace-VerifiedFile $buttonStage11 $oldButton11 $buttonHash11
    Write-Host '초기 LOGIN ONLY 시작 버튼을 백업하고 전쟁 서버 시작으로 교체했습니다.' -ForegroundColor Green
   } finally {if(Test-Path -LiteralPath $buttonStage11){Remove-Item -LiteralPath $buttonStage11}}
  }
  Write-Host '전쟁 서버 시작: 2_Start_Local_War.cmd (2_Start_War_33.cmd도 같은 버튼)' -ForegroundColor Green
 } catch {
  Write-Host ('이전 시작 버튼 보완 실패: '+$_.Exception.Message) -ForegroundColor Yellow
  Write-Host '게임 설치는 완료되었습니다. 새 2_Start_Local_War.cmd를 사용하세요.' -ForegroundColor Yellow
 }
}
