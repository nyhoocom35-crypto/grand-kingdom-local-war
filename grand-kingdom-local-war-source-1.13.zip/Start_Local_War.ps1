﻿$ErrorActionPreference='Stop'
try{
 if(Get-Process -Name Vita3K -ErrorAction SilentlyContinue){throw 'Close Vita3K, start this server, then reopen Vita3K.'}
 if(@(Get-Process -ErrorAction SilentlyContinue|Where-Object {$_.ProcessName -like 'GK_Server*'}).Count -gt 0){throw 'Close other GK server windows first.'}
 $m=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'release.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $r=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'public-install.json') -Raw -Encoding UTF8|ConvertFrom-Json
 if($r.mode -notin @('standard','growth8')){throw 'Unsupported installation mode.'}
 $expected=$m.modes.($r.mode).patched_sha256
 if((Get-FileHash -LiteralPath $r.target -Algorithm SHA256).Hash -ne $expected){throw 'Executable hash mismatch. Run 1_Install_Standard.cmd or the selected optional growth installer.'}
 $protocol=Join-Path $PSScriptRoot 'protocol.dat'
 if(!(Test-Path -LiteralPath $protocol) -or (Get-FileHash -LiteralPath $protocol -Algorithm SHA256).Hash -ne $m.protocol_sha256){throw 'Protocol missing or incorrect. Re-run the installer with your decrypted executable.'}
 $exe=Join-Path $PSScriptRoot 'GK_Server_29.exe'
 if((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash -ne $m.server_sha256){throw 'Server hash mismatch.'}
 & $exe --selftest;if($LASTEXITCODE -ne 0){throw 'Server selftest failed.'}
 Write-Host 'Grand Kingdom Local War 1.13' -ForegroundColor Green
 Write-Host ('Mode: '+$r.mode+' / EXP x3 / MERIT x3')
 Write-Host 'Vote44 / Shop43 / Research39 / Siege40: 연구 완료 시 실제 상점 목록 갱신, 기존 연구 진행 유지.' -ForegroundColor Green
 Write-Host 'Vita3K SETTINGS: OpenGL backend / VSync OFF' -ForegroundColor Yellow
 $backup=Join-Path $PSScriptRoot ('backups/before-start11_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N').Substring(0,6))
 [void](New-Item -ItemType Directory -Path $backup)
 foreach($name in @('war-state.json','local-users.json','public-install.json','active-install.json')){
  $p=Join-Path $PSScriptRoot $name
  if(Test-Path -LiteralPath $p -PathType Leaf){Copy-Item -LiteralPath $p -Destination $backup;if((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath (Join-Path $backup $name) -Algorithm SHA256).Hash){throw 'State backup verification failed.'}}
 }
 Write-Host '국가·지역·거점 이름 표시 33 포함. READY 뒤 Vita3K를 실행하세요.' -ForegroundColor Green
 Write-Host 'This is a LOCAL AI war server for this PC. Keep the READY window open.'
 & $exe
 if($LASTEXITCODE -ne 0){throw 'Server stopped. Check whether another program is using local port80.'}
}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}
