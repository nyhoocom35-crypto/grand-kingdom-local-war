﻿function Replace-VerifiedFile([string]$Source, [string]$Target, [string]$ExpectedHash) {
 $Source=[IO.Path]::GetFullPath($Source)
 $Target=[IO.Path]::GetFullPath($Target)
 if(-not (Test-Path -LiteralPath $Source -PathType Leaf)){throw 'Replacement source missing.'}
 if(-not (Test-Path -LiteralPath $Target -PathType Leaf)){throw 'Replacement target missing.'}
 if((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne $ExpectedHash){throw 'Replacement source hash mismatch.'}
 # Windows PowerShell converts $null to an empty string for this .NET call.
 # Use an actual sibling backup path, also keeping the replaced file on failure.
 $rollback=Join-Path (Split-Path $Target -Parent) ('gk-replace-backup-'+[guid]::NewGuid().ToString('N')+'.bin')
 [IO.File]::Replace($Source,$Target,$rollback)
 if((Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash -ne $ExpectedHash){throw ('Replacement verification failed. Prior executable retained at: '+$rollback)}
 if(Test-Path -LiteralPath $rollback){Remove-Item -LiteralPath $rollback}
}
